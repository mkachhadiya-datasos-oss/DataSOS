from datetime import datetime
import  db_config as db
import hashlib
import json
from threading_request_check import *
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import random
import os
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
# Serve static folder
app.mount("/static", StaticFiles(directory="static"), name="static")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow all (for testing)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


#api endpoint logic for basic functionality
@app.get("/")
def serve_ui():
    return FileResponse("static/basic_html.html")
@app.get("/dashboard")
def dashboard():
    return {"message": "Welcome to dashboard"}
@app.get("/srp")
def req_pdp(url : str):
    ''' srp = simple request pdp '''
    import requests
    headers = db.build_headers()
    request_args = {"headers":headers}
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)

    request_args = {k: v for k,v in request_args.items() if v is not None}
    try:
        response = requests.get(url,**request_args)
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(f"200{url}srp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            # pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status":200,
                    "url":url,
                    "req_type":"srp",
                    "pagesave":pagesave_path,
                    "timestamp_time" : datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key":file_hash_key
            }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(f"{response.status_code}{url}srp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.normpath(os.path.join(file_path,f"{file_hash_key}.html"))
            item = {
                    "status": response.status_code,
                    "url": url,
                    "req_type": "srp",
                    "pagesave":None,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/srsp")
def req_sesion_pdp(url : str):

    """srsp = simple request session pdp"""
    import requests
    headers = db.build_headers()
    request_args = {"headers": headers}
    file_path = os.path.join(db.SAVE_PATH, "srsp")
    os.makedirs(file_path, exist_ok=True)
    request_args = {k: v for k, v in request_args.items() if v is not None}
    try:
        session = requests.Session()
        response = session.get(url, **request_args)
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}srsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status": 200,
                    "url": url,
                    "req_type": "srsp",
                    "pagesave": pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}srsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "srsp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crp")
def creq_pdp(url : str):
    """curl-cffi request pdp"""

    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers beacause curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crp")
    os.makedirs(file_path,exist_ok=True)
    try:
        response = requests.get(url,impersonate=random.choice(impersonate_list))
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(f"200{url}crp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status":200,
                    "url":url,
                    "req_type":"crp",
                    "pagesave":pagesave_path,
                    "timestamp_time" : datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key":file_hash_key
            }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(f"{response.status_code}{url}crp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                    "status": response.status_code,
                    "url": url,
                    "req_type": "crp",
                    "pagesave":pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }
@app.get("/crsp")
def creq_session_pdp(url : str):
    """crsp = curl request with session pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers because curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crsp")
    os.makedirs(file_path, exist_ok=True)
    try:
        session = requests.Session()
        response = session.get(url, impersonate=random.choice(impersonate_list))
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {"status": 200,
                    "url": url,
                    "req_type": "crsp",
                    "pagesave": pagesave_path,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(pagesave_path, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crsp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            pagesave_path = os.path.join(file_path,f"{file_hash_key}.html")
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crsp",
                "pagesave": pagesave_path,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(pagesave_path, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crpp")
def creq_proxy_pdp(url : str):
    """crpp = curl request proxy pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import urllib.parse
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers beacause curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crpp")
    os.makedirs(file_path, exist_ok=True)
    try:
        token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
        targetUrl = urllib.parse.quote(url)
        url = "http://api.scrape.do/?token={}&url={}".format(token, targetUrl)
        response = requests.get(url, impersonate=random.choice(impersonate_list))
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crpp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {"status": 200,
                    "url": url,
                    "req_type": "crpp",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(SAVE_PATH, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crpp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crpp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(SAVE_PATH, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }
@app.get("/crspp")
def creq_proxy_session_pdp(url : str):
    """crspp = curl request proxy session pdp"""
    from curl_cffi import requests
    from curl_cffi.requests import BrowserType
    import urllib.parse
    impersonate_list = [i.value for i in BrowserType]

    # batter not to use headers because curl-cffi provide it with TLS, JA3, fingerprinting, randon sea-ca may trigger blocking
    file_path = os.path.join(db.SAVE_PATH, "crspp")
    os.makedirs(file_path, exist_ok=True)
    try:
        token = "876484b6eb084b818e74e53e26d5e519302cbab8e78"
        targetUrl = urllib.parse.quote(url)
        url = "http://api.scrape.do/?token={}&url={}".format(token, targetUrl)
        session = requests.Session()
        response = session.get(url, impersonate=random.choice(impersonate_list))
        session.close()
        if response.status_code == 200:
            file_hash_key = hashlib.sha256(
                f"200{url}crspp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {"status": 200,
                    "url": url,
                    "req_type": "crspp",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                    }

            with open(SAVE_PATH, "w", encoding="utf-8") as f:
                f.write(response.text)
            db.insert_records(item)
            return item
        else:
            file_hash_key = hashlib.sha256(
                f"{response.status_code}{url}crspp{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
            SAVE_PATH = f"{file_path}/{file_hash_key}.html"
            item = {
                "status": response.status_code,
                "url": url,
                "req_type": "crspp",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": file_hash_key
            }
            # with open(SAVE_PATH, "w", encoding="utf-8") as f:
            #     f.write(response.text)
            db.insert_records(item)
            return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/srtp")
def req_thread_pdp(url :str):
    '''srtp = simple request thread pdp... '''
    try:
        response_json = request_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "srtp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/srstp")
def req_session_thread_pdp(url : str):
    '''srstp = simple request session thread pdp...'''
    try:
        response_json = request_session_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "srstp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/crtp")
def curl_request_thread_pdp(url :str):
    """crtp = curl cffi request thread pdp..."""
    try:
        response_json = curl_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status",None)),
            "url": url,
            "req_type": "crtp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code":500,
            "content":{"status": "error", "message": str(e)}
        }

@app.get("/crstp")
def curl_req_session_thread_pdp(url : str):
    try:
        response_json = curl_session_thread_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crstp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crtpp")
def curl_req_proxy_thread_pdp(url : str):
    """crtpp = curl request thread proxy pdp"""
    try:
        response_json = curl_thread_proxy_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crtpp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }

@app.get("/crtspp")
def curl_req_thread_session_proxy_pdp(url : str):
    """crtspp = curl request thread session proxy pdp"""
    try:
        response_json = curl_thread_proxy_session_pdp(url)
        item = {
            "status": json.dumps(response_json.get("response_Status", None)),
            "url": url,
            "req_type": "crtspp",
            "pagesave": None,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": None
        }
        db.insert_records(item)
        return item
    except Exception as e:
        return {
            "status_code": 500,
            "content": {"status": "error", "message": str(e)}
        }
@app.get("/seleniumPDP")
def selenium_req(url :str):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager

    def is_blocked(driver):
        html = driver.page_source.lower()
        title = driver.title.lower()
        url = driver.current_url.lower()

        block_signs = [
            "cf-challenge",
            "captcha",
            "access denied",
            "verify you are human",
            "attention required",
            "just a moment","forbidden","Press & Hold"
        ]

        if any(sign in html for sign in block_signs):
            return True

        if any(sign in title for sign in block_signs):
            return True

        if "/cdn-cgi/" in url:
            return True

        return False
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--headless=False")
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service,options = options)
    driver.get(url)
    content = driver.page_source
    if is_blocked(driver):
        print("Blocked detected!")
        file_hash_key = hashlib.sha256(
            f"201{url}selenium{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        #201 indicate some issue check pagesave for this...
        item = {
            "status": 201,
            "url": url,
            "req_type": "selenium",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    else:
        print("Page loaded normally")
        file_hash_key = hashlib.sha256(
            f"200{url}selenium{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        item = {
            "status": 200,
            "url": url,
            "req_type": "selenium",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    driver.quit()

@app.get("/playwrightTest")
def playwright_req(url : str):
    from playwright.sync_api import sync_playwright
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_context().new_page()
        page.goto("https://www.zillow.com/")
        page.wait_for_load_state("networkidle")
        content = page.content()
        try:
            if "captcha" in page.content() or "Press & Hold":
                print("Blocked!")
                file_hash_key = hashlib.sha256(
                    f"201{url}playwright{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
                SAVE_PATH = f"{file_path}/{file_hash_key}.html"
                with open(SAVE_PATH, "w", encoding="utf-8") as f:
                    f.write(content)
                # 201 indicate some issue check pagesave for this...
                item = {
                    "status": 201,
                    "url": url,
                    "req_type": "playwright",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                }
                db.insert_records(item)
                return item
            else:
                file_hash_key = hashlib.sha256(
                    f"200{url}playwright{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
                SAVE_PATH = f"{file_path}/{file_hash_key}.html"
                with open(SAVE_PATH, "w", encoding="utf-8") as f:
                    f.write(content)
                # 201 indicate some issue check pagesave for this...
                item = {
                    "status": 200,
                    "url": url,
                    "req_type": "playwright",
                    "pagesave": SAVE_PATH,
                    "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                    "file_hash_key": file_hash_key
                }
                db.insert_records(item)
                return item
            browser.close()
        except Exception as e:
            item = {
                "status": 500,
                "url": url,
                "req_type": "playwright",
                "pagesave": None,
                "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
                "file_hash_key": "Blocking"
            }
            db.insert_records(item)
            return item

@app.get("/drissionpagePDP")
def drission_page_req(url : str):
    from DrissionPage import ChromiumPage
    file_path = os.path.join(db.SAVE_PATH, "srp")
    os.makedirs(file_path, exist_ok=True)
    timestamp = datetime.now().strftime('%d-%m-%Y-%H-%M-%S-%f')[:-3]
    page = ChromiumPage()
    sucess = page.get(url)
    content = page.html
    block_keywords = [
        "captcha",
        "verify you are human",
        "access denied",
        "cloudflare",
    ]
    is_blocked = any(word in content.lower() for word in block_keywords)
    status_code = 200 if sucess else 201
    if status_code != 200 or is_blocked:
        file_hash_key = hashlib.sha256(
            f"201{url}drissionpage{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        # 201 indicate some issue check pagesave for this...
        item = {
            "status": 201,
            "url": url,
            "req_type": "drissionpage",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item
    else:
        file_hash_key = hashlib.sha256(
            f"200{url}drission_page{datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3]}".encode()).hexdigest()
        SAVE_PATH = f"{file_path}/{file_hash_key}.html"
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            f.write(content)
        # 201 indicate some issue check pagesave for this...
        item = {
            "status": 200,
            "url": url,
            "req_type": "drissionpage",
            "pagesave": SAVE_PATH,
            "timestamp_time": datetime.now().strftime("%d-%m-%Y-%H-%M-%S-%f")[:-3],
            "file_hash_key": file_hash_key
        }
        db.insert_records(item)
        return item


if __name__ == "__main__":
    # create_table()
    # session_id = str(uuid.uuid4())
    # cookies = {
    #     "session_id": session_id
    # }
    # url = 'https://books.toscrape.com/'
    # result = selenium_req(url)
    # result = req_pdp(url)

    # print(json.dumps(req_pdp(url)))
    uvicorn.run(
        "main:app",
        host="0.0.0.0",  # allow network
        port=8000,  # your port
        reload=True
    )
    # uvicorn.run("main:app",host="0.0.0.0",port=8000,reload=True)