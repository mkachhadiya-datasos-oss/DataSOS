import os
from ICrimeWatch_OH_SOR import db_config as db

conn,cur = db.conn_()
query = f"select offender_id from {db.pagesave_table} where status='done' and status_photo='done'"
cur.execute(query)
records = cur.fetchall()
print(len(records))
for id_ in records:
    ofend_id = id_["offender_id"]
    path_ = fr"{db.DETAIL_PATH}\{ofend_id}.html"
    if not os.path.exists(path_):
        print(ofend_id)
        update_query = f"update {db.pagesave_table} set status='pending' ,status_photo='pending' where offender_id='{ofend_id}'"
        cur.execute(update_query)
        conn.commit()
    else:
        print("found :",ofend_id)