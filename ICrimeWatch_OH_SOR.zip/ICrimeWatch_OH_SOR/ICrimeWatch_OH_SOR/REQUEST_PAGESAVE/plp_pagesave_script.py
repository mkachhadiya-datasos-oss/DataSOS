from curl_cffi import requests
from concurrent.futures import ThreadPoolExecutor
from ICrimeWatch_OH_SOR.REQUEST_PAGESAVE.playwright_Script_check import *
import ICrimeWatch_OH_SOR.db_config as db
from parsel import Selector
conn, cur = db.conn_()
start_time = time.time()
cookies_dict = collect_cookies('https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
cookies = {
    'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
    'datadome': f'{cookies_dict.get("datadome")}',
}

def fetch_result(page):
    global cookies
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Referer': f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrCity=&OfndrLast=%27%25%27&OfndrFirst=%27%25%27&level=&AllCity=&altaddr=home_addr&excludeIncarcerated=0&page={page}',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
        'sec-ch-device-memory': '8',
        'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-arch': '"x86"',
        'sec-ch-ua-full-version-list': '"Google Chrome";v="147.0.7727.101", "Not.A/Brand";v="8.0.0.0", "Chromium";v="147.0.7727.101"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Linux"',
    }
    url=f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}'
    for i in range(5):
        response = requests.get(
            url = url,
            cookies=cookies,
            headers=headers, impersonate="chrome110",timeout=800000
        )
        print(response.status_code)
        if response.status_code == 200:
            file_path = fr"{db.INDEX_PATH}\{page}.html"
            db.pagesave_data(response,file_path)
            print("pagesave done... for page : ",page)
            response = Selector(response.text)
            total_count_on_page = response.xpath('//strong[contains(text(),"Found")]').get().strip()
            table_tr = response.xpath('//table[.//tr//*[contains(text(),"View Details")]][@bgcolor="#CCCCCC"]//tr[position()>1]')
            if table_tr.get():
                # main_list = list()
                for tr in table_tr:
                    #lattter transfer this into function
                    pdp_url = tr.xpath('.//td[2]/a/@href').get()
                    offender_id = pdp_url.split("OfndrID=")[-1].split("&AgencyID")[0]
                    photo_url = tr.xpath('.//td[2]/a/img/@src').get()
                    item = dict()
                    item["plp_url"] = url
                    item["page_no"] = page
                    item["pdp_url"] = pdp_url
                    item["offender_id"] = offender_id
                    item["photo_url"] = photo_url
                    db.insert_item(item,db.INDEX_TABLE)
                    #end transfer
            break
        elif response.status_code == 403:
            # count+=1
            # if count == 5:break
            cookies_dict = collect_cookies(f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}')
            # cookies_dict = get_cookie_dict(
            #     f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}')
            cookies = {
                # '__utma': '6555946.1356812029.1777018539.1777018539.1777018539.1',
                # '__utmz': '6555946.1777018539.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
                # '_ga': 'GA1.2.1356812029.1777018539',
                # '_gid': 'GA1.2.786249279.1778132863',
                'cf_clearance': f"{cookies_dict.get("cf_clearance")}",
                # '_ga_LZVJY7FF50': 'GS2.2.s1778132865$o2$g1$t1778134392$j60$l0$h0',
                'datadome': f'{cookies_dict.get("datadome")}',
            }
            continue

pages = list(range(104,750))
with ThreadPoolExecutor(max_workers=5) as executor:
    result = list(executor.map(fetch_result,pages))
for r in result:
    print(r)
end_time = time.time()
total_ = end_time - start_time
print("total from file 3 : ",total_)
