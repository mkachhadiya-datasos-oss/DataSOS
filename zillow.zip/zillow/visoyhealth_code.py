import json
import time
from http.client import responses
import gzip
from seleniumwire.undetected_chromedriver import Chrome
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ==============================
# Start Undetected Chrome
# ==============================

options = uc.ChromeOptions()
options.add_argument("--start-maximized")
options.add_argument("--ignore-certificate-errors")
options.add_argument("--ignore-ssl-errors")
options.add_argument("--allow-insecure-localhost")
options.add_argument("--disable-web-security")
seleniumwire_options = {
    'verify_ssl': False,'suppress_connection_errors': True
}
driver = Chrome(options=options,seleniumwire_options=seleniumwire_options,version_main=145)

driver.get("https://www.visoryhealth.com/")
# ==============================
# 1️⃣ Click "Customer"
# ==============================
wait = WebDriverWait(driver, 20)
driver.execute_script("document.body.style.zoom='100%'")
time.sleep(2)

customer_btn = wait.until(
    EC.presence_of_element_located(
        (By.XPATH, "//div[contains(text(),'Customer')]")
    )
)
time.sleep(2)
customer_btn.click()

print("Clicked Customer")

# Wait until modal disappears
wait.until(
    EC.invisibility_of_element_located(
        (By.XPATH, "//div[contains(text(),'Tell us about yourself')]")
    )
)

# ==============================
# Enter ZIP Code
# ==============================

zip_wrapper = wait.until(
    EC.presence_of_element_located(
        (By.CSS_SELECTOR, "div.location-wrapper")
    )
)
time.sleep(2)

driver.execute_script("arguments[0].click();", zip_wrapper)

# ==============================
# Step 2: Wait for input to appear
# ==============================

zip_input = wait.until(
    EC.visibility_of_element_located(
        (By.CSS_SELECTOR, "input.rbt-input-main")
    )
)
time.sleep(2)

# ==============================
# Step 3: Enter ZIP
# ==============================

zip_input.send_keys("10001")
time.sleep(2)
# Click first suggestion
first_option = driver.find_element(By.XPATH, "//div[@id='zipcode'][@role='listbox']//a[1]")
time.sleep(2)
first_option.click()

time.sleep(2)
driver.requests.clear()
# ==============================
# Enter Drug Name
# ==============================

drug_wrapper = wait.until(EC.presence_of_element_located((By.XPATH,"//span[text()='Type your drug name here']/ancestor::div[contains(@class,'location-wrapper')]")))
time.sleep(2)

driver.execute_script("arguments[0].click();",drug_wrapper)
time.sleep(2)
drug_input = wait.until(EC.visibility_of_element_located((By.XPATH,"//input[contains(@class,'rbt-input')]")))
time.sleep(1)
# driver.execute_script("arguments[0].focus();", drug_input)
drug_input.send_keys("Sildenafil Citrate")

time.sleep(3)
# Click first suggestion
first_option = driver.find_element(By.XPATH, "//div[@id='drugsearch'][@role='listbox']//a[1]")
time.sleep(2)

first_option.click()
time.sleep(2)

#before button click we can get search basic request response that header has "pbm-subscription-key" this key
# ==============================
# Capture Network Logs
# ==============================
last_request = None
for request in driver.requests:
    if request.response:
        if "search?query" in request.url:
            last_request = request
request = last_request
body = request.response.body

if request.response.headers.get('Content-Encoding') == "gzip":
    body = gzip.decompress(body)
response_json = json.loads(body.decode('utf-8'))
if request.body:
    print("paylod : ",request.body.decode())
# print("response : ")
# print(request.response.body.decode())
data_to_save = {
    "url": request.url,
    "method": request.method,
    "request_headers": dict(request.headers),
    "response_headers": dict(request.response.headers),
    "response_json": response_json
}
print("=" * 50)
with open("search_result.json", "w", encoding="utf-8") as f:
    json.dump(data_to_save, f, indent=4)

print("Saved successfully ✅")
driver.requests.clear()

# Click Search Button
time.sleep(2)

search_btn = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@class='row']//button[@type='submit']")))
time.sleep(2)

search_btn.click()

time.sleep(6)
# ==============================
# Capture Network Logs
# ==============================
last_request = None

for request in driver.requests:
    if request.response:
        if "search?drugname" in request.url:
            last_request = request

request = last_request
body = request.response.body

if request.response.headers.get('Content-Encoding') == "gzip":
    body = gzip.decompress(body)
response_json = json.loads(body.decode('utf-8'))
if request.body:
    print("paylod : ",request.body.decode())
# print("response : ")
# print(request.response.body.decode())
data_to_save = {
    "url": request.url,
    "method": request.method,
    "request_headers": dict(request.headers),
    "response_headers": dict(request.response.headers),
    "response_json": response_json
}
print("=" * 50)
with open("drugname_search_result.json", "w", encoding="utf-8") as f:
    json.dump(data_to_save, f, indent=4)

print("Saved successfully ✅")
# ==============================
# Print Results
# ==============================
driver.close()

driver.quit()