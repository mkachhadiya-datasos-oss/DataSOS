import curl_cffi.requests.impersonate
from curl_cffi import requests
from curl_cffi.requests import BrowserType
import json
import time
import random
import pymysql
import db_config as db

def request_start():
    query = f"select * from {db.lat_long_table} where status='pending'"
    db.cur.execute(query)
    datas = db.cur.fetchall()
    impersonate_list = [v.value for v in BrowserType]
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.zillow.com',
        'priority': 'u=1, i',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
    }
    time_stop = [1,3,4,2,1,3,2,2.5,1.5]
    request_id = 172
    for data in datas:
        response_list = list()
        for i in range(1,13):
            # current_page = 1
            json_data = {
                'searchQueryState': {
                    'pagination': {
                        'currentPage': i,
                    },
                    'isMapVisible': True,
                    'mapBounds': {
                        'west': float(data[2]),
                        'east': float(data[1]),
                        'south': float(data[3]),
                        'north': float(data[4]),
                    },
                    'filterState': {
                        'isForRent': {
                            'value': True,
                        },
                        'isForSaleByAgent': {
                            'value': False,
                        },
                        'isForSaleByOwner': {
                            'value': False,
                        },
                        'isNewConstruction': {
                            'value': False,
                        },
                        'isComingSoon': {
                            'value': False,
                        },
                        'isAuction': {
                            'value': False,
                        },
                        'isForSaleForeclosure': {
                            'value': False,
                        },
                    },
                    'isListVisible': True,

                },
                'wants': {
                    'cat1': [
                        'listResults',
                        'mapResults',
                    ],
                },
                'requestId': request_id,
                'isDebugRequest': False,
            }
            time.sleep(random.choice(time_stop))
            session = requests.Session()
            response = session.put('https://www.zillow.com/async-create-search-page-state', headers=headers, json=json_data, impersonate="chrome101")
            session.close()
            time.sleep(random.choice(time_stop))

            request_id+=1
            file_path = fr"{db.plp_pagesave}\{i}_{data[5]}.json"
            if response.status_code == 200:
                response_list.append(response.status_code)
                with open(file_path,"w",encoding="UTF-8") as f:
                    json.dump(response.json(),f)
                print("json data saved..")
            else:
                response_list.append(response.status_code)
                print("response status code and page number and data :",data," respose:",response.status_code)

        if len(set(response_list)) == 1:
            update_qu8ery = f"Update {db.lat_long_table} set status='done' where hash_key='{data[5]}'"
            db.cur.execute(update_qu8ery)
            db.conn.commit()
        else:
            update_qu8ery = f"Update {db.lat_long_table} set status='Error' where hash_key='{data[5]}'"
            db.cur.execute(update_qu8ery)
            db.conn.commit()




if __name__ == "__main__":
    request_start()

