import pandas as pd
import pymysql
import hashlib
from datetime import datetime
today = datetime.now().strftime("%Y%m")
plp_pagesave = fr"E:\pagesave\zillow\{today}\plp"
lat_long_table = "Zillow_lat_long"

conn = pymysql.connect(host="localhost",user="root",database="feasibility_test")
cur = conn.cursor()
def create_Table():
    query = f"""Create TABLE IF NOT EXISTS {lat_long_table} (
    id int auto_increment primary key,
    east VARCHAR(255),
    west VARCHAR(255),
    south VARCHAR(255),
    north VARCHAR(255),
    hash_key VARCHAR(255),
    status VARCHAR(50) DEFAULT 'pending'
    )"""
    cur.execute(query)
    conn.commit()

create_Table()

# df = pd.read_excel(fr"E:\Mansi\projects\zillow\US_Zillow_Grid.xlsx")
# insert_query = f""" Insert INTO {lat_long_table} (east, west, south, north, hash_key) values (%s, %s, %s, %s, %s)"""
#
# value_list = []
# for _, rows in df.iterrows():
#     east = rows["east"]
#     west = rows["west"]
#     south = rows["south"]
#     north = rows["north"]
#     hash_key = hashlib.sha256(f"{east}{west}{south}{north}".encode()).hexdigest()[]
#     value_list.append((east, west, south, north, hash_key))
#
# cur.executemany(insert_query,value_list)
# conn.commit()

