from playwright.sync_api import sync_playwright
import time
import os

def save_page(page, name):
    html = page.content()
    with open(f"{name}.html", "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Saved: {name}.html")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False, slow_mo=100)
    context = browser.new_context(viewport={"width": 1366, "height": 768})
    page = context.new_page()

    # ---------------------------
    # 1. Open Zillow
    # ---------------------------
    page.goto("https://www.zillow.com/")
    page.wait_for_load_state("networkidle")

    page.wait_for_selector("text=Press & Hold")

    hold_area = page.locator("text=Press & Hold")
    box = hold_area.bounding_box()

    x = box["x"] + box["width"] / 2
    y = box["y"] + box["height"] / 2

    page.mouse.move(x, y)
    page.mouse.down()
    time.sleep(10)
    page.mouse.up()

    time.sleep(5)
    # ---------------------------
    # 3. Go to For Sale page
    # ---------------------------
    page.goto("https://www.zillow.com/homes/for_sale/")
    page.wait_for_load_state("networkidle")
    time.sleep(3)

    # ---------------------------
    # 4. Zoom map little
    # ---------------------------
    try:
        zoom_btn = page.locator("button[aria-label*='Zoom in']")
        if zoom_btn.count() > 0:
            zoom_btn.first.click()
            time.sleep(2)
    except:
        print("Zoom button not found")

    # ---------------------------
    # 5. Move cursor to side listing div
    # ---------------------------
    try:
        side_div = page.locator("#search-page-list-container")
        side_div.hover()
        time.sleep(2)
    except:
        print("Side div not found")

    # ---------------------------
    # 6. Scroll until pagination
    # ---------------------------
    while True:
        page.mouse.wheel(0, 1000)
        time.sleep(1)

        if page.locator(".search-pagination").count() > 0:
            print("Pagination found")
            break

    # ---------------------------
    # 7. Save full page
    # ---------------------------
    save_page(page, "for_sale_with_pagination")

    browser.close()