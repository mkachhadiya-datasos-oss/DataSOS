import pandas as pd

# ==============================
# US Boundary
# ==============================
US_WEST  = -125
US_EAST  = -66
US_SOUTH = 24.5
US_NORTH = 49.5

# ==============================
# Tile Size (Your Original Exact Values)
# ==============================
lon_step = 1.31561279296875
lat_step = 0.749224073236

tiles = []

current_north = US_NORTH

while current_north > US_SOUTH:

    current_west = US_WEST

    while current_west < US_EAST:

        west  = current_west
        east  = current_west + lon_step
        north = current_north
        south = current_north - lat_step

        if east > US_EAST:
            east = US_EAST
        if south < US_SOUTH:
            south = US_SOUTH

        tiles.append({
            "west": west,
            "east": east,
            "south": south,
            "north": north
        })

        current_west += lon_step

    current_north -= lat_step

df = pd.DataFrame(tiles)

# Important: disable float formatting
pd.options.display.float_format = None

df.to_excel("US_Zillow_Grid.xlsx", index=False)

print("Excel generated.")
print("Total tiles:", len(df))



# import json
# import math
# import pandas as pd
# US_BOUNDS = {
#     "west": -125.0,
#     "east": -66.9,
#     "south": 24.5,
#     "north": 49.4
# }
#
#
# def meters_to_longitude_degrees(meters, latitude):
#     """
#     Convert meters to longitude degrees at specific latitude
#     """
#     meters_per_degree = 111320 * math.cos(math.radians(latitude))
#     return meters / meters_per_degree
#
#
# def generate_us_longitude_steps(step_meters=11, latitude=37.0):
#     """
#     Generate longitude values from east to west across US
#     moving step_meters each time.
#     latitude default = center of US (~37°)
#     """
#
#     east = US_BOUNDS["east"]
#     west = US_BOUNDS["west"]
#
#     delta = meters_to_longitude_degrees(step_meters, latitude)
#
#     current = east
#     longitudes = []
#
#     while current >= west:
#         longitudes.append(current)
#         current -= delta
#
#     return longitudes
#
#
# def generate_us_grid(step_meters=11):
#     boxes = []
#
#     lat = US_BOUNDS["south"]
#
#     while lat <= US_BOUNDS["north"] and len(boxes) <20:
#
#         delta_lat = step_meters / 111320
#
#         delta_lng = meters_to_longitude_degrees(step_meters, lat)
#
#         lng = US_BOUNDS["east"]
#
#         while lng >= US_BOUNDS["west"]:
#             box = {
#                 "west": lng - delta_lng,
#                 "east": lng,
#                 "south": lat,
#                 "north": lat + delta_lat
#             }
#
#             boxes.append(box)
#
#             lng -= delta_lng
#
#         lat += delta_lat
#
#     return boxes
#
# # data = generate_us_grid()
#
# data = generate_us_grid(step_meters=1000)  # ⚠️ NOT 11m (use 1000m first)
#
# df = pd.DataFrame(data)
#
# with open(r"E:\Mansi\projects\zillow\lat_long_text.json", "w", encoding="utf-8") as f:
#     json.dump(df.to_dict(orient="records"), f, indent=2)