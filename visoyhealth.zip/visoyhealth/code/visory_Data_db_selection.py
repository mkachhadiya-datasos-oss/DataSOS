""" this file including db selection input and process and store into data table and update status as well captch solution"""
import json
import time
import gzip
import hashlib
from selenium.common.exceptions import TimeoutException
from tldextract import update
import db_config as db
import pandas as pd
from seleniumwire.undetected_chromedriver import Chrome
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def pagesave_insert_records(item):
    generic_name = item["generic_name"]
    mode_quantity = item["mode_quantity"]
    drug_name = item["drug_name"]
    form = item["form"]
    dosage = item["dosage"]
    quantity = item["quantity"]
    zipcode = item["zipcode"]
    pagesave_path = item["pagesave_path"]
    hash_key = item["hash_key"]

    try:
        # language=SQL
        query = f"""
        INSERT INTO {db.pagesave_pdp_table}
        (generic_name, mode_quantity, drug_name, form, dosage, quantity, zipcode, pagesave_path, hash_key)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        db.cur.execute(query,(generic_name, mode_quantity, drug_name, form, dosage, quantity, zipcode, pagesave_path, hash_key))
        db.conn.commit()

        update_query = f"update {db.input_Data_table} set status='done' where generic_name = %s and zipcode = %s"
        db.cur.execute(update_query,(generic_name,zipcode))
        db.conn.commit()

    except Exception as e:
        print("insertion isuue and update issue: ", e)


def select_drop_down_value(wait, index, value_to_select):
    if index != 3:
        # click dropdown toggle
        dropdowns = wait.until(
            EC.presence_of_all_elements_located((By.XPATH, "//button[contains(@class,'dropdown-toggle-custom')]")))
        target_dropdown = dropdowns[index]
        # open drop down
        driver.execute_script("arguments[0].click();", target_dropdown)

        # wait for matching options
        option_xpath = f"""
           //div[contains(@class,'dropdown-menu')]
           //button[normalize-space()='{value_to_select}']
           """
        option = wait.until(EC.presence_of_element_located((By.XPATH, option_xpath)))

        # direct json click
        driver.execute_script("arguments[0].click();", option)

    else:
        # click dropdown toggle
        dropdowns = wait.until(
            EC.presence_of_all_elements_located((By.XPATH, "//button[contains(@class,'dropdown-toggle-custom')]")))
        target_dropdown = dropdowns[index]
        # open drop down
        driver.execute_script("arguments[0].click();", target_dropdown)
        qty_input = wait.until(
            EC.visibility_of_element_located((By.XPATH, "//input[@placeholder='Enter quantity']"))
        )
        time.sleep(1)
        # click input
        qty_input.click()
        # select old value
        qty_input.send_keys(Keys.CONTROL + "a")
        # delete it
        qty_input.send_keys(Keys.BACKSPACE)
        qty_input.clear()

        # driver.execute_script("arguments[0].focus();", drug_input)
        # drug_name = "Tadalafil"
        qty_input.send_keys(str(value_to_select))
        time.sleep(1)
        # IMPORTANT → press enter to apply
        qty_input.send_keys(Keys.ENTER)

def is_captcha_present(driver):
    try:
        # switch to recaptcha iframe if present
        iframe = driver.find_element(By.XPATH, "//iframe[contains(@title,'reCAPTCHA')]")
        driver.switch_to.frame(iframe)

        driver.find_element(By.XPATH, "//label[@id='recaptcha-anchor-label']")

        driver.switch_to.default_content()
        return True

    except:
        driver.switch_to.default_content()
        return False


def search_drug(driver, wait, Generic_Name, mode_qty, drug_name, form_value, dosage_value, quantity_value,zipcode):
    # 1st - again search drug name here for same pincode
    wrappers = wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div.location-wrapper")))
    time.sleep(2)
    drug_wrapper = wrappers[1]
    driver.execute_script("arguments[0].click();", drug_wrapper)
    time.sleep(2)
    drug_input = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[contains(@class,'rbt-input')]")))
    time.sleep(1)
    # driver.execute_script("arguments[0].focus();", drug_input)
    # drug_name = "Tadalafil"
    drug_name = drug_name
    drug_input.send_keys(drug_name)
    # drug_input.send_keys("Tadalafil")
    time.sleep(3)
    # Click first suggestion
    first_option = driver.find_element(By.XPATH, "//div[@id='drugsearch'][@role='listbox']//a[1]")
    time.sleep(2)
    first_option.click()
    driver.execute_script("window.scrollBy(0,200);")
    time.sleep(1)
    driver.execute_script("window.scrollBy(0,-120);")
    time.sleep(1)
    # 2nd alter clicking drug must select search button for result ealse in below drop down you may not get require filds.
    search_btn = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@class='row']//button[@type='submit']")))
    driver.execute_script("arguments[0].click();", search_btn)
    time.sleep(6)

    if is_captcha_present(driver):
        print("Captcha appeared")
        time.sleep(1)
        #give time to solve captch continue with current values

        # here may be captch solving provide
        search_drug(driver, wait, Generic_Name, mode_qty, drug_name, form_value, dosage_value, quantity_value,zipcode)
    else:
        print("No captcha.. pass for next move")
        # continue next step

    # options select for type and amount of dosage
    last_request = None
    # form_value = "Tablet"
    # dosage_value = "5MG"
    # quantity_value = "30"
    file_hash = f"{zipcode}{drug_name}{form_value}{dosage_value}{quantity_value}"
    hash_value = hashlib.sha256(file_hash.encode()).hexdigest()
    print(f"search drug : {drug_name} \n dosage_value : {dosage_value} \n hash key : ", hash_value)
    try:
        select_drop_down_value(wait, 1, form_value)
    except:
        pass
    try:
        select_drop_down_value(wait, 2, dosage_value)
    except:
        pass
    # try:
    select_drop_down_value(wait, 3, quantity_value)
    # except:
    #     pass
    time.sleep(1)
    update_btn = wait.until(EC.presence_of_element_located((By.XPATH, '//button[@class="btn-sm btn-update"]')))
    driver.execute_script("arguments[0].click();", update_btn)
    time.sleep(5)
    if is_captcha_present(driver):
        print("Captcha appeared")
        # here may be captch solving provide
        search_drug(driver, wait, Generic_Name, mode_qty, drug_name, form_value, dosage_value, quantity_value,zipcode)
    else:
        print("No captcha.. pass for next move")
        # continue next step
    # ==============================
    # Capture Network Logs
    # ==============================
    requests_list = list(driver.requests)
    for request in requests_list:
        if request.response:
            if "search?drugname" in request.url:
                last_request = request

    request = last_request
    body = request.response.body
    if request.response.headers.get('Content-Encoding') == "gzip":
        body = gzip.decompress(body)
    response_json = json.loads(body.decode('utf-8'))
    if request.body:
        print("paylod : ", request.body.decode())
    # print("response : ")
    # print(request.response.body.decode())
    data_to_save = {
        "url": request.url,
        "zipcode":zipcode,
        "method": request.method,
        "request_headers": dict(request.headers),
        "response_headers": dict(request.response.headers),
        "response_json": response_json
    }
    print("=" * 50)
    pagesave_path = fr"{db.drug_pagesave_path}\{hash_value}.json"
    with open(pagesave_path, "w", encoding="utf-8") as f:
        json.dump(data_to_save, f, indent=4)
    print("Saved successfully ✅")
    try:
        item = dict()
        item["generic_name"] = Generic_Name
        item["mode_quantity"] = mode_qty
        item["drug_name"] = drug_name
        item["form"] = form_value
        item["dosage"] = dosage_value
        item["quantity"] = quantity_value
        item["zipcode"] = zipcode
        item["pagesave_path"] = pagesave_path
        item["hash_key"] = hash_value
        try:
            pagesave_insert_records(item)
        except:
            print("issue in insertion or update...")
    except Exception as e:
        print("db_insertion error",e)
    time.sleep(3)
    driver.requests.clear()
    # ==============================
    # Print Results
    # ==============================


# ===================================
# read input from db and take drug name and realvent inputs
# ===================================
query_select = f"select * from {db.input_Data_table} where status='pending' and zipcode='10001' limit 5"
db.cur.execute(query_select)
all_data = db.cur.fetchall()

# df = pd.read_excel(fr"G:\Projects\Mansi\projects\visoyhealth\Process.xlsx", sheet_name="Input")
# ==============================
# Start Undetected Chrome
# ==============================

options = uc.ChromeOptions()
options.add_argument("--start-maximized")
options.add_argument("--ignore-certificate-errors")
options.add_argument("--ignore-ssl-errors")
options.add_argument("--allow-insecure-localhost")
options.add_argument("--disable-web-security")
# extension path
# extension_path = r"C:\Users\Admin\Downloads\anticaptcha-plugin_v0.83"
# options.add_argument(f"--load-extension={extension_path}")
# options.add_argument(f"--disable-extensions-except={extension_path}")
seleniumwire_options = {
    'verify_ssl': False, 'suppress_connection_errors': True
}
driver = Chrome(options=options, seleniumwire_options=seleniumwire_options, version_main=145)
driver.get("chrome://extensions/")
time.sleep(10)
driver.get("https://www.visoryhealth.com/")
# ==============================
# 1️⃣ Click "Customer"
# ==============================
wait = WebDriverWait(driver, 30)
driver.execute_script("document.body.style.zoom='100%'")

customer_btn = wait.until(
    EC.presence_of_element_located(
        (By.XPATH, "//div[contains(text(),'Customer')]")
    )
)
time.sleep(2)
customer_btn.click()
try:
    customer_btn.click()
except:
    pass
print("Clicked Customer")

# Wait until modal disappears
wait.until(
    EC.invisibility_of_element_located(
        (By.XPATH, "//div[contains(text(),'Tell us about yourself')]")
    )
)
# ==============================
# Enter ZIP Code
# ==============================
zip_wrapper = wait.until(
    EC.presence_of_element_located(
        (By.CSS_SELECTOR, "div.location-wrapper")
    )
)
time.sleep(2)

driver.execute_script("arguments[0].click();", zip_wrapper)

# ==============================
# Step 2: Wait for input to appear
# ==============================

zip_input = wait.until(
    EC.visibility_of_element_located(
        (By.CSS_SELECTOR, "input.rbt-input-main")
    )
)
time.sleep(2)

# ==============================
# Step 3: Enter ZIP
# ==============================
zipcode = "10001"
zip_input.send_keys(zipcode)
time.sleep(2)
# Click first suggestion
first_option = driver.find_element(By.XPATH, "//div[@id='zipcode'][@role='listbox']//a[1]")
time.sleep(2)
first_option.click()

time.sleep(2)
driver.requests.clear()

# drug_name list
# drug_name = ["Tadalafil",]
# ==============================
# Enter Drug Name
# ==============================

drug_wrapper = wait.until(EC.presence_of_element_located(
    (By.XPATH, "//span[text()='Type your drug name here']/ancestor::div[contains(@class,'location-wrapper')]")))
time.sleep(2)
driver.execute_script("arguments[0].click();", drug_wrapper)
time.sleep(2)
drug_input = wait.until(EC.visibility_of_element_located((By.XPATH, "//input[contains(@class,'rbt-input')]")))
time.sleep(1)
# driver.execute_script("arguments[0].focus();", drug_input)
drug_name = "Tadalafil"
drug_input.send_keys(drug_name)
# drug_input.send_keys("Tadalafil")
time.sleep(3)
# Click first suggestion
first_option = driver.find_element(By.XPATH, "//div[@id='drugsearch'][@role='listbox']//a[1]")
time.sleep(2)

first_option.click()
time.sleep(2)

# before button click we can get search basic request response that header has "pbm-subscription-key" this key
# ==============================
# Capture Network Logs
# ==============================
last_request = None
requests_list = list(driver.requests)
for request in requests_list:
    if request.response:
        if "search?query" in request.url:
            last_request = request
if last_request:
    request = last_request
    body = request.response.body

    if request.response.headers.get('Content-Encoding') == "gzip":
        body = gzip.decompress(body)
    response_json = json.loads(body.decode('utf-8'))
    if request.body:
        print("paylod : ", request.body.decode())
    # print("response : ")
    # print(request.response.body.decode())
    data_to_save = {
        "url": request.url,
        "method": request.method,
        "request_headers": dict(request.headers),
        "response_headers": dict(request.response.headers),
        "response_json": response_json
    }
    print("=" * 50)
    with open("search_result1.json", "w", encoding="utf-8") as f:
        json.dump(data_to_save, f, indent=4)

    print("Saved successfully ✅")
driver.requests.clear()

# Click Search Button
time.sleep(2)

search_btn = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@class='row']//button[@type='submit']")))
driver.execute_script("arguments[0].click();", search_btn)
time.sleep(6)
if is_captcha_present(driver):
    print("Captcha appeared")
    # here may be captch solving provide
    # search_drug(driver,wait,drug_name,form_value,dosage_value,quantity_value)
else:
    print("No captcha.. pass for next move")
    # continue next step
# for index, rows in df.iterrows():
for rows in all_data:
    print(rows)
    Generic_Name = rows["generic_name"]
    mode_qty = rows["mode_quantity"]
    drug_name = rows["drug_name"]
    form_value = rows["form"]
    dosage_value = rows["dosage"]
    quantity_value = int(rows["quantity"])
    search_drug(driver, wait,Generic_Name, mode_qty, drug_name, form_value, dosage_value, quantity_value, zipcode)

# driver.close()
# driver.quit()


###########pending 2nd request do
