import hashlib
import os
from datetime import datetime
import pymysql
import pandas as pd


year_month = datetime.now().strftime("%Y%m")
input_Data_table = f"drug_data_{year_month}_new"
pagesave_pdp_table = f"drug_pdp_page_{year_month}"
drug_pagesave_path = fr"E:\Mansi\pagesave\visoryhealth\{year_month}_1\drug_search_page"
os.makedirs(drug_pagesave_path,exist_ok=True)

#connection_String
conn = pymysql.connect(host="localhost",user="root",database="visoyhealth",cursorclass=pymysql.cursors.DictCursor)
cur = conn.cursor()

#creat_data table

def create_table_pdp():
    table_creation = f'''CREATE TABLE IF NOT EXISTS {pagesave_pdp_table}(
    id INT AUTO_INCREMENT PRIMARY KEY,
    generic_name VARCHAR(255),
    mode_quantity VARCHAR(255),
    drug_name VARCHAR(255),
    form VARCHAR(255),
    dosage VARCHAR(255),
    quantity VARCHAR(255),
    zipcode VARCHAR(255),
    pagesave_path varchar(255),
    hash_key varchar(255)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;'''

    cur.execute(table_creation)
    conn.commit()

create_table_pdp()

#
# def create_table():
#     table_creation = f"""CREATE TABLE IF NOT EXISTS {input_Data_table} (
#     id INT AUTO_INCREMENT PRIMARY KEY,
#     generic_name VARCHAR(255),
#     mode_quantity VARCHAR(255),
#     drug_name VARCHAR(255),
#     form VARCHAR(255),
#     dosage VARCHAR(255),
#     quantity VARCHAR(255),
#     zipcode VARCHAR(200),
#     status VARCHAR(50) DEFAULT 'pending') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"""
#     cur.execute(table_creation)
#     conn.commit()
#
# create_table()
# df = pd.read_excel(fr"E:\Mansi\input_visory_mearge_pincode.xlsx",sheet_name="Input", keep_default_na=False)
# insert_query = f""" Insert INTO {input_Data_table} (generic_name, mode_quantity, drug_name, form, dosage, quantity, zipcode) values (%s, %s, %s, %s, %s, %s, %s)"""
#
# value_list = []
# for _, rows in df.iterrows():
#     generic_name = rows["Generic Name"]
#     mode_quantity = rows["MODE QUANTITY"]
#     drug_name = rows["Drug Name"]
#     form = rows["Form"]
#     dosage = rows["Doasge"]
#     quantity = rows["Quantity"]
#     zipcode = rows["zipcode"]
#
#     value_list.append((generic_name, mode_quantity, drug_name, form, dosage, quantity, zipcode))
#
# cur.executemany(insert_query,value_list)
# conn.commit()
def insert_record(item):
    pass