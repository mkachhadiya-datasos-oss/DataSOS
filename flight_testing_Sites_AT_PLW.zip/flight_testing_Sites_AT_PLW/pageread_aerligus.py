#step2 ,reading from to page and mane file for perticuler destination like from london to new yourk
# scrpit is not complated like path managment pending do dont run blindly frist manage all path in it as in file_api_resting.py

import time
from datetime import datetime
import os
import json
from urllib.parse import unquote
import pandas as pd

pageread_path = fr"E:\Mansi\projects\flight_testing_Sites\pagesave_flight_api"


def gbp_to_usd(price_gbp, rate=1.28):
    return round(price_gbp * rate, 2)

def insert_db(response_item):
    pass

main_data_list = list()


def fetch_data(data_info, source, destination):
    for data_list in data_info:
        url = data_list.get("url", "")
        data_from_url = "".join(url.split("departureDate=")[-1].split("&numYouths")[0]).replace("/","-").replace("/", "-")
        # now onw page has many date so date wise data_list entry for one page like today data and it's all flight details
        data = data_list.get("response_json", "").get("data", "")
        try:
            message = data.get("journey", "").get("outbound", "").get("message", "")
            if message and message.get("code") == "SOLD_OUT":
                print("flight sold out for date :", data_from_url)
            else:
                # flight loop [this has all timing flight detail]
                flights = data["journey"]["outbound"]["flights"]
                for flight in flights:
                    # if stop count =1 "direct flight" if stop count = 2 "1 stop" , if stop count = 3 "2 stop" if stop count > 3 "2+stop"
                    stop_count = 0
                    time_departure = []
                    time_arrival = []
                    for tip in flight["trips"]:
                        departure = tip["departure"]["date"]
                        arrival = tip["arrival"]["date"]
                        dt = datetime.strptime(departure, "%Y-%m-%dT%H:%M:%S.%f")
                        time_departure.append(dt.strftime("%H:%M"))
                        at = datetime.strptime(arrival, "%Y-%m-%dT%H:%M:%S.%f")
                        time_arrival.append(at.strftime("%H:%M"))
                        stop_count += 1
                    final_departure = time_departure[0]
                    final_arrival = time_arrival[-1]
                    final_stop = "Direct flight" if stop_count == 1 else f"{stop_count - 1} stop" if stop_count <= 3 else "2+ stop"

                    # price and class iteration
                    for price_class in flight["priceInfo"]["fares"]:
                        # becasue if basis codes not provided then flight unavailable or that class is unavailable
                        if price_class["basisCodes"]:
                            class_ = price_class["type"]
                            price = gbp_to_usd(price_class["price"])

                            item = dict()
                            item["Airline"] = "aerlingus"
                            item["Route-From"] = source
                            item["Route-To"] = destination
                            item["DOT"] = data_from_url
                            item["Class"] = class_
                            item["Category"] = final_stop
                            item["Time-Departure"] = final_departure
                            item["Time-Arrival"] = final_arrival
                            item["Number of Traveller"] = "1"
                            item["Price ($)"] = price
                            main_data_list.append(item)








        except Exception as e:
            print(e)


for file_name in os.listdir(pageread_path):
    if file_name.endswith(".json"):
        file_path = os.path.join(pageread_path, file_name)
        with open(file_path, "r", encoding="UTF-8") as json_file:
            # here one page has many dates around 10 dates so iterate page wise page 1 then page 2 and so on
            data_info = json.load(json_file)

        encoded_value = data_info[2]["cookies"][32]["value"]
        encode_v = next(value["value"] for value in data_info[2]["cookies"] if value["name"] == "latest_search")
        # decode it
        decoded_value = unquote(encoded_value)
        search_value = json.loads(decoded_value)
        source = search_value["flightJourneySearches"][0]["sourceAirportLabel"]
        destination = search_value["flightJourneySearches"][0]["destinationAirportLabel"]

        response_item = fetch_data(data_info, source, destination)
        # insert_db(response_item)

df = pd.DataFrame.from_dict(main_data_list)
df.to_excel("main_data.xlsx")
