# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html
from dataclasses import fields

import scrapy


class IcrimewatchOhSorItem(scrapy.Item):
    def __setitem__(self, key, value):
        if key not in self.values():
            self.fields[key] = scrapy.Field()
            self._values[key] = value
