import re
from pathlib import Path
from scrapy.cmdline import execute
import ICrimeWatch_OH_SOR.db_config as db
from ICrimeWatch_OH_SOR.db_config import clean_text
from ICrimeWatch_OH_SOR.items import *

class PdpPagereadSpider(scrapy.Spider):
    name = "pdp_pageread"
    conn, cur = db.conn_()

    # allowed_domains = ["www.icrimewatch.net"]
    # start_urls = ["https://www.icrimewatch.net/results.php"]
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
    def start_requests(self):
        query = f"select * from {db.INDEX_TABLE} where status='done' and status_photo='done'"
        self.cur.execute(query)
        records = self.cur.fetchall()
        for data in records:
            id_ = data["id"]
            offender_id = data["offender_id"]
            pdp_url = data["pdp_url"]
            photo_url = data["photo_url"]
            pdp_path = fr"{db.DETAIL_PATH}\{offender_id}.html"
            file_path = Path(pdp_path).as_uri()
            yield scrapy.Request(url=file_path,callback=self.parse,dont_filter=True,cb_kwargs={
                "id_":id_,"pdp_url":pdp_url,"photo_url":photo_url,"offender_id":offender_id})

    def parse(self, response,**kwargs):
        id_ = kwargs["id_"]
        file_id = kwargs["offender_id"]
        pdp_url = kwargs["pdp_url"]
        photo_url = kwargs["photo_url"]
        basic_detail_table = response.xpath('//h2[contains(text(),"Offender Details")]/following-sibling::table//tr/td/table[1]')
        if basic_detail_table.get():
            #name
            name = basic_detail_table.xpath('.//td[./span[@class="nameTitle"]]/following-sibling::td/span[@class="nameTitle"]/text()').get()
            if name:
                name = db.clean_text(name)
            else:
                name = None

            #registration
            registration = basic_detail_table.xpath('.//td[./strong[contains(text(),"Registration")]]/following-sibling::td/text()').get()
            if registration:
                registration = db.clean_text(registration)
            else:
                registration = None

            #aliases
            aliases = basic_detail_table.xpath('.//td[.//strong[contains(text(),"Aliases")]]/following-sibling::td/span[@class="nameContent"]/text()').get()
            if aliases:
                aliases = clean_text(aliases)
            else:
                aliases = None

            #level
            level = basic_detail_table.xpath('.//td[./strong[contains(text(),"Level")]]/following-sibling::td/text()').getall()
            if level:
                level = clean_text(" ".join(level))
            else:
                level = None


        #address and physical description
        physical_address_table = response.xpath('//h2[contains(text(),"Offender Details")]/following-sibling::table//tr/td/table[2]')
        if physical_address_table.get():
            #age
            age = physical_address_table.xpath('.//td[./strong[contains(text(),"Age")]]/following-sibling::td/text()').get()
            if age:
                age = clean_text(age)
            else: age = None
            #height
            height = physical_address_table.xpath('.//td[./strong[contains(text(),"Height")]]/following-sibling::td/text()').get()
            if height:
                height = clean_text(height)
            else: height = None

            #sex
            sex = physical_address_table.xpath('.//td[./strong[contains(text(),"Sex")]]/following-sibling::td/text()').get()
            if sex:
                sex = clean_text(sex)
            else: sex = None

            #weight
            weight = physical_address_table.xpath('.//td[./strong[contains(text(),"Weight")]]/following-sibling::td/text()').get()
            if weight:
                weight = clean_text(weight)
            else: weight = None
            #race
            race = physical_address_table.xpath('.//td[./strong[contains(text(),"Race")]]/following-sibling::td/text()').get()
            if race:
                race = clean_text(race)
            else: race = None
            #eyes
            eyes = physical_address_table.xpath('.//td[./strong[contains(text(),"Eyes")]]/following-sibling::td/text()').get()
            if eyes:
                eyes = clean_text(eyes)
            else: eyes = None

            #hair
            hair = physical_address_table.xpath('.//td[./strong[contains(text(),"Hair")]]/following-sibling::td/text()').get()
            if hair:
                hair = clean_text(hair)
            else:
                hair = None
            #scar/tattos
            scars = physical_address_table.xpath('.//td[./strong[contains(text(),"Scars/Tattoos")]]/following-sibling::td/text()').get()
            if scars:
                scars = clean_text(scars)
            else: scars = None

            #//tr[td[./span[contains(text(),"Address")]]]/following-sibling::tr/text()
            #address
            address = physical_address_table.xpath('.//tr[td/span[contains(text(),"Address")]]/following-sibling::tr[1]/td[1]/text()').getall()
            if address:
                address = clean_text(" ".join(address))
            else:
                address = None

        offences = response.xpath('//td[./strong/span[contains(text(),"Description:")]]')
        total_offences = len(offences)

        #comments
        comments = response.xpath('//td[@class="sectionHeading"]/span[contains(normalize-space(.),"Comments")]/ancestor::tr/following-sibling::tr/td/text()').get()
        if comments:
            comments = clean_text(comments)
        else:
            comments = None
        # registration status
        registration_status = response.xpath('//img[@src="images/nonCompliant.jpg"]').get()
        if registration_status:
            registration_status = "Non-compliant"
        else:
            registration_status = None

        #photo
        photo = f"{file_id}.jpg"

        #work address
        work_address = response.xpath('//td/strong[contains(normalize-space(.),"Work Addresses")]/ancestor::tr/following-sibling::tr//blockquote//tr/td[1]/text()').getall()
        if work_address:
            work_address = clean_text(" ".join(work_address))
        else:
            work_address = None

        # school address
        school_address = response.xpath(
            '//td/strong[contains(normalize-space(.),"School Addresses")]/ancestor::tr/following-sibling::tr[1]//blockquote//tr/td[1]/text()').getall()
        if school_address:
            school_address = clean_text(" ".join(school_address))
        else:
            school_address = None

        #volunter address
        volunter_address = response.xpath('//td/strong[contains(normalize-space(.),"Volunteer Addresses")]/ancestor::tr/following-sibling::tr[1]//blockquote//tr/td[1]/text()').getall()
        if volunter_address:
            volunter_address =clean_text(" ".join(volunter_address))
        else:
            volunter_address = None

        #other address
        other_address = response.xpath('//td/strong[contains(normalize-space(.),"Other Residential Addresses")]/ancestor::tr/following-sibling::tr//blockquote//tr/td[1]/text()').getall()
        if other_address:
            other_address = clean_text(" ".join(other_address))
        else:
            other_address = None

        #victime classefication
        victim_classification = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.),"Primary Victim classification")]]/following-sibling::td/text()').get()
        if victim_classification:
            victim_classification = clean_text(victim_classification)
        else: victim_classification = None

        #victime age
        victim_age = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.)," Age of victim at time of crime")]]/following-sibling::td/text()').get()
        if victim_age:
            victim_age = clean_text(victim_age)
        else: victim_age = None

        #gender of victime
        victim_gender = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.)," Gender of victim")]]/following-sibling::td/text()').get()
        if victim_gender:
            victim_gender = clean_text(victim_gender)
        else:victim_gender = None

        #race of victime
        victim_race = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.)," Race of victim")]]/following-sibling::td/text()').get()
        if victim_race:
            victim_race = clean_text(victim_race)
        else: victim_race = None

        #victime_note
        victim_note = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.),"Notes")]]/following-sibling::td/text()').get()
        if victim_note:
            victim_note = clean_text(victim_note)
        else: victim_note = None

        #victim_relation
        victim_relation = response.xpath('//td//span[contains(normalize-space(.),"Victim Info")]/ancestor::tr/following-sibling::tr/td[./strong[contains(normalize-space(.),"relationship to offender")]]/following-sibling::td/text()') .get()
        if victim_relation:
            victim_relation = clean_text(victim_relation)
        else: victim_relation = None

        offense_rows = response.xpath(
            '//td[@class="sectionHeading"]//span[contains(.,"Offenses")]'
            '/ancestor::tr/following-sibling::tr'
        )

        offenses = []
        current_offense = None
        label_mapping = {
            "Description": "Description",
            "Date Convicted": "Date_Convicted",
            "Conviction State": "Conviction_State",
            "Release Date": "Release_Date",
            "Details": "Details",
            "State Equivalent": "State_Equivalent"
        }
        for row in offense_rows:
            # skip unrelated rows
            if not row.xpath('.//span[@class="offenseLabel"]'):
                continue
            label = row.xpath(
                'normalize-space(.//span[@class="offenseLabel"])'
            ).get()

            value = row.xpath(
                'normalize-space(./td[last()])'
            ).get()
            label = re.sub(r'[^\x00-\x7F]+', '', label)
            if label:
                label = (
                    label.replace(r"\Uffffffff", "")
                    .replace(":", "")
                    .strip()
                )

            value = value.strip() if value else None
            clean_label = label_mapping.get(label)
            # New offense starts
            if clean_label == "Description":

                # save previous offense
                if current_offense:
                    offenses.append(current_offense)

                current_offense = {
                    "Description": value,
                    "Date_Convicted": None,
                    "Conviction_State": None,
                    "Release_Date": None,
                    "Details": None,
                    "State_Equivalent": None
                }

            elif current_offense and clean_label in current_offense:
                current_offense[clean_label] = value or None
        # append last offense
        if current_offense:
            offenses.append(current_offense)
        total_offences_count = 1
        if offenses and len(offenses) > 0:
            for offense in offenses:
                item =IcrimewatchOhSorItem()
                # -------------------------
                # BASIC DETAILS
                # -------------------------
                item["id_"] = id_
                item["file_id"] = file_id
                item["pdp_url"] = pdp_url
                item["photo_url"] = photo_url
                item["name"] = name
                item["registration"] = registration
                item["aliases"] = aliases
                item["level"] = level

                # -------------------------
                # PHYSICAL
                # -------------------------
                item["age"] = age
                item["height"] = height
                item["sex"] = sex
                item["weight"] = weight
                item["race"] = race
                item["eyes"] = eyes
                item["hair"] = hair
                item["scars"] = scars

                # -------------------------
                # ADDRESS
                # -------------------------
                item["address"] = address
                item["work_address"] = work_address
                item["school_address"] = school_address
                item["volunter_address"] = volunter_address
                item["other_address"] = other_address

                # -------------------------
                # COMMENTS
                # -------------------------
                item["comments"] = comments
                item["registration_status"] = registration_status

                #---------------------------
                # offencecount
                item["total_offences_count"] = total_offences_count
                # -------------------------
                # -------------------------
                # VICTIM INFO
                # -------------------------
                item["victim_classification"] = victim_classification
                item["victim_age"] = victim_age
                item["victim_gender"] = victim_gender
                item["victim_race"] = victim_race
                item["victim_note"] = victim_note
                item["victim_relation"] = victim_relation

                # -------------------------
                # OFFENSE INFO
                # -------------------------
                item["Description"] = offense.get("Description")
                item["Date_Convicted"] = offense.get("Date_Convicted")
                item["Conviction_State"] = offense.get("Conviction_State")
                item["Release_Date"] = offense.get("Release_Date")
                item["Details"] = offense.get("Details")
                item["State_Equivalent"] = offense.get("State_Equivalent")
                total_offences_count+=1
                yield item









if __name__ == "__main__":
    execute("scrapy crawl pdp_pageread".split())
