# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
from ICrimeWatch_OH_SOR.items import *
import ICrimeWatch_OH_SOR.db_config as db
# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

class IcrimewatchOhSorPipeline:
    conn, cur = db.conn_()

    def insert_item(self,item,table_name,parent_table):
        id_ = item.pop("id_")
        keys = ", ".join(item.keys())
        values = tuple(item.values())
        placeholder = ", ".join(["%s"] * len(item))
        try:
            query = f"insert into {table_name} ({keys}) values ({placeholder})"
            self.cur.execute(query, values)
            self.conn.commit()
        except Exception as e:
            print("issue in insertion.....", e)
        try:
            update_query = f"update {parent_table} set status='page_read' where id= %s"
            self.cur.execute(update_query, (id_,))
            self.conn.commit()
        except Exception as e:
            print("issue in data updation .....", e)

    def process_item(self, item, spider):
        if isinstance(item,IcrimewatchOhSorItem):
            self.insert_item(item,db.DETAIL_TABLE,db.INDEX_TABLE)
        return item
