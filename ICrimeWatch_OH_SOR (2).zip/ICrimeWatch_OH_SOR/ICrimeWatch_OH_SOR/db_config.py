import pymysql
from datetime import datetime
import os
import re

year_month = datetime.now().strftime("%Y_%m")
year_month_month = datetime.now().strftime("%Y_%m_%B")
current_date = datetime.now().strftime("%m%d%Y")
day = datetime.now().day
if int(day) < 15:
    file_ = 1
elif int(day) >= 15:
    file_ = 2
else:
    file_ = 0

#=============table names====================
database_name = f"ICrimeWatch_{year_month}"
INDEX_LINK_INPUT_TABLE = f"index_link_table"
INDEX_TABLE = f"plp_table"
DETAIL_TABLE = f"pdp_table"

#=============page save config============================
state_name = "OH"
layout_name = "ICrimeWatch"
frequency = "Bi-Weekly"
rar_file_prefix = "SOR"
file_type = "MFF"
start_date = "NA"
end_date = "NA"

CODE_PATH = fr"D:\Scrapes\Code"
DATA_PATH = fr"D:\Scrapes\Data"
os.makedirs(CODE_PATH,exist_ok=True)
os.makedirs(DATA_PATH,exist_ok=True)


#output file
PARSE_PATH = fr"{DATA_PATH}\{state_name}\{layout_name}\{year_month_month}_File{file_}\Parse"
os.makedirs(PARSE_PATH,exist_ok=True)

#parse file name
OUTPUT_FILE_PATH = fr"{PARSE_PATH}\{state_name}_{rar_file_prefix}_{file_type}_{current_date}_FROM_{start_date}_TO_{end_date}.xlsx"

#detail pagesave - main folder for (PDP,Assets,Photos,CAPTCHA Images)
SCRAPE_PATH = fr"{DATA_PATH}\{state_name}\{layout_name}\{year_month_month}_File{file_}\Scrape"
os.makedirs(SCRAPE_PATH,exist_ok=True)

#Index pagesave (PLP)
INDEX_PATH = fr"{SCRAPE_PATH}\Index"
os.makedirs(INDEX_PATH,exist_ok=True)

#detail pagesave (PDP)
DETAIL_PATH = fr"{SCRAPE_PATH}\Pages"
os.makedirs(DETAIL_PATH,exist_ok=True)

PHOTO_PATH = fr"{SCRAPE_PATH}\Photos"
os.makedirs(PHOTO_PATH,exist_ok=True)

#===============================================

def clean_text(text):
    if not text:
        return None
    text = re.sub(r"\s+"," ",text)
    return text

def pagesave_data(response,file_path):
    if "pdp" in file_path or ".html" in file_path:
        with open(file_path,"w",encoding="utf-8") as f:
            f.write(response.text)
    else:
        with open(file_path,"wb") as f:
            f.write(response.content)

def create_db():
    conn = pymysql.connect(host="localhost", user="root")
    cur = conn.cursor()
    query = f"Create database if not exists {database_name}"
    cur.execute(query)
    conn.commit()

def conn_():
    conn = pymysql.connect(host="localhost",user="root",database=database_name,cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    return conn, cur
create_db()
conn,cur = conn_()

def index_url_table():
    query = f"""CREATE TABLE IF NOT EXISTS index_link_table (
                    id int auto_increment primary key,
                    index_url varchar(250),
                    page_no int,
                    status varchar(30) default "pending",
                    index index_on (page_no),
                    unique unique_key (index_url)
                    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()

def pagesave_table_Create():
    query = f"""Create table if not exists {INDEX_TABLE} (
                    id int auto_increment primary key,
                    plp_url varchar(250),
                    page_no int,
                    pdp_url varchar(255),
                    offender_id varchar(200),
                    photo_url text,
                    status varchar(50) default "pending",
                    status_photo varchar(50) default "pending",
                    INDEX index_value (plp_url),
                    constraint unique_value unique (offender_id)
            )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()


#final data table
def pdp_data_table():
    query = f"""CREATE TABLE IF NOT EXISTS {DETAIL_TABLE} (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    file_id VARCHAR(255),
    pdp_url VARCHAR(500),
    photo_url VARCHAR(500),
    name VARCHAR(255),
    registration VARCHAR(255),
    aliases VARCHAR(500),
    level VARCHAR(255),
    age VARCHAR(100),
    height VARCHAR(100),
    sex VARCHAR(50),
    weight VARCHAR(100),
    race VARCHAR(100),
    eyes VARCHAR(100),
    hair VARCHAR(100),
    scars TEXT,
    address VARCHAR(500),
    work_address VARCHAR(500),
    school_address VARCHAR(500),
    volunter_address VARCHAR(500),
    other_address VARCHAR(500),
    comments TEXT,
    registration_status VARCHAR(255),
    total_offences_count VARCHAR(10),
    victim_classification VARCHAR(255),
    victim_age VARCHAR(255),
    victim_gender VARCHAR(255),
    victim_race VARCHAR(255),
    victim_note TEXT,
    victim_relation VARCHAR(255),
    Description TEXT,
    Date_Convicted VARCHAR(255),
    Conviction_State VARCHAR(255),
    Release_Date VARCHAR(255),
    Details TEXT,
    State_Equivalent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )engine=InnoDB charset=utf8mb4 collate=utf8mb4_unicode_ci;"""
    cur.execute(query)
    conn.commit()

index_url_table()
pagesave_table_Create()
pdp_data_table()

# def insert_item(item,table_name):
#     conn, cur = conn_()
#     keys = ", ".join(item.keys())
#     values = tuple(item.values())
#     placeholder = ", ".join(["%s"] * len(item))
#     query = f"insert into {table_name} ({keys}) values ({placeholder})"
#     cur.execute(query,values)
#     conn.commit()
#     cur.close()
#     conn.close()