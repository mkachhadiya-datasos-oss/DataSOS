import ICrimeWatch_OH_SOR.db_config as db
import pandas as pd
conn, cur = db.conn_()
query = f"select * from {db.DETAIL_TABLE}"
cur.execute(query)
data = cur.fetchall()
columns = [col[0] for col in cur.description]

df = pd.DataFrame(data,columns=columns)
df.drop_duplicates(keep="last",inplace=True)

with pd.ExcelWriter(db.OUTPUT_FILE_PATH,engine="xlsxwriter") as writer:
    total_records = len(df)
    writer.book.strings_to_urls = False
    df.to_excel(writer,index=False)


