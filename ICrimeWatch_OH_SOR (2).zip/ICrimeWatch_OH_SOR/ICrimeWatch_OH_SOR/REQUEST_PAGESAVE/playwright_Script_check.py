from playwright.sync_api import sync_playwright
import json
import time
import random
# TARGET_URL = "https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1"

def get_cookie_dict(cookies):
        cookie_dict = {}
        for cookie in cookies:
            cookie_dict[cookie["name"]] = cookie["value"]
        return cookie_dict

def collect_cookies(pdp_url):
    with sync_playwright() as p:

        browser = p.chromium.launch(
            headless=False,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--start-maximized",
                "--disable-dev-shm-usage",
                "--no-sandbox",
            ]
        )

        context = browser.new_context(
            viewport={"width": 1366, "height": 768},
            user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
            locale="en-US",
            timezone_id="America/New_York"
        )

        page = context.new_page()

        # Remove webdriver detection
        page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
    
            window.chrome = {
                runtime: {}
            };
    
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
    
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US', 'en']
            });
        """)
        print("Opening target page...")

        page.goto(
            pdp_url,
            wait_until="networkidle",
            timeout=120000
        )
        # Human-like wait
        time.sleep(random.uniform(4,5))
        # Get cookies
        cookies = context.cookies()
        cookie_dict = get_cookie_dict(cookies)
        print("\n===== ALL COOKIES =====\n")
        print(json.dumps(cookie_dict, indent=4))
        print("\nCurrent URL:")
        print(page.url)

        # input("\nPress ENTER to close browser...")

        browser.close()
        # time.sleep(300)
        return cookie_dict


if __name__ == "__main__":
    # collect_cookies('https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
    collect_cookies('https://www.icrimewatch.net/offenderdetails.php?OfndrID=6625253&AgencyID=55149')


