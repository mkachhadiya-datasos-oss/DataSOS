from curl_cffi import requests
from concurrent.futures import ThreadPoolExecutor
from ICrimeWatch_OH_SOR.REQUEST_PAGESAVE.playwright_Script_check import *
import ICrimeWatch_OH_SOR.db_config as db
from parsel import Selector
start_time = time.time()
cookies_dict = collect_cookies('https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
cookies = { 'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
    'datadome': f'{cookies_dict.get("datadome")}'}
def update_record(page):
    try:
        query_update = f"update {db.INDEX_LINK_INPUT_TABLE} set status='done' where page_no={page}"
        cur.execute(query_update)
        conn.commit()
    except Exception as e:
        print("update issue :",page,e)
def insert_item(item,table_name):
    keys = ", ".join(item.keys())
    values = tuple(item.values())
    placeholder = ", ".join(["%s"] * len(item))
    try:
        query = f"insert into {table_name} ({keys}) values ({placeholder})"
        cur.execute(query,values)
        conn.commit()
    except Exception as e:
        print(str(e))
def fetch_result(page):
    global cookies
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Referer': f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrCity=&OfndrLast=%27%25%27&OfndrFirst=%27%25%27&level=&AllCity=&altaddr=home_addr&excludeIncarcerated=0&page={page}',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
        'sec-ch-device-memory': '8',
        'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-arch': '"x86"',
        'sec-ch-ua-full-version-list': '"Google Chrome";v="147.0.7727.101", "Not.A/Brand";v="8.0.0.0", "Chromium";v="147.0.7727.101"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Linux"',
    }
    url=f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}'
    for i in range(5):
        response = requests.get(
            url = url,
            cookies=cookies,
            headers=headers, impersonate="chrome110",timeout=800000
        )
        print(response.status_code)
        if response.status_code == 200:
            file_path = fr"{db.INDEX_PATH}\{page}.html"
            db.pagesave_data(response,file_path)
            print("pagesave done... for page : ",page)
            response = Selector(response.text)
            records = response.xpath('//table//td//strong[contains(normalize-space(.),"Found 0 offenders")]').get()
            if records:
                cookies_dict = collect_cookies(
                    f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}')
                cookies = {
                    'cf_clearance': f"{cookies_dict.get("cf_clearance")}",
                    'datadome': f'{cookies_dict.get("datadome")}',
                }
                continue
            table_tr = response.xpath('//table[.//tr//*[contains(text(),"View Details")]][@bgcolor="#CCCCCC"]//tr[position()>1]')
            if table_tr.get():

                for tr in table_tr:
                    #lattter transfer this into function
                    pdp_url = tr.xpath('.//td[2]/a/@href').get()
                    offender_id = pdp_url.split("OfndrID=")[-1].split("&AgencyID")[0]
                    photo_url = tr.xpath('.//td[2]/a/img/@src').get()
                    item = dict()
                    item["plp_url"] = url
                    item["page_no"] = page
                    item["pdp_url"] = pdp_url
                    item["offender_id"] = offender_id
                    item["photo_url"] = photo_url
                    insert_item(item,db.INDEX_TABLE)
                update_record(page)

            break
        elif response.status_code == 403:
            cookies_dict = collect_cookies(f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page}')
            cookies = {
                'cf_clearance': f"{cookies_dict.get("cf_clearance")}",
                'datadome': f'{cookies_dict.get("datadome")}',
            }
            continue
#================================================================
'''page no that are missing in sql plp table find thoese number and rerun with thoese pages only '''
def missing_plp_link():
    quesry_select = f"select page_no from {db.INDEX_LINK_INPUT_TABLE} where page_no not in(select page_no from {db.INDEX_TABLE})"
    cur.execute(quesry_select)
    data = cur.fetchall()
    pages = [i.get("page_no") for i in data]
    pages.sort()
    return pages
#=================================================================
''' pages that are not have 30 record in one page those page require rerun'''
def less_pdp_count():
    query_rerun = f"SELECT COUNT(*),page_no FROM {db.INDEX_TABLE} GROUP BY page_no HAVING COUNT(page_no) < 30"
    cur.execute(query_rerun)
    data = cur.fetchall()
    page_no = [int(i.get("page_no")) for i in data]
    return page_no
"""fetch page no from index_link_table and update status"""
def start_function():
    try:
        query_index = f"select page_no from {db.INDEX_LINK_INPUT_TABLE} where status='pending'"
        cur.execute(query_index)
        data = cur.fetchall()
        pages = [i.get("page_no") for i in data]
        return pages
    except Exception as e:
        print(e)
def executor_fun(pages):
    try:
        with ThreadPoolExecutor(max_workers=5) as executor:
            result = list(executor.map(fetch_result,pages))
        for r in result:
            print(r)
        end_time = time.time()
        total_ = end_time - start_time
        print("total from file 3 : ",total_)
    except Exception as e:
        print("Executor having problem :",e)
if __name__ == "__main__":
    conn, cur = db.conn_()
    for i in range(5):
        pages = start_function()
        if len(pages) > 0:
            executor_fun(pages)
        else:break
    cur.close()
    conn.close()
    time.sleep(2)
    conn, cur = db.conn_()
    for i in range(3):
        pages = missing_plp_link()
        if len(pages) > 0:
            executor_fun(pages)
        else:break
    cur.close()
    conn.close()
    time.sleep(2)
    conn, cur = db.conn_()
    for i in range(3):
        pages = less_pdp_count()
        if len(pages) > 0:
            executor_fun(pages)
        else:break
    cur.close()
    conn.close()
