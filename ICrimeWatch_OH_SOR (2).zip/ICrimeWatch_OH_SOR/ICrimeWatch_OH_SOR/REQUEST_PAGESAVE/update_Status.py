import os
from ICrimeWatch_OH_SOR import db_config as db

conn,cur = db.conn_()

query = f"select page_no from {db.INDEX_TABLE}"
cur.execute(query)
data = cur.fetchall()
# print(data)

for file_name in os.listdir(db.INDEX_PATH):
    # print("filename:",file_name,"\n","path_:",db.INDEX_PATH)
    page_no = file_name.split(".html")[0]
    full_path = os.path.join(db.INDEX_PATH,file_name)
    # print( os.path.getsize(full_path))
    if os.path.isfile(full_path):
        size = os.path.getsize(full_path)
        if (size/1024) < 22:
            print(file_name,size)
            qyery1 = f"update {db.INDEX_TABLE} set status_rerun='pending' where page_no={page_no}"
            cur.execute(qyery1)
            conn.commit()
# for page_no in data:
#     index_path_page_no = f"{db.INDEX_PATH}\{page_no.get('page_no')}.html"
#




# ============= if status done and page save not exists ===================
# query = f"select offender_id from {db.INDEX_TABLE} where status='done' and status_photo='done'"
# cur.execute(query)
# records = cur.fetchall()
# print(len(records))
# for id_ in records:
#     ofend_id = id_["offender_id"]
#     path_ = fr"{db.DETAIL_PATH}\{ofend_id}.html"
#     if not os.path.exists(path_):
#         print(ofend_id)
#         update_query = f"update {db.INDEX_TABLE} set status='pending' ,status_photo='pending' where offender_id='{ofend_id}'"
#         cur.execute(update_query)
#         conn.commit()
#     else:
#         print("found :",ofend_id)