from curl_cffi import requests
from parsel import Selector
import re
import math
from ICrimeWatch_OH_SOR.REQUEST_PAGESAVE.playwright_Script_check import *
import ICrimeWatch_OH_SOR.db_config as db
conn, cur = db.conn_()
url=f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1'
cookies_dict = collect_cookies(url)
cookies = { 'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
    'datadome': f'{cookies_dict.get("datadome")}'}
url_list = []
headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Referer': f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrCity=&OfndrLast=%27%25%27&OfndrFirst=%27%25%27&level=&AllCity=&altaddr=home_addr&excludeIncarcerated=0&page=1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
        'sec-ch-device-memory': '8',
        'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-arch': '"x86"',
        'sec-ch-ua-full-version-list': '"Google Chrome";v="147.0.7727.101", "Not.A/Brand";v="8.0.0.0", "Chromium";v="147.0.7727.101"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-model': '""',
        'sec-ch-ua-platform': '"Linux"',
    }
for i in range(5):
    response = requests.get( url = url, cookies=cookies,   headers=headers, impersonate="chrome110",timeout=800000)
    print(response.status_code)
    if response.status_code == 200:
        response = Selector(response.text)
        records = response.xpath('//table//td//strong[contains(normalize-space(.),"Found 0 offenders")]').get()
        if records:
            print("having issue in response.....")
        else:
            record_text = response.xpath(
                '//table[@class="searchArea"]//td/strong[contains(text(),"Found")]/text()').get()
            text_ = db.clean_text(record_text)
            record_ = re.findall(r'\d+', text_)
            record_count = int(record_[0])
            if record_count != 0:
                total_pages =  math.ceil(record_count / 30)
                #after break make sure to iterate loop in this and insert pages into db
                #start
                for num in range(1,round(total_pages)+1):
                    url_list.append((f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={num}',num))
            query1 = f"insert ignore into {db.INDEX_LINK_INPUT_TABLE} (index_url, page_no) values (%s, %s)"
            cur.executemany(query1,url_list)
            conn.commit()
            break
    elif response.status_code == 403:
        cookies_dict = collect_cookies(
            url)
        cookies = {
            'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
            'datadome': f'{cookies_dict.get("datadome")}',
        }
        continue