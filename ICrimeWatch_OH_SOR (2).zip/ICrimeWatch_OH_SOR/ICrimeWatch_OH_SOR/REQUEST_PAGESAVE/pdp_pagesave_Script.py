
from curl_cffi.requests.impersonate import BrowserType
from curl_cffi import requests
from ICrimeWatch_OH_SOR.REQUEST_PAGESAVE.playwright_Script_check import *
import ICrimeWatch_OH_SOR.db_config as db
conn, cur = db.conn_()
start_time = time.time()
impersonate_list = [i.value for i in BrowserType]
cookies_dict = collect_cookies('https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
cookies = {
    'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
    'datadome': f'{cookies_dict.get("datadome")}',
}
#
# def insert_item(item,table_name):
#     keys = ", ".join(item.keys())
#     values = tuple(item.values())
#     placeholder = ", ".join(["%s"] * len(item))
#     query = f"insert into {db.INDEX_TABLE} ({keys}) values ({placeholder})"
#     cur.execute(query,values)
#     conn.commit()



def pdp_pagesave(page_no,offender_id):
    global cookies
    for i in range(5):
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'Referer': f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page_no}',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
            'sec-ch-ua': '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
            'sec-ch-ua-platform': '"Linux"',
        }
        params = {
            'OfndrID': f'{offender_id}',
            'AgencyID': '55149',
        }
        response = requests.get('https://www.icrimewatch.net/offenderdetails.php', params=params, cookies=cookies, headers=headers,impersonate=random.choice(impersonate_list))
        if response.status_code == 200:
            file_path = fr"{db.DETAIL_PATH}\{offender_id}.html"
            db.pagesave_data(response,file_path)
            status = "done"
            return status

        else:
            cookies_dict = collect_cookies(
                'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
            cookies = {
                'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
                'datadome': f'{cookies_dict.get("datadome")}',
            }
            if i == 4:
                status="issue"
                return status
            continue

def photp_pagesave(photo_url,offender_id):
    headers = {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Referer': 'https://www.icrimewatch.net/',
        'Sec-Fetch-Dest': 'image',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Site': 'cross-site',
        'Sec-Fetch-Storage-Access': 'active',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
        'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Linux"',
    }
    file_path = fr"{db.PHOTO_PATH}\{offender_id}.jpg"
    response = requests.get(
        photo_url,
        headers=headers,impersonate=random.choice(impersonate_list)
    )
    print(response.status_code)
    db.pagesave_data(response,file_path)
    status="done"
    return status


if __name__ == "__main__":
    # pass
    query = f"select * from {db.INDEX_TABLE} where status='pending'"
    cur.execute(query)
    records = cur.fetchall()
    for data in records:
        plp_url = data["plp_url"]
        page_no = data["page_no"]
        pdp_url = "https://www.icrimewatch.net/" + data.get("pdp_url")
        photo_url = data.get("photo_url")
        offender_id = data.get("offender_id")
        status_pdp = pdp_pagesave(page_no,offender_id)
        status_photo = photp_pagesave(photo_url,offender_id)
        update_query = f"update {db.INDEX_TABLE} set status='{status_pdp}' ,status_photo='{status_photo}' where offender_id='{offender_id}'"
        cur.execute(update_query)
        conn.commit()








#========================threading===========================
# from curl_cffi.requests.impersonate import BrowserType
# from curl_cffi import requests
# from ICrimeWatch_OH_SOR.REQUEST_PAGESAVE.playwright_Script_check import *
# import ICrimeWatch_OH_SOR.db_config as db
# from concurrent.futures import ThreadPoolExecutor
# conn, cur = db.conn_()
# start_time = time.time()
# impersonate_list = [i.value for i in BrowserType]
#
# #
# # def insert_item(item,table_name):
# #     keys = ", ".join(item.keys())
# #     values = tuple(item.values())
# #     placeholder = ", ".join(["%s"] * len(item))
# #     query = f"insert into {db.INDEX_TABLE} ({keys}) values ({placeholder})"
# #     cur.execute(query,values)
# #     conn.commit()
#
# def pdp_pagesave(page_no,offender_id,cookies):
#     local_cookies = cookies.copy()
#     for i in range(5):
#         headers = {
#             'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
#             'Accept-Language': 'en-US,en;q=0.9',
#             'Connection': 'keep-alive',
#             'Referer': f'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page={page_no}',
#             'Upgrade-Insecure-Requests': '1',
#             'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36',
#             'sec-ch-ua': '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
#             'sec-ch-ua-platform': '"Linux"',
#         }
#         params = {
#             'OfndrID': f'{offender_id}',
#             'AgencyID': '55149',
#         }
#         response = requests.get('https://www.icrimewatch.net/offenderdetails.php', params=params, cookies=local_cookies, headers=headers,impersonate=random.choice(impersonate_list))
#         if response.status_code == 200:
#             file_path = fr"{db.DETAIL_PATH}\{offender_id}.html"
#             db.pagesave_data(response,file_path)
#             status = "done"
#             return status
#
#         else:
#             cookies_dict = collect_cookies(
#                 'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
#             local_cookies = {
#                 'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
#                 'datadome': f'{cookies_dict.get("datadome")}',
#             }
#             if i == 4:
#                 status="issue"
#                 return status
#             continue
#
# def photp_pagesave(photo_url,offender_id):
#     headers = {
#         'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
#         'Accept-Language': 'en-US,en;q=0.9',
#         'Connection': 'keep-alive',
#         'Referer': 'https://www.icrimewatch.net/',
#         'Sec-Fetch-Dest': 'image',
#         'Sec-Fetch-Mode': 'no-cors',
#         'Sec-Fetch-Site': 'cross-site',
#         'Sec-Fetch-Storage-Access': 'active',
#         'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
#         'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
#         'sec-ch-ua-mobile': '?0',
#         'sec-ch-ua-platform': '"Linux"',
#     }
#     file_path = fr"{db.PHOTO_PATH}\{offender_id}.jpg"
#     response = requests.get(
#         photo_url,
#         headers=headers,impersonate=random.choice(impersonate_list)
#     )
#     print(response.status_code)
#     db.pagesave_data(response,file_path)
#     status="done"
#     return status
#
# def worker(data):
#     try:
#         conn,cur = db.conn_()
#         plp_url,page_no,photo_url,offender_id, cookies = data
#         try:status_pdp = pdp_pagesave(page_no, offender_id,cookies)
#         except Exception:status_pdp = "issue"
#         try:status_photo = photp_pagesave(photo_url, offender_id)
#         except Exception: status_photo = "issue"
#         update_query = f"update {db.INDEX_TABLE} set status='{status_pdp}' ,status_photo='{status_photo}' where offender_id='{offender_id}'"
#         cur.execute(update_query)
#         conn.commit()
#         cur.close()
#         conn.close()
#         print("offender id :",offender_id)
#     except Exception as e:
#         print("issue in worker.",e)
#
# if __name__ == "__main__":
#     cookies_dict = collect_cookies(
#         'https://www.icrimewatch.net/results.php?AgencyID=55149&SubmitNameSearch=1&OfndrLast=%27%%27&OfndrFirst=%27%%27&OfndrCity=&page=1')
#     cookies = {
#         'cf_clearance': f"{cookies_dict.get('cf_clearance')}",
#         'datadome': f'{cookies_dict.get("datadome")}',
#     }
#     query = f"select * from {db.INDEX_TABLE} where status='pending'"
#     cur.execute(query)
#     records = cur.fetchall()
#     data_list = [(data.get("plp_url"),data.get("page_no"),data.get("photo_url"),data.get("offender_id"),cookies) for data in records]
#
#     with ThreadPoolExecutor(max_workers=1) as executor:
#         result = executor.map(worker,data_list)
#         for r in result:
#             print(r)


