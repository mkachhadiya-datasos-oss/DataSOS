import time

from playwright.sync_api import sync_playwright

playwright = None
browser = None
context = None
page = None

def get_key():
    global playwright, browser, context, page

    if browser is None:
        playwright = sync_playwright().start()
        browser = playwright.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

    page.goto("https://sexoffenders.nv.gov/ConditionsOfUse.aspx")
    page.wait_for_timeout(2000)

    cookies = context.cookies()

    for c in cookies:
        if c["name"] == "ASP.NET_SessionId":
            return c["value"]

def reset_browser():
    global browser, context, page, playwright

    if browser:
        browser.close()
    if playwright:
        playwright.stop()

    browser = None
    context = None
    page = None

def is_expired(html):
    return (
        "Conditions of Use" in html
        or "captcha" in html.lower()
    )
if __name__ == "__main__":
    pass
    # for i in range(5):
    #     get_key()
    #     time.sleep(5)
    #     reset_browser()