import pandas as pd
import string

letters = string.ascii_lowercase

data = []

# generate all 2-letter combinations
combinations = [a + b for a in letters for b in letters]

# create full pairing
for first in combinations:
    for last in combinations:
        data.append([first, last])

# create dataframe
df = pd.DataFrame(data, columns=["FirstName", "LastName"])

# save to excel
df.to_excel("name_combinations.xlsx", index=False)

print("Done! File saved as name_combinations.xlsx")