from datetime import datetime
import pymysql
import os

year_month = datetime.now().strftime("%Y_%m")
#deathbycaptch credential ....
user_for_captch = 'kartikrramanuj'
pass_for_captch = 'kartikdbc123$'

# table name conversion
input_table = "input_name"
plp_listing_table = "plp_listing_table"
pdp_table_name = "pdp_data_table"
plp_table_creation_new = "plp_table_creation_new"

#path for page save and captcha images save
captch_image_store_path = fr'/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Captcha_images'
plp_page_save_folder = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Index"

file_path = fr"/home/mkachhadiya@datasos.local/output.txt"

pdp_pagesave_detail = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Detail"
pdp_pagesave_OtherAddress = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/OtherAddress"
pdp_pagesave_Scars = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Scars"
pdp_pagesave_Vehicle = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Vehicle"
pdp_pagesave_photo = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Photos"

process_logs = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/process_logs"
os.makedirs(captch_image_store_path,exist_ok=True)
os.makedirs(plp_page_save_folder,exist_ok=True)
os.makedirs(pdp_pagesave_detail,exist_ok=True)
os.makedirs(pdp_pagesave_OtherAddress,exist_ok=True)
os.makedirs(pdp_pagesave_Scars,exist_ok=True)
os.makedirs(pdp_pagesave_Vehicle,exist_ok=True)
os.makedirs(pdp_pagesave_photo,exist_ok=True)
def db_creation():
    conn = pymysql.connect(host="localhost", user="mansi", password="mansi", cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    database = f"NV_SOR_{year_month}"
    query = f"create database if not exists {database}"
    cur.execute(query)
    conn.commit()

def conn_():
    conn = pymysql.connect(host="localhost",user="mansi",password="mansi",database=f"NV_SOR_{year_month}",cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    return conn,cur

conn, cur = conn_()
def plp_table_creation_new_fun():
    query = f"""create table if not exists plp_table_creation_new (
    id int auto_increment primary key,
    name varchar(240),
    picture_url text,
    pdp_link text,
    aliases text,
    primaryresidence text,
    first_name varchar(50),
    last_name varchar(50),
    pagesave_path text,
    status varchar(50) default "pending",
    status_main_pdp varchar(50) default "pending",
    status_address varchar(50) default "pending",
    status_scars varchar(50) default "pending",
    status_vehicle varchar(50) default "pending",
    status_image varchar(50) default "pending",
    index index_value (name)
    )engine=InnoDB default CHARSET=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()

if __name__ == "__main__":
    # pass
    # db_creation()
    plp_table_creation_new_fun()