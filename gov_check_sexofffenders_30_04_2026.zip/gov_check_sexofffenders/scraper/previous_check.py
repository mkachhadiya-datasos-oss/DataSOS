
import os
import config_use as db
from curl_cffi import requests
from parsel import Selector
from session_id_get import *
import pandas as pd
import deathbycaptcha
from urllib.parse import urlparse, parse_qs

def captch_solver(session_id,session):
    url = "https://sexoffenders.nv.gov/Captcha.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Referer": "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    cookies = {
        "ASP.NET_SessionId": f"{session_id}"
    }
    response = session.get(url, headers=headers,
                           # cookies=cookies,
                           )
    print("Status:", response.status_code)
    print(session.cookies.get_dict())
    # Save captcha page (HTML)
    with open(db.captcha_1, "w", encoding="utf-8") as f:
        f.write(response.text)
    print("Done")
    response = Selector(response.text)
    return response

def captch_post_requst(session_id,session,czptch_path,VIEWSTATE1,captch_text,VIEWSTATEGENERATOR1,EVENTVALIDATION1):
    #captch_request"
    url = "https://sexoffenders.nv.gov/Captcha.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://sexoffenders.nv.gov/Captcha.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    cookies = {
        "ASP.NET_SessionId": f"{session_id}"
    }
    data = {
        "__LASTFOCUS": "",
        "LBD_VCT_captcha_ctl00_contentplaceholder1_botdetectcaptcha": f"{czptch_path}",
        "__VIEWSTATE": f"{VIEWSTATE1}",
        "ctl00$ContentPlaceHolder1$CodeTextBox": f"{captch_text}",
        "ctl00$ContentPlaceHolder1$ValidateButton": "Continue",
        "__VIEWSTATEGENERATOR": f"{VIEWSTATEGENERATOR1}",
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__EVENTVALIDATION": f"{EVENTVALIDATION1}"
    }
    response = session.post(
        url,
        headers=headers,
        # cookies=cookies,
        data=data,allow_redirects = False )

    print("Status Code:", response.status_code)
    print("Response Length:", len(response.text))
    print()
    print("first page captch solved..")
    response = Selector(response.text)
    return response

def lanapcaptch(session_id,t,s,session):
    cookies = {
        'ASP.NET_SessionId': f"{session_id}",
    }
    headers = {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://sexoffenders.nv.gov/Captcha.aspx',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
    }

    params = {
        'get': 'image',
        'c': 'captcha_ctl00_contentplaceholder1_botdetectcaptcha',
        't': f'{t}',
        's': f'{s}',
    }
    response = session.get('https://sexoffenders.nv.gov/LanapCaptcha.aspx', params=params,
                           # cookies=cookies,
                            headers=headers)

    with open(fr"{db.captch_image_store_path}/captcha.png", 'wb') as f:
        f.write(response.content)

    client = deathbycaptcha.HttpClient(db.user_for_captch, db.pass_for_captch)

    captcha_file = fr'/home/mkachhadiya@datasos.local/Mansi/projects/gov_check_sexofffenders/captch_images/captcha.png'

    captcha = client.decode(captcha_file, timeout=60)

    if captcha:
        print("CAPTCHA text:", captcha['text'])
        with open(fr'{db.captch_image_store_path}/captcha_{captcha['text']}.png', 'wb') as f:
            f.write(response.content)
        return captcha['text']
    else:
        print("Failed to solve captcha")
        return None

# def condition_for_user(session_id,session):
def condition_for_user(session):
    #get request step1 :
    url = "https://sexoffenders.nv.gov/ConditionsOfUse.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    # cookies = {
    #     "ASP.NET_SessionId": f"{session_id}"
    # }
    response = session.get(url, headers=headers,
                           # cookies=cookies,
                         )
    print("Status:", response.status_code)
    print(session.cookies.get_dict())
    session_id = session.cookies.get("ASP.NET_SessionId")
    with open(fr"/{db.extra_html_pagesave}/condition_of_use.html","w",encoding="utf-8") as f:
        f.write(response.text)
    response = Selector(response.text)
    VIEWSTATE = response.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()

    #post request conditionforuse "i agree" stpe2
    post_data = {
        "__VIEWSTATE": VIEWSTATE,
        "__VIEWSTATEGENERATOR": VIEWSTATEGENERATOR,
        "__EVENTVALIDATION": EVENTVALIDATION,
        "ctl00$ContentPlaceHolder1$btnAgree": "I agree"
    }
    headers_post = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://sexoffenders.nv.gov",
        "Referer": "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }

    res2 = session.post(
        "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        headers=headers_post,
        data=post_data,allow_redirects=False
    )
    #captch request review ()
    response_captch = captch_solver(session_id,session)

    czptch_path = response_captch.xpath('//input[@id="LBD_VCT_captcha_ctl00_contentplaceholder1_botdetectcaptcha"]/@value').get()
    src = response_captch.xpath('//img[@id="captcha_ctl00_contentplaceholder1_botdetectcaptcha_CaptchaImage"]/@src').get()
    VIEWSTATE1 = response_captch.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR1 = response_captch.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION1= response_captch.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
    parsed = urlparse(src)
    params = parse_qs(parsed.query)

    t_value = params.get("t", [""])[0]
    s_value = params.get("s", [""])[0]
    captch_text = lanapcaptch(session_id, czptch_path, s_value,session)
    response_captch_post = captch_post_requst(session_id, session, czptch_path, VIEWSTATE1, captch_text, VIEWSTATEGENERATOR1, EVENTVALIDATION1)
    VIEWSTATE2 = response_captch_post.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR2 = response_captch_post.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION2 = response_captch_post.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
    return VIEWSTATE2, VIEWSTATEGENERATOR2, EVENTVALIDATION2
    # VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, t_value, captch_text = search_ofendr_1(session_id, session)
    # search_ofender2(VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, first_name, last_name, session_id, session, t_value,
    #                 captch_text)
    # return_value = ofender_result(first_name, last_name, session_id, session)


def search_ofendr_1(session_id,session):
    url = "https://sexoffenders.nv.gov/SearchOffender.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Referer": "https://sexoffenders.nv.gov/Captcha.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    response = session.get(url, headers=headers )
    if response.status_code == 200:
        with open(fr"{db.extra_html_pagesave}/searchoffender.html","w",encoding="utf-8") as f:
            f.write(response.text)
        print("Status:", response.status_code)
        print(session.cookies.get_dict())
        response = Selector(response.text)
        VIEWSTATE = response.xpath('//input[@id="__VIEWSTATE"]/@value').get()
        VIEWSTATEGENERATOR = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
        EVENTVALIDATION = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
        captcha_hidden = response.xpath(
            '//input[@id="LBD_VCT_searchoffender_ctl00_contentplaceholder1_botdetectcaptcha"]/@value').get()

        # captcha_hidden = response.xpath(
        #     '//input[contains(@name,"LBD_VCT_searchoffender")]/@value'
        # ).get()
        #captch iamge_solve_
        src = response.xpath(
            '//img[@id="searchoffender_ctl00_contentplaceholder1_botdetectcaptcha_CaptchaImage"]/@src').get()
        parsed = urlparse(src)
        params = parse_qs(parsed.query)

        t_value = params.get("t", [""])[0]
        s_value = params.get("s", [""])[0]
        captch_text = lanapcaptch(session_id, captcha_hidden, s_value, session)
        #captch image solve done


        return VIEWSTATE, VIEWSTATEGENERATOR ,EVENTVALIDATION, captcha_hidden , captch_text
    else:
        print("Status:", response.status_code)

        return None, None, None, None

def search_ofender2(VIEWSTATE, VIEWSTATEGENERATOR ,EVENTVALIDATION,first_name,last_name,session_id,session,captcha_hidden, captch_text):
    url = "https://sexoffenders.nv.gov/SearchOffender.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://sexoffenders.nv.gov",
        "Referer": "https://sexoffenders.nv.gov/SearchOffender.aspx",
        "User-Agent": "Mozilla/5.0"
    }


    payload = {
        "LBD_VCT_searchoffender_ctl00_contentplaceholder1_botdetectcaptcha":  captcha_hidden,
        "__EVENTTARGET": "ctl00$ContentPlaceHolder1$btnSearch",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": f"{VIEWSTATE}",
        "__VIEWSTATEGENERATOR":  f"{VIEWSTATEGENERATOR}",
        "__EVENTVALIDATION":  f"{EVENTVALIDATION}",
        "ctl00$ContentPlaceHolder1$txtLastName": f"{first_name}",
        "ctl00$ContentPlaceHolder1$txtFirstName": f"{last_name}",
        "ctl00$ContentPlaceHolder1$CodeTextBox": f"{captch_text}"
    }
    print(payload)
    response = session.post(url, headers=headers,
                            # cookies=cookies,
                            data=payload,
                            allow_redirects=False
                            )
    if response.status_code ==302:
        print("redirected...")
        print("Status:", response.status_code)
        print(session.cookies.get_dict())
        print("Redirect:", response.headers.get("Location"))
        response = Selector(response.text)
        return response
    else:
        return {"message":"no data found "}

def ofender_result(first_name,last_name,session_id,session,response):
    # url = "https://sexoffenders.nv.gov/OffenderSearchResults.aspx"
    # headers = {
    #     "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    #     "Accept-Language": "en-US,en;q=0.9",
    #     "Cache-Control": "max-age=0",
    #     "Referer": "https://sexoffenders.nv.gov/SearchOffender.aspx",
    #     "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    # }
    # cookies = {
    #     "ASP.NET_SessionId": f"{session_id}"
    # }
    # response = session.get(url, headers=headers,
    #                        # cookies=cookies,
    #                       )
    # if response.status_code == 200:
    #below line i use sift tab  si dont forget to again tab it
    # print("Status:", response.status_code)
    print(session.cookies.get_dict())
    pagesave_plp_path = fr"{db.plp_page_save_folder}/{first_name}_{last_name}.html"
    with open(pagesave_plp_path,"w",encoding="utf-8") as f:
        f.write(response._text)
    print("done check process")
    response = Selector(response._text)
    if response.xpath('//input[@id="ctl00_ContentPlaceHolder1_btnAgree"]'):
        print("re - request....")
        return "change"
    else:
        # plp_details(response)
        table_path = response.xpath('//h4[contains(text(),"Offenders:")]/following-sibling::table')
        if table_path:
            table = table_path[0]
            columns = [name.strip() for name in table_path.xpath('.//tr//th/text()').getall()]
            # header define
            header = "picture|pdp_url|name|aliases|primary_residency\n"

            file_exists = os.path.exists(db.file_path)
            with open(db.file_path, "a", encoding="utf-8") as f:
                # write header only if file is new/empty
                if not file_exists or os.stat(db.file_path).st_size == 0:
                    f.write(header)
                #table td data
                for tr in table.xpath('.//tr[position()>1]'):
                    picture = tr.xpath('.//td[1]//img/@src').get()
                    pdp_url = tr.xpath('.//td[2]//a/@href').get()
                    if pdp_url:
                        pdp_url = "https://sexoffenders.nv.gov"+pdp_url.lstrip(".")
                    name = tr.xpath('.//td[2]//a/text()').get()
                    aliases = [alias.strip() for alias in tr.xpath('.//td[3]/ul//li/text()').getall()]
                    primary_residency = [res.strip() for res in tr.xpath('.//td[4]/ul//li/text()').getall()]
                    f.write(f"{name}|{aliases}|{picture}|{primary_residency}|{pdp_url}\n")
            pass
        else:
            print(f"no result found for {first_name} - {last_name}")
    # else:
    #     print("for final result response is  :",response.status_code)

if __name__ == "__main__":
    # session_id = get_key()
    df = pd.read_excel(r"/home/mkachhadiya@datasos.local/Documents/check_records.xlsx")
    session = requests.Session(impersonate="chrome110")
    VIEWSTATE2, VIEWSTATEGENERATOR2, EVENTVALIDATION2 = condition_for_user(session)
    for row in df.itertuples(index=False):
        first_name = row.FirstName
        last_name = row.LastName
        for i in range(5):
            # session_id = get_key()
            session_id = "1"
            VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, captcha_hidden, captch_text = search_ofendr_1(session_id, session)
            response_serch_offender =search_ofender2(VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, first_name, last_name, session_id, session,
                            captcha_hidden,
                            captch_text)
            return_value = ofender_result(first_name, last_name, session_id, session,response_serch_offender)
            if return_value == "change":
                reset_browser()
                session_id = get_key()
                continue
            else:
                break

    # for row in df.itertuples(index=False):
    #     first_name = row.FirstName
    #     last_name = row.LastName
    #     for i in range(5):
    #         # session_id = get_key()
    #         session = requests.Session()
    #         return_value = condition_for_user(session)
    #         if return_value == "change":
    #             reset_browser()
    #             session_id = get_key()
    #             continue
    #         else:
    #             break

