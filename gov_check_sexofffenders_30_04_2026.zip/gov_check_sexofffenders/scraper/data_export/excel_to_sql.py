import scraper.config_use as db
import pandas as pd

chunk_size = 1000
conn, cur = db.conn_()

def input_table_creation(input_name):
    query = f"""create table if not exists {input_name}(
    id int auto_increment primary key,
    first_name varchar(50),
    last_name varchar(50),
    status varchar(50) default 'pending',
    index index_value (first_name, last_name),
    constraint unique_set unique (first_name, last_name)
    )engine=InnoDB default CHARSET=utf8mb4 collate=utf8mb4_unicode_ci"""

    cur.execute(query)
    conn.commit()

    df = pd.read_excel(fr"/home/mkachhadiya@datasos.local/Documents/name_combinations_nevada_SOR.xlsx")
    data = list(df.itertuples(index=False,name=None))
    query_insert = "INSERT INTO input_name (first_name,last_name) values (%s ,%s)"
    cur.executemany(query_insert,data)
    conn.commit()


if __name__ == "__main__":
    # pdp_table_creation()
    # plp_table_creation()
    pass
    # input_table_creation(db.input_table)