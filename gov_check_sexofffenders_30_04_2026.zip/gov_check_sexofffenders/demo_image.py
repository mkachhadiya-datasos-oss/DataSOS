# from PIL import Image
# from io import BytesIO
# from curl_cffi import requests
#
# url = "https://sexoffenders.nv.gov/DisplayImage.aspx?OffenderId=2632&ImageId=277913"
#
# res = requests.get(url)
#
# img = Image.open(BytesIO(res.content))
# img = img.resize((400, 400))  # width, height
#
# img.save("resized.png")
#
#

from curl_cffi import requests

url = "https://sexoffenders.nv.gov/DisplayImage.aspx?OffenderId=2632&ImageId=277913"

headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
    "Host": "sexoffenders.nv.gov",
    "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
}
for i in range(1,50):

    response = requests.get(url, headers=headers,impersonate="chrome110")

    print(response.status_code)
    with open("image_chedk.jpg","wb") as f:
        f.write(response.content)