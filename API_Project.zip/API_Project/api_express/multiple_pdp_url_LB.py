'''Workers = people doing tasks
Queue = task list
Chunk = group of tasks
Process = separate machine
Flow:
1. Split URLs into chunks
2. Each chunk → new process
3. Inside process:
     create workers
     workers wait for tasks
4. Add tasks to queue
5. Workers pick tasks and execute
6. All tasks finish → process ends'''
import asyncio
import hashlib
import random
import uuid
import aiohttp
import pandas as pd
import time
from multiprocessing import Process
CONCURRENT_WORKERS = 300
CHUNK_SIZE = 300
PARALLEL_CHUNKS = 20
TIMEOUT = 30
# LOAD URLS
df = pd.read_excel(r"D:\Users\mkachhadiya\Downloads\express_url.xlsx")
urls = df["url"].dropna().tolist()
start_time = time.time()
def chunk_list(data, chunk_size):
    return [data[i : i+chunk_size] for i in range(0, len(data), chunk_size)]

def load_proxies(file):
    proxies = []
    with open(file) as f:
        for line in f:
            ip, port, user, password = line.strip().split(":")
            proxies.append(f"http://{user}:{password}@{ip}:{port}")
    return proxies

proxies = load_proxies(r"D:\Users\mkachhadiya\Downloads\Webshare_Proxies 1.txt")

#step 5
'''this work for sending request and returning response '''
async def fetch(session, url):
    proxy = random.choice(proxies)
    try:
        await asyncio.sleep(random.uniform(0.05, 0.2))
        try:
            product_id = url.split("/pro/")[-1].split("/color")[0]
        except:
            product_id = url.split("/pro/")[-1]
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/json',
            'origin': 'https://www.express.com',
            'priority': 'u=1, i',
            'referer': f'{url}',
            'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
            'x-exp-request-id': 'c1c1a25f-b212-41b6-8fa9-d9659f4ce8d2',
            'x-exp-rvn-cache-key': 'f33b558d8b729d21aa0d372d54d3d5f33a2c640d6da40500c24822e0ea868684',
            'x-exp-rvn-cacheable': 'true',
            'x-exp-rvn-query-classification': 'product',
            'x-exp-rvn-source': 'app_express.com',
        }
        json_data = {
            'operationName': 'ProductQuery',
            'variables': {
                'productId': f'{product_id}',
                'useCache': False,
            },
            'query': 'query ProductQuery($productId: String!) {\n  product(id: $productId) {\n    bopisEligible\n    categories {\n      name\n      key\n      __typename\n    }\n    clearancePromoMessage\n    finalsalePromoMessage\n    colorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    clearanceColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    finalColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    collection\n    crossRelDetailMessage\n    crossRelProductURL\n    EFOProduct\n    expressProductType\n    fabricCare\n    fabricDetailImages {\n      caption\n      image\n      __typename\n    }\n    firstProductNameInEnsemble\n    gender\n    internationalShippingAvailable\n    listPrice\n    marketPlaceProduct\n    name\n    newProduct\n    onlineExclusive\n    onlineExclusivePromoMsg\n    pdpCrossSellHeader\n    productDescription {\n      type\n      content\n      __typename\n    }\n    matchingSet {\n      color\n      skus\n      __typename\n    }\n    productDetail\n    productFeatures\n    productId\n    productImage\n    productInventory\n    productURL\n    promoMessage\n    recsAlgorithm\n    originRecsAlgorithm\n    salePrice\n    type\n    breadCrumbSummary\n    breadCrumbCategory {\n      categoryName\n      h1CategoryName\n      links {\n        rel\n        href\n        __typename\n      }\n      breadCrumbCategory {\n        categoryName\n        h1CategoryName\n        links {\n          rel\n          href\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    colorSlices {\n      color\n      colorFamily\n      defaultSlice\n      faceoutModelDetails {\n        model1\n        model2\n        __typename\n      }\n      ipColorCode\n      hasWaistAndInseam\n      swatchURL\n      imageMap {\n        All {\n          LARGE\n          MAIN\n          __typename\n        }\n        Default {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model1 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model2 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model3 {\n          LARGE\n          MAIN\n          __typename\n        }\n        __typename\n      }\n      mediaMap {\n        main {\n          url\n          sequenceId\n          __typename\n        }\n        large {\n          url\n          sequenceId\n          __typename\n        }\n        modelInfo {\n          sequenceId\n          labelText\n          __typename\n        }\n        __typename\n      }\n      onlineSkus\n      skus {\n        backOrderable\n        backOrderDate\n        clearanceDisclaimer\n        categoryType\n        displayMSRP\n        displayPrice\n        ext\n        finalSaleDisclaimer\n        inseam\n        inStoreInventoryCount\n        inventoryMessage\n        isFinalSale\n        isInStockOnline\n        miraklOffer {\n          minimumShippingPrice\n          sellerId\n          sellerName\n          __typename\n        }\n        marketPlaceSku\n        onClearance\n        onSale\n        onlineExclusive\n        onlineInventoryCount\n        size\n        sizeName\n        skuId\n        __typename\n      }\n      __typename\n    }\n    originRecs {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      __typename\n    }\n    relatedProducts {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      colorSlices {\n        color\n        defaultSlice\n        __typename\n      }\n      __typename\n    }\n    storeTier\n    icons {\n      icon\n      category\n      __typename\n    }\n    __typename\n  }\n}',
        }
        uniq_key = hashlib.md5(f"{product_id}-{time.time()}".encode()).hexdigest()
        headers["x-exp-rvn-cache-key"] = uniq_key
        headers["Connection"] = "close"
        headers["x-exp-request-id"] = str(uuid.uuid4())
        headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        headers["Pragma"] = "no-cache"
        headers["Expires"] = "0"
        headers["x-exp-rvn-cacheable"] = "false"
        async with session.get(url, json=json_data,headers=headers,proxy=proxy) as response:
            print(response.status, url)
            return await response.text()

    except Exception:
        print("FAILED", url)
        return None

#step4
'''
taking queue that has those 300 urls and session
iterate in while true means 1worker != 1task
worker do work till queue getting empty ,so while true require 
300 worker assign so currently if i do not wright while true is on . but when i have more task and > worker then 
at that time while true require because if i have 5 worker and 15 task so after 5 tast complated it look for next task and take it.
'''
async def worker(queue, session):
    while True:
        url = await queue.get()
        try:
            '''fetch take session and url as e want same session for 300 so session passing require.
            go to this function '''
            response = await fetch(session, url)
            await pagesave(response,url)
        finally:
            #complating task after its work done.
            queue.task_done()

async def pagesave(response,url):



# step 3
""" frist it define queue that follow fifo order 
timeout we know
aiohttp.clientSession this is important because it ensure to use same session throughout that 300 urls like..\
when we send request to it ensure to open TCP connection -> make handshake -> allow then give response -> close connection
but this process also take time in it .so aiohttp.clientConnection ensure to stay on same session till this chunk completed 
for next chunk this will create new session and stay till that chunk all request completed .."""
async def run_chunk(url_chunk):
    queue = asyncio.Queue()

    timeout = aiohttp.ClientTimeout(total=TIMEOUT)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        # add URLs
        '''at this part i wright queue frist because i want to make sure all url goese in queue frist then it assign to worker 
        like if i wright worker frist then it create all worker frist then each waiting for taking task from queue so eeminating that
        idel time i wright queue putting frist 
        so it like que = url5 | url4 | url3 | url2 | url1  -> fifo -> puting value in queue
        basically worker take task from queue so out out must ready for it.
        que task adding process is faster then worker assign so if you wright it after worker then ans not having any issue ..'''

        for url in url_chunk:
            await queue.put(url)

        # start workers
        """ at this like it creating worker that take task ,processit and complete it . repeting same process
        it take queue for getting task from it ,
        session for maintain same session..
        goto worker fuction check hat it does..
        asyncio.create_task length of concurrent_workers in out case i use 300 worker for 300 urls...
        it create list of workers nd worker do go and check in function `worker`"""
        workers = [
            asyncio.create_task(worker(queue, session))
            for _ in range(CONCURRENT_WORKERS)
        ]


        await queue.join()

        for w in workers:
            w.cancel()

# step 2 then its call to process chunk function here async run start asyncio.run() it pass that 4 chunk parellerly to run_chunk
'''
1 process ->chunk[0]
2 process ->chunk[1]
3 process ->chunk[2]
4 process ->chunk[4]
--> this all start at once...
'''

def process_chunk(url_chunk): #this get 300 300 urls
    #this file has scrpit for run each chunk in run_chunk size.. it take that url and goto run_chunk
    asyncio.run(run_chunk(url_chunk))


# 🚀 MAIN CONTROL
# if __name__ == "__main__":
def start_fun(urls):
    #step 1: take url and chunkl size send it ti chunk list function
    chunks = chunk_list(urls, CHUNK_SIZE)
    #in chunks i have list of list that contains url in chunks like ,i have chunk_size = 300,total url is 1000
    # chunks = [ [300 urls] , [300 urls], [300 urls] ,[100 urls] ]

    print(f"Total URLs: {len(urls)}") # 1000
    print(f"Total Chunks: {len(chunks)}") # 4

    # Run in batches of parallel processes
    #(0,4,20)
    for i in range(0, len(chunks), PARALLEL_CHUNKS):
        #chunks[0 : 20] batch = list of entire chunks as we have only 4 chunk and 20 proces can allow
        #here process means parallel run process like if 4 proces then that 4 run at same time , mere if i reduce paralle_chunks
        #to 2 then bat like chun 1,2 3,4 run parallel then in second iteration batch 3,4 run parallel .
        batch = chunks[i: i+PARALLEL_CHUNKS]
        processes = []
        # batch = [ [300 urls] , [300 urls], [300 urls] ,[100 urls] ]
        for chunk in batch:
            #chunk like [300 urls]                  (300 urls,) pass
            p = Process(target=process_chunk, args=(chunk,))
            #goto this function read comment then come back to this line
            #here thread is same as process like what target function you want to call and what value you want to pass in args
            # now this starting each process total 4 process stat 4 at once appending to processes
            p.start()
            processes.append(p)

        # wait for batch
        for p in processes:
            #this wait to completing all process.
            p.join()

    print("Total time:", time.time() - start_time)
start_fun()
# import asyncio
# import hashlib
# import random
# import time
# import uuid
#
# import aiohttp
# import pandas as pd
#
# CONCURRENT_REQUESTS = 100
# TIMEOUT = 30
#
#
# # LOAD URLS FROM EXCEL
# df = pd.read_excel(fr"D:\Users\mkachhadiya\Downloads\express_url.xlsx")
# urls = df["url"].dropna().tolist()
#
#
# # LOAD PROXIES
# def load_proxies(file):
#     proxies = []
#
#     with open(file) as f:
#         for line in f:
#             line = line.strip()
#
#             if not line:
#                 continue
#
#             ip, port, user, password = line.split(":")
#
#             proxy = f"http://{user}:{password}@{ip}:{port}"
#
#             proxies.append(proxy)
#
#     return proxies
#
#
# proxies = load_proxies(fr"D:\Users\mkachhadiya\Downloads\Webshare_Proxies 1.txt")
#
#
# sem = asyncio.Semaphore(CONCURRENT_REQUESTS)
#
#
# async def fetch(session, url):
#     try:
#         product_id = url.split("/pro/")[-1].split("/color")[0]
#     except:
#         product_id = url.split("/pro/")[-1]
#     headers = {
#         'accept': '*/*',
#         'accept-language': 'en-US,en;q=0.9',
#         'content-type': 'application/json',
#         'origin': 'https://www.express.com',
#         'priority': 'u=1, i',
#         'referer': f'{url}',
#         'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
#         'sec-ch-ua-mobile': '?0',
#         'sec-ch-ua-platform': '"Windows"',
#         'sec-fetch-dest': 'empty',
#         'sec-fetch-mode': 'cors',
#         'sec-fetch-site': 'same-origin',
#         'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
#         'x-exp-request-id': 'c1c1a25f-b212-41b6-8fa9-d9659f4ce8d2',
#         'x-exp-rvn-cache-key': 'f33b558d8b729d21aa0d372d54d3d5f33a2c640d6da40500c24822e0ea868684',
#         'x-exp-rvn-cacheable': 'true',
#         'x-exp-rvn-query-classification': 'product',
#         'x-exp-rvn-source': 'app_express.com',
#     }
#     json_data = {
#         'operationName': 'ProductQuery',
#         'variables': {
#             'productId': f'{product_id}',
#             'useCache': False,
#         },
#         'query': 'query ProductQuery($productId: String!) {\n  product(id: $productId) {\n    bopisEligible\n    categories {\n      name\n      key\n      __typename\n    }\n    clearancePromoMessage\n    finalsalePromoMessage\n    colorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    clearanceColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    finalColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    collection\n    crossRelDetailMessage\n    crossRelProductURL\n    EFOProduct\n    expressProductType\n    fabricCare\n    fabricDetailImages {\n      caption\n      image\n      __typename\n    }\n    firstProductNameInEnsemble\n    gender\n    internationalShippingAvailable\n    listPrice\n    marketPlaceProduct\n    name\n    newProduct\n    onlineExclusive\n    onlineExclusivePromoMsg\n    pdpCrossSellHeader\n    productDescription {\n      type\n      content\n      __typename\n    }\n    matchingSet {\n      color\n      skus\n      __typename\n    }\n    productDetail\n    productFeatures\n    productId\n    productImage\n    productInventory\n    productURL\n    promoMessage\n    recsAlgorithm\n    originRecsAlgorithm\n    salePrice\n    type\n    breadCrumbSummary\n    breadCrumbCategory {\n      categoryName\n      h1CategoryName\n      links {\n        rel\n        href\n        __typename\n      }\n      breadCrumbCategory {\n        categoryName\n        h1CategoryName\n        links {\n          rel\n          href\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    colorSlices {\n      color\n      colorFamily\n      defaultSlice\n      faceoutModelDetails {\n        model1\n        model2\n        __typename\n      }\n      ipColorCode\n      hasWaistAndInseam\n      swatchURL\n      imageMap {\n        All {\n          LARGE\n          MAIN\n          __typename\n        }\n        Default {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model1 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model2 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model3 {\n          LARGE\n          MAIN\n          __typename\n        }\n        __typename\n      }\n      mediaMap {\n        main {\n          url\n          sequenceId\n          __typename\n        }\n        large {\n          url\n          sequenceId\n          __typename\n        }\n        modelInfo {\n          sequenceId\n          labelText\n          __typename\n        }\n        __typename\n      }\n      onlineSkus\n      skus {\n        backOrderable\n        backOrderDate\n        clearanceDisclaimer\n        categoryType\n        displayMSRP\n        displayPrice\n        ext\n        finalSaleDisclaimer\n        inseam\n        inStoreInventoryCount\n        inventoryMessage\n        isFinalSale\n        isInStockOnline\n        miraklOffer {\n          minimumShippingPrice\n          sellerId\n          sellerName\n          __typename\n        }\n        marketPlaceSku\n        onClearance\n        onSale\n        onlineExclusive\n        onlineInventoryCount\n        size\n        sizeName\n        skuId\n        __typename\n      }\n      __typename\n    }\n    originRecs {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      __typename\n    }\n    relatedProducts {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      colorSlices {\n        color\n        defaultSlice\n        __typename\n      }\n      __typename\n    }\n    storeTier\n    icons {\n      icon\n      category\n      __typename\n    }\n    __typename\n  }\n}',
#     }
#     uniq_key = hashlib.md5(f"{product_id}-{time.time()}".encode()).hexdigest()
#     headers["x-exp-rvn-cache-key"] = uniq_key
#     headers["Connection"] = "close"
#     headers["x-exp-request-id"] = str(uuid.uuid4())
#     headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
#     headers["Pragma"] = "no-cache"
#     headers["Expires"] = "0"
#     headers["x-exp-rvn-cacheable"] = "false"
#     proxy = random.choice(proxies)
#
#     async with sem:
#
#         try:
#
#             await asyncio.sleep(random.uniform(0.1, 0.4))
#
#             async with session.get(
#                 url,
#                 proxy=proxy,
#                 headers=headers,json=json_data
#             ) as response:
#
#                 text = await response.text()
#
#                 print(response.status, url)
#
#                 return text
#
#         except Exception as e:
#             print("FAILED:", url, e)
#             return None
#
#
# async def main():
#
#     timeout = aiohttp.ClientTimeout(total=TIMEOUT)
#
#     connector = aiohttp.TCPConnector(limit=CONCURRENT_REQUESTS)
#
#     async with aiohttp.ClientSession(
#         timeout=timeout,
#         connector=connector
#     ) as session:
#
#         tasks = []
#
#         for url in urls:
#             tasks.append(asyncio.create_task(fetch(session, url)))
#
#         await asyncio.gather(*tasks)
#
#
# if __name__ == "__main__":
#     asyncio.run(main())