import json
import re
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import multiple_pdp_url_LB as LB
import time
from curl_cffi import requests
import hashlib
import uuid
from fastapi import FastAPI, Query, UploadFile, File
import io

import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from tenacity import stop_after_attempt, wait_exponential ,retry
import pandas as pd
app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
def remove_extra_spaces(input_string):
    # Use regex to replace consecutive spaces with a single space
    cleaned_string = re.sub(r'\s+', ' ', input_string).strip()
    return cleaned_string


def gen_output_file_excel(response):

    pass
@app.get("/")
def home():
    return FileResponse("static/index.html")


@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10))
@app.get("/search_key/")
def search_value(search_key :str):
    main_item_list = list()
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.express.com',
        'priority': 'u=1, i',
        'referer': f'https://www.express.com/exp/search?q={search_key}',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
        'x-exp-request-id': f'{uuid.uuid4()}',
        'x-exp-rvn-cache-key': 'a0f9bbfeff8cf37428a453391030fdb455d593ee453f49e16e33e3c92d2d0490',
        'x-exp-rvn-cacheable': 'false',
        'x-exp-rvn-query-classification': 'getRetailSearch',
        'x-exp-rvn-source': 'app_express.com',
        # 'cookie': 'ak_bmsc=0558DF8C42C4B42B5229028AFA73BEB9~000000000000000000000000000000~YAAQBXLMF6YUdOWcAQAAcaqO5R+DqdFS/cTVaPUMPdKZhUARP8BN1gVjLUc1elHRGMmMIhaCByk6ZxW6Vtt+Fe+6Uh67UONdUXK6JjZLk1UGEab73tPdmfRd4LtcZ1IGkvFCQf1EC6JCljFXiNq7X4YhE9as0kRJwbchu9Y+CDjJxE69+sRQ1YTQMw1a6DmfYh55xD2onSsURlWsOkX7qk1Ft9p452OAUzWlTedLXOu9xGezShx4cVRmNXLLVGeNTF2WDHoJ/AvN8xGk4b8QzSpjdl7W1iYlT7BdPWzLeSAzwyCB0oWrnHUHD+09E/8hTB8/EyZy5LvAO5NsXwa/WBGc2IUlGtK7GZCKzMPUcDe0AXBAZomx3AVSQD00RTKty2mdk7R0q2N5mUhTwsfDnT2yLd0fITIINOEurKb3h45mzbh1MxHHXoalAX1AMXRM8aZmXnelXEf0PTp/VisE; bluecoreNV=true; QuantumMetricSessionID=82f3441b123546f96e24ccca234accb7; QuantumMetricUserID=7086f1e62b6fdd988b143dcf09ece3a0; AKA_A2=A; tfpsi=92756578-a200-4bce-99a4-d02765caae80; ATTRIBUTION_LANDING=%2F; _gcl_au=1.1.622422266.1773377881; OptanonAlertBoxClosed=2026-03-13T04:58:01.557Z; isMobile=false; isTablet=false; _shopify_y=41d2d845-6eb7-4ce0-95ed-f15b9efd4cfb; accessToken=j%3A%7B%22accessToken%22%3A%22eyJhbGciOiJSUzI1NiIsImtpZCI6ImEyZGZiOGEzOGI1MmQ5ZjA5ZWRjYWE1MDcwYTBlOGYwYTllMDk4YmEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZWNvbW0tcmVzb3VyY2VzLXByb2QiLCJhdWQiOiJlY29tbS1yZXNvdXJjZXMtcHJvZCIsImF1dGhfdGltZSI6MTc3MzM3NTIwMiwidXNlcl9pZCI6IldaM2FsdlF1OXRaSzU1QjUwemxJZmlTSDZqRDIiLCJzdWIiOiJXWjNhbHZRdTl0Wks1NUI1MHpsSWZpU0g2akQyIiwiaWF0IjoxNzczMzc1MjAyLCJleHAiOjE3NzMzNzg4MDIsImVtYWlsIjoiZ3Vlc3RAZXhwcmVzcy5jb20iLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImZpcmViYXNlIjp7ImlkZW50aXRpZXMiOnsiZW1haWwiOlsiZ3Vlc3RAZXhwcmVzcy5jb20iXX0sInNpZ25faW5fcHJvdmlkZXIiOiJwYXNzd29yZCJ9fQ.jZTOz5pbEuHJeqmyqZQjMckJ6qXOLWWELOghoEnvnOvJCafR4uaSFObBDkeKwvnt28i_YdPXaeVER3bcRbefbkX_3VGTo_rOvLwHcd53Uz3RjQ4vA3Gkg880imT_Z92OCCyytlUXR3155ozZPlgZ-vH2N62UvIBYaMvz1_H2bV3i1mh4ONnRF_J5ssqksWvSADegL6-oTQd6MsoGAwa4e-4vK0UIOIEIjuVM4u2P19t_kWgXPKuPhtOPQP5NZDkf-iV5vTy0QglP4rZcB2fiQFp7y9lisoKrZDwpd93d6hNwn21p47r1ii-F6bE0d2ZrVFHN0DOPGnjzycLz_D729Q%22%2C%22expireTime%22%3A1773378802%7D; JSESSIONID=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJndWVzdCIsInNlc3Npb25TdGF0ZSI6IkdVRVNUIiwic2Vzc2lvbklkIjoicWMwNHE4NzZ4YWQ4MWF3ZXFwbzV0dnY4aC50ZXN0IiwidGltZXN0YW1wIjoxNzczMzc3ODg4MjIxfQ.0j7nioZwpYuuk_oKvQhsLf6aoaLJvPJ-nvRXxTViowvK9YOMJM3Eyzb_X4pYBMIVayw9mdY2WBDqMDDhDJA5dg; exp_hbeat=1; _fbp=fb.1.1773321509333.4615694219; BAGID=7ec1b56d-4121-497c-bb10-a94ff37d9eb5; crl8.fpcuid=24427367-f8e5-45d2-ba46-d54ffc94e422; unbxd.userId=uid-1773377893550-29161; unbxd.visit=first_time; unbxd.visitId=visitId-1773377893558-16540; _ga=GA1.1.232807683.1773377894; OptanonConsent=isGpcEnabled=0&datestamp=Fri+Mar+13+2026+10%3A28%3A14+GMT%2B0530+(India+Standard+Time)&version=202503.2.0&browserGpcFlag=0&isIABGlobal=false&hosts=&consentId=3c49e298-4d21-439b-8947-85c073bfaa96&interactionCount=2&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0002%3A1%2CC0003%3A1%2CC0004%3A1&intType=1&geolocation=US%3BFL&AwaitingReconsent=false; mp_express_mixpanel=%7B%22distinct_id%22%3A%20%2219ce233070a7c5-0b34f0edcba94-26061c51-100200-19ce233070b131d%22%2C%22bc_persist_updated%22%3A%201773377895849%7D; bc_invalidateUrlCache_targeting=1773377896838; _scid=xXqUehlhp16Dj3Ic2NYKcMsPUP4I0v5yk84XtQ; _scid_r=xXqUehlhp16Dj3Ic2NYKcMsPUP4I0v5yk84XtQ; _ScCbts=%5B%5D; spangle_uuid=2bfbce9f-2f83-44f1-9315-530d10d6e7d5; _aid=f78bddfa-1bf3-423d-98e5-2e4f790121a3; granify.uuid=464a5d9a-139c-44b6-b7bb-f6dabf880ee0; cto_bundle=KTenG19seUIxbmR6QjZiNSUyRjVsRTh5RUIyYnBlTG5hSnp2eUFUdkI4alhNZXpOWjZVVUdHc1FmS1ZadWhMUVUzMlYyYmVHb1Z0UkFQRGpLMW9FT3RFd05GblE0aGp0NklrTUJ1UkNldm9VRTBZbUYxU3NrZHZGbXc2ZGhiMFdsVjVzOGVIMExtNGZKV3FsUExRZmxuTGJ1cGptZyUzRCUzRA; granify.new_user.1447=true; _pin_unauth=dWlkPU9XRmxOamM0TWpjdFptWXlaQzAwTmpCakxXRXpOMll0WWpFNU1XVXlNVE0wWlRCbQ; _tt_enable_cookie=1; _ttp=01KKJRYNK934NHMPCE1Q7KNZHT_.tt.1; ttcsid_C4IQ11S17T561FR1HC40=1773377866246::7DpqFERFcRVSuxo3K3Ke.2.1773377902863.1; __attentive_id=9e6279375fee454fbcc1fe66e49f0830; __attentive_session_id=e4e989b55c584f5e922890ed08d5f3b2; __attentive_cco=1773377903860; _attn_=eyJ1Ijoie1wiY29cIjoxNzczMzIxNTI1OTE3LFwidW9cIjoxNzczMzc3OTAzODYyLFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcIjllNjI3OTM3NWZlZTQ1NGZiY2MxZmU2NmU0OWYwODMwXCJ9IiwiZWF0Ijoie1wiY29cIjoxNzczMzc3OTAzODQ5LFwidW9cIjoxNzczMzc3OTAzODQ5LFwibWFcIjozNjUwLFwiaW5cIjp0cnVlLFwidmFsXCI6XCJodHRwczovL2dya3JoLmV4cHJlc3MuY29tXCJ9In0=; _sctr=1%7C1773340200000; _attn_bopd_=unknown; __attentive_dv=1; __attentive_pv=1; __attentive_ss_referrer=ORGANIC; ttcsid=1773377866248::VYQpumED4PeTnn4uR8U5.2.1773377902863.0::1.-16223.0::382067.1.1075.33::0.0.0; ph_phc_38wmItYGu4CQmIV1zJRkXQbay671jQcSCDGcMKfiY5T_posthog=%7B%22%24device_id%22%3A%22019ce232-e9d0-7200-a9d2-1c9969502933%22%2C%22distinct_id%22%3A%22019ce232-e9d0-7200-a9d2-1c9969502933%22%2C%22%24sesid%22%3A%5B1773378266086%2C%22019ce58e-c9f1-729e-a951-eda36926f655%22%2C1773377866221%5D%2C%22%24initial_person_info%22%3A%7B%22r%22%3A%22%24direct%22%2C%22u%22%3A%22https%3A%2F%2Fwww.express.com%2F%22%7D%2C%22%24user_state%22%3A%22anonymous%22%7D; granify.session.1447=-1; bm_sz=7ED80172E2CEE5A5D479FC243A2A1D16~YAAQB3LMF9Kyfr+cAQAAAeyU5R/k7kQ0yr7JioFMT/a5rlyVbg/Xu1XKbll9PCAafMSOGovIUfL9IfMzgS93dtH3bWAIh18rpUDkvh1sDInSC0u0SiLFXEnsGhWY9umbj14PIhreCFaQIGT5oOuzPJeUW257LDgNok6BOoGO42v8NZ4ZjGn2bNaQgUPx1Urb1Er6Z7kih+sv980b68jPLZjjK0o40vIdbXYapVfCRvKSQV2uNae3Y2DtDUEBnETdbBSo6E9gMoST/zdLGK6DzskIhjnk7MMPp50SmLYDxCEMIbAp4OM4g7BPIOf73+pOmlfXgN+ZH30ur+BUmHjebdsCRKGHMTrxcg/AowndBSaQvv8aRPMR3XoaL6wIhna/ByO5RO8KBz2xWt/FaW/yTqraDtus6PoINxBNjQ==~3551554~3555896; _ga_RFQTHME9SL=GS2.1.s1773377893$o1$g0$t1773378268$j60$l0$h0; RT="z=1&dm=www.express.com&si=26472f54-47c4-49c6-aa13-67b2d1dabc9c&ss=mmofdxt1&sl=3&tt=brd&bcn=%2F%2F173bf105.akstat.io%2F&obo=2&rl=1"; _abck=F8D684018EF2734CE8DA83621DC8D462~-1~YAAQB3LMF2mzfr+cAQAAfPKU5Q9GhxMLjgIT6yRyE9S+pMwPOokJTXUdrQ9f+NAKJaeS/QZNhpRQiGYoV0QIvipBu+oTcLkL8g+JbYh6iYJ9HHcZQpvPDljjikfpul2Eafad8NBTcN871RXvAlUKTHs4HtiJ1d8LB7NjA+U+c5f4RSCto3S0LB1gbOf9IYO9R+4Yza5/wi7YU8n9I6BhCNQffKw4TtvSx/c3CUCet1AQC9zh9NXz/3AYJfyvzRwA9fcV7nyTS+KMXxUtTj1zE13zwDUO1hT/A6hNdGe0wRxgXd/UpoBgQGa1fHlZNIUs1ttr9J6H5Q8UonA+4ObYZzlakp9YsQa89kz8Pys+2G9CCLgIDD9MK5DbrdQJw9rOVh3S0CP2BXDz37QYUNmM1eTXMZQHFH3jO4GQYQxlNoE4Tvz03lnSZ90NeUS8BvW7rHmkcifTZcCL0hjtgJXQVVWz4y7n2RbXy14P9bCG5zQrhxigj1/7uqKTdblovUvf6zT1dL6T0wVAYDjwL1ykkZWpB1BQ0rjFMz4oZpugo8u4um/X5+V0wgqmYkQzdSjjUeZH9ukrI0JZtuYF9YXz5Fi4eAm0t00mzJSIZY01HrR81A+EHnSsAya3LYVRKEEfnpiCzHgU/hZAM1mJ3od1uN7eSYJVKhdDJ6p+76GUMng+Bi4=~-1~-1~-1~AAQAAAAF%2f%2f%2f%2f%2f4PYlw9TyIPDblwZYhPsKa0EpSKu+lxHCZtGskyi5yvFyUbzG9FrGfJfr%2fXSn0R6UGXKPmwwZ4PSoPJku7gsWNcsopa+hKBeiP06vLPZJQ7zNFiXBSi7v8YHscguFPSQaHqBMoM%3d~1773378329; _Elevar-apex=[1%2C%22LFjW1DR3NdT55WECwL5Zx%22%2C%221773377859%22%2C%221%22%2C%221773377893%22%2C{}%2C[[1%2C1%2C1]%2C[2%2C1%2C1]%2C[3%2C1%2C1]%2C[4%2C1%2C1]%2C[5%2C0%2C-1]%2C[6%2C0%2C-1]%2C[7%2C0%2C-1]]%2C%22{%5C%22_fbp%5C%22:%5C%22fb.1.1773321509333.4615694219%5C%22%2C%5C%22_ga%5C%22:%5C%22GA1.1.232807683.1773377894%5C%22%2C%5C%22_scid%5C%22:%5C%22xXqUehlhp16Dj3Ic2NYKcMsPUP4I0v5yk84XtQ%5C%22%2C%5C%22_ttp%5C%22:%5C%2201KKJRYNK934NHMPCE1Q7KNZHT_.tt.1%5C%22%2C%5C%22_ga_RFQTHME9SL%5C%22:%5C%22GS2.1.s1773377893$o1$g0$t0$j60$l0$h0%5C%22}%22%2C0]; akavpau_wwwexpcom=1773378570~id=a679eca3448b1f27deb99ac230157de6; bm_sv=C80375521ECE9439FECB8BB2B1E52A98~YAAQB3LMF+uzfr+cAQAAWPSU5R9kW+9bbcMppplDWzko7PWGd7x1PCbSr6k6f0zLn/SXoC43b0qFBwu2MmxLU/Zcnb2ANnixDp2RhGxIs3zIWHFkqt3jukyulLUMsPOqLkcAYRE3FoOhZKIIg6wRDGlZk2QAhAe76wOmrhAyi5bPTBNvx97KqnVod/aPYjDkQ/tZXX5iQemdMDbYQvSlHAtA41ZEsBsDuUWLByPcgVln/tSYVNuwnktsTL+SeX8M9Nw=~1',
    }
    headers['x-exp-rvn-cache-key'] = hashlib.md5(f"{search_key}-{time.time()}".encode('utf-8')).hexdigest()
    headers["cache-control"] = "no-store,no-cache,must-revalidate,max-age=0"
    headers["Pragma"] = "no-cache"
    headers["Expires"] = "0"
    headers["Connection"] = "close"
    json_data = {
        'operationName': 'RetailSearchQuery',
        'variables': {
            'payload': {
                'filter': '',
                'query': f'{search_key}',
                'servingConfig': 'desktop-mobile',
                'sort': '',
                'visitorId': '232807683.1773377894',
                'userId': '',
                'start': 0,
                'rows': 56,
            },
        },
        'query': 'query RetailSearchQuery($payload: RetailSearchInput) {\n  getRetailSearch(payload: $payload) {\n    didYouMean {\n      frequency\n      suggestion\n      __typename\n    }\n    facets {\n      facetId\n      name\n      position\n      values\n      __typename\n    }\n    pagination {\n      end\n      pageNumber\n      pageSize\n      start\n      totalProductCount\n      __typename\n    }\n    products {\n      availabilityStoreIds\n      averageOverallRating\n      colors {\n        color\n        defaultSku\n        defaultSkuUpc\n        imageSet\n        skuUpc\n        __typename\n      }\n      ensembleListPrice\n      ensembleSalePrice\n      faceoutVariantId\n      gender\n      isEnsemble\n      key\n      listPrice\n      marketplaceProduct\n      name\n      newProduct\n      onlineExclusive\n      onlineExclusivePromoMsg\n      paginationEnd\n      paginationStart\n      productDescription\n      productId\n      productImage\n      productURL\n      promoMessage\n      salePrice\n      totalReviewCount\n      __typename\n    }\n    redirect {\n      type\n      value\n      __typename\n    }\n    attributionToken\n    requestId\n    source\n    totalProductsWithMissingData\n    __typename\n  }\n}',
    }
    session = requests.Session()
    response = session.post('https://www.express.com/graphql', headers=headers, data=json.dumps(json_data), impersonate="chrome110")
    session.close()
    try:
        if response.status_code == 200:
            response_json = response.json()
            products = response_json["data"]["getRetailSearch"]["products"]
            for data_ in products:
                item_dict = dict()
                item_dict["name"] = data_.get("name",None)
                item_dict["product_url"] = "https://www.express.com"+data_.get("productURL","")
                item_dict["product_id"] = data_.get("productId",None)
                item_dict["gender"] = data_.get("gender",None)
                item_dict["mrp"] = data_.get("listPrice",None)
                item_dict["selling_price"] = data_.get("salePrice",None)
                if item_dict["selling_price"] and not item_dict["mrp"]:
                    item_dict["mrp"] = item_dict["selling_price"]
                elif item_dict["mrp"] and not item_dict["selling_price"]:
                    item_dict["selling_price"] = item_dict["mrp"]
                item_dict["image"] = data_.get("productImage", None)
                item_dict["rating"] = round(data_.get("averageOverallRating"),1) if data_.get("averageOverallRating") else None
                item_dict["review"] = data_.get("totalReviewCount")
                item_dict["colors"] = " | ".join({value["color"] for value in data_["colors"]})
                main_item_list.append(item_dict)

            return {"status_Code":response.status_code,
                    "data":main_item_list}
        else:
            return {"status_Code":response.status_code,"message":"having issue while getting response.."}
    except:
        return {"status_Code":500,"message":"internal server error.."}

@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10))
@app.get("/category/")
def category_detail():
    "how many categories we can scrape."
    main_category_info = list()
    headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/json',
        'origin': 'https://www.express.com',
        'priority': 'u=1, i',
        'referer': 'https://www.express.com/',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
        'x-exp-request-id': '53794034-c08c-4f16-ac72-313601edc59a',
        'x-exp-rvn-cache-key': '0b9df8f34a19f1af32aabd2a73dd3fc96fc4d58e89b8e3e477391551ce77380d',
        'x-exp-rvn-cacheable': 'true',
        'x-exp-rvn-query-classification': 'getUniversalNav',
        'x-exp-rvn-source': 'app_express.com',
    }
    headers['x-exp-rvn-cache-key'] = hashlib.md5(f"express-{time.time()}".encode('utf-8')).hexdigest()
    headers["cache-control"] = "no-store,no-cache,must-revalidate,max-age=0"
    headers["Pragma"] = "no-cache"
    headers["Expires"] = "0"
    headers["Connection"] = "close"
    json_data = {
        'operationName': 'getUniversalNav',
        'variables': {'useCache':False},
        'query': 'query getUniversalNav {\n  getUniversalNav {\n    headerProperty {\n      evergreenMessage\n      logoImage\n      linkText\n      linkHref\n      searchPageUrl\n      __typename\n    }\n    menuNavigation {\n      title\n      url\n      disclaimer\n      children {\n        carouselItems {\n          image\n          imageAltText\n          title\n          url\n          __typename\n        }\n        label\n        columnType\n        titleColor\n        shopAllText\n        shopAllUrl\n        links {\n          title\n          url\n          promoMessage\n          titleColor\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    navigationGlobalControls {\n      promoColorCode\n      hideShopAllLinks\n      __typename\n    }\n    __typename\n  }\n}',
    }
    try:
        session = requests.Session()
        response = session.post('https://www.express.com/graphql', impersonate="chrome101", headers=headers, json=json_data)
        session.close()

        if response.status_code == 200:
            response_json = response.json()
            main_nav_key = response_json["data"]["getUniversalNav"]["menuNavigation"]
            for main_nav in main_nav_key:
                main_cat_name = main_nav["title"]
                main_cat_url = main_nav.get("url",None)
                for child in main_nav["children"]:
                    if child["links"]:
                        sub_lable = child["label"]
                        for sub_cate in child["links"]:
                            category_dict=dict()
                            sub_cat_title = sub_cate["title"]
                            sub_cat_url = "https://www.express.com"+sub_cate["url"]
                            category_dict["main_category"] = main_cat_name
                            category_dict["main_category_url"] = main_cat_url
                            category_dict["sub_category"] = f"{sub_lable} -> {sub_cat_title}"
                            category_dict["sub_category_url"] = f"{sub_cat_url}"
                            main_category_info.append(category_dict)
            return {"stats_Code":response.status_code,"data":main_category_info}
        else:
            return {"status_Code":200,"message":"having issue while getting response.."}
    except Exception as e:
        return {"status_Code":500,"message":"internal server error.."}


    # Note: json_data will not be serialized by requests
    # exactly as it was in the original request.
    # data = '{"operationName":"getUniversalNav","variables":{},"query":"query getUniversalNav {\\n  getUniversalNav {\\n    headerProperty {\\n      evergreenMessage\\n      logoImage\\n      linkText\\n      linkHref\\n      searchPageUrl\\n      __typename\\n    }\\n    menuNavigation {\\n      title\\n      url\\n      disclaimer\\n      children {\\n        carouselItems {\\n          image\\n          imageAltText\\n          title\\n          url\\n          __typename\\n        }\\n        label\\n        columnType\\n        titleColor\\n        shopAllText\\n        shopAllUrl\\n        links {\\n          title\\n          url\\n          promoMessage\\n          titleColor\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    navigationGlobalControls {\\n      promoColorCode\\n      hideShopAllLinks\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
    # response = requests.post('https://www.express.com/graphql', cookies=cookies, headers=headers, data=data)

@retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10))
@app.get("/pdp/")
def express_pdp(product_url: str):
    main_list = list()
    max_retires = 5
    try:
        try:
            product_id = product_url.split("/pro/")[-1].split("/color")[0]
        except:
            product_id = product_url.split("/pro/")[-1]
        for i in range(max_retires):
            start_time = time.time()
            headers = {
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9',
                'content-type': 'application/json',
                'origin': 'https://www.express.com',
                'priority': 'u=1, i',
                'referer': f'{product_url}',
                'sec-ch-ua': '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
                'x-exp-request-id': 'c1c1a25f-b212-41b6-8fa9-d9659f4ce8d2',
                'x-exp-rvn-cache-key': 'f33b558d8b729d21aa0d372d54d3d5f33a2c640d6da40500c24822e0ea868684',
                'x-exp-rvn-cacheable': 'true',
                'x-exp-rvn-query-classification': 'product',
                'x-exp-rvn-source': 'app_express.com',
            }
            json_data = {
                'operationName': 'ProductQuery',
                'variables': {
                    'productId': f'{product_id}',
                    'useCache': False,
                },
                'query': 'query ProductQuery($productId: String!) {\n  product(id: $productId) {\n    bopisEligible\n    categories {\n      name\n      key\n      __typename\n    }\n    clearancePromoMessage\n    finalsalePromoMessage\n    colorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    clearanceColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    finalColorsPromoMessage {\n      colorCode\n      message\n      __typename\n    }\n    collection\n    crossRelDetailMessage\n    crossRelProductURL\n    EFOProduct\n    expressProductType\n    fabricCare\n    fabricDetailImages {\n      caption\n      image\n      __typename\n    }\n    firstProductNameInEnsemble\n    gender\n    internationalShippingAvailable\n    listPrice\n    marketPlaceProduct\n    name\n    newProduct\n    onlineExclusive\n    onlineExclusivePromoMsg\n    pdpCrossSellHeader\n    productDescription {\n      type\n      content\n      __typename\n    }\n    matchingSet {\n      color\n      skus\n      __typename\n    }\n    productDetail\n    productFeatures\n    productId\n    productImage\n    productInventory\n    productURL\n    promoMessage\n    recsAlgorithm\n    originRecsAlgorithm\n    salePrice\n    type\n    breadCrumbSummary\n    breadCrumbCategory {\n      categoryName\n      h1CategoryName\n      links {\n        rel\n        href\n        __typename\n      }\n      breadCrumbCategory {\n        categoryName\n        h1CategoryName\n        links {\n          rel\n          href\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    colorSlices {\n      color\n      colorFamily\n      defaultSlice\n      faceoutModelDetails {\n        model1\n        model2\n        __typename\n      }\n      ipColorCode\n      hasWaistAndInseam\n      swatchURL\n      imageMap {\n        All {\n          LARGE\n          MAIN\n          __typename\n        }\n        Default {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model1 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model2 {\n          LARGE\n          MAIN\n          __typename\n        }\n        Model3 {\n          LARGE\n          MAIN\n          __typename\n        }\n        __typename\n      }\n      mediaMap {\n        main {\n          url\n          sequenceId\n          __typename\n        }\n        large {\n          url\n          sequenceId\n          __typename\n        }\n        modelInfo {\n          sequenceId\n          labelText\n          __typename\n        }\n        __typename\n      }\n      onlineSkus\n      skus {\n        backOrderable\n        backOrderDate\n        clearanceDisclaimer\n        categoryType\n        displayMSRP\n        displayPrice\n        ext\n        finalSaleDisclaimer\n        inseam\n        inStoreInventoryCount\n        inventoryMessage\n        isFinalSale\n        isInStockOnline\n        miraklOffer {\n          minimumShippingPrice\n          sellerId\n          sellerName\n          __typename\n        }\n        marketPlaceSku\n        onClearance\n        onSale\n        onlineExclusive\n        onlineInventoryCount\n        size\n        sizeName\n        skuId\n        __typename\n      }\n      __typename\n    }\n    originRecs {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      __typename\n    }\n    relatedProducts {\n      listPrice\n      marketPlaceProduct\n      name\n      productId\n      productImage\n      productURL\n      salePrice\n      colorSlices {\n        color\n        defaultSlice\n        __typename\n      }\n      __typename\n    }\n    storeTier\n    icons {\n      icon\n      category\n      __typename\n    }\n    __typename\n  }\n}',
            }
            uniq_key = hashlib.md5(f"{product_id}-{time.time()}".encode()).hexdigest()
            headers["x-exp-rvn-cache-key"] = uniq_key
            headers["Connection"] = "close"
            headers["x-exp-request-id"] = str(uuid.uuid4())
            headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            headers["Pragma"] = "no-cache"
            headers["Expires"] = "0"
            headers["x-exp-rvn-cacheable"] = "false"
            session = requests.Session()
            response = session.post('https://www.express.com/graphql', headers=headers,json=json_data,timeout=100,impersonate="chrome120",verify=False,)
            session.close()
            if response.status_code ==200:
                break
        if response.status_code== 200:
            row = response.json()
            try:
                if row["errors"]:
                    return {'statusCode': 408,
                        'error_message': 'Request timeout, failed to reach host'}
            except Exception as e:
                pass
            # Website
            Website = "express"
            # Name
            try:
                value = row["data"]["product"]["name"]
                Name = value.strip()
            except Exception as e:
                Name = "N/A"
            #Image URL
            try:
                Image_URL = row["data"]["product"]["productImage"]
            except Exception as e:
                Image_URL = "N/A"
            # PID
            try:
                value = row["data"]["product"]["productId"]
                PID = value
            except Exception as e:
                PID = product_id
            #SKU pending
            try:
                SKU_main = row["data"]["product"]["colorSlices"][0]["onlineSkus"][0]
            except Exception as e:
                try:
                    if len(row["data"]["product"]["colorSlices"]) >1 :
                        SKU_main = row["data"]["product"]["colorSlices"][1]["onlineSkus"][0]
                    else: SKU_main = "N/A"
                except Exception as e:
                    SKU_main = "N/A"
                SKU_main ="N/A" if not SKU_main else SKU_main
            #IsInStock penidng
            instock_flag = False
            IsInStock = False
            #Brand
            Brand = "EXPRESS"
            Colour = None

            #rating review request
            for i in range(max_retires):
                json_data = {
                    'operationName': 'ReviewContainerQuery',
                    'variables': {
                        'id': product_id,
                        'useCache': False,
                        'limit': 3,
                        'offset': 0,
                    },
                    'query': 'query ReviewContainerQuery($id: String!, $limit: Int, $offset: Int, $sort: String, $useCache: Boolean) {\n  feedback(\n    id: $id\n    limit: $limit\n    offset: $offset\n    sort: $sort\n    useCache: $useCache\n  ) {\n    ratings {\n      count\n      metrics {\n        overall\n        size\n        __typename\n      }\n      recommend {\n        yes\n        no\n        __typename\n      }\n      __typename\n    }\n    results {\n      count\n      reviews {\n        author {\n          id\n          age\n          badges\n          frequency\n          location\n          name\n          __typename\n        }\n        content {\n          title\n          text\n          occasions\n          photos\n          __typename\n        }\n        helpful {\n          yes\n          no\n          __typename\n        }\n        date\n        id\n        ratings {\n          overall\n          size\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}',
                }
                uniq_key = hashlib.md5(f"{product_id}-{time.time()}".encode()).hexdigest()
                headers["x-exp-rvn-cache-key"] = uniq_key
                headers["Connection"] = "close"
                headers["x-exp-request-id"] = str(uuid.uuid4())
                headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
                headers["Pragma"] = "no-cache"
                headers["Expires"] = "0"
                headers["x-exp-rvn-cacheable"] = "false"
                response_review = requests.post('https://www.express.com/graphql',headers=headers,json=json_data,timeout=100,impersonate="chrome120", verify=False)
                if response_review.status_code == 200:
                    break
            if response_review.status_code==200:
                review_data = response_review.json()
                # Num Ratings
                try:
                    num_rating = review_data["data"]["feedback"]["ratings"]["count"]
                    Num_Ratings = num_rating if num_rating else "N/A"
                except Exception as e:
                    Num_Ratings = "N/A"

                # -------------------------------
                # Average Ratings
                try:
                    avg_rating = review_data["data"]["feedback"]["ratings"]["metrics"]["overall"]
                    Average_Ratings = round(avg_rating, 1) if avg_rating else "N/A"
                except Exception as e:
                    Average_Ratings = "N/A"
            else:
                Num_Ratings = "N/A"
                Average_Ratings = "N/A"

            #gender
            try:
                val = row["data"]["product"]["gender"]
                Gender = val if val else None
            except Exception as e:
                print("Gender Error:", e)
                Gender = None
            #Alternate Image URLs
            Alternate_iamge_urls = list()
            #Link URL
            Link_URL = product_url

            # Category
            try:
                value = row["data"]["product"]["breadCrumbSummary"]
                if value:
                    value = "/".join([key for key in value.keys()])
                Category = value if value else "N/A"
            except Exception as e:
                Category = "N/A"

            #Description
            # -------------------------------
            # Short Description
            try:
                value = row["data"]["product"]["productDescription"][0]["type"]
                if value == "paragraph":
                    short_desc = row["data"]["product"]["productDescription"][0]['content']
                    text = " ".join([text for text in short_desc])
                Short_Description = text.strip()
            except Exception as e:
                print("Short Description Error:", e)
                Short_Description = None

            # -------------------------------
            # Description
            try:
                description_list = []
                description_list.append(Short_Description)
                # feature
                value = row["data"]["product"]["productFeatures"]
                if value:
                    feature = " ".join([text for text in value]).strip()
                    description_list.append(feature)
                else:
                    value = None
                # rest text
                demo = row["data"]["product"]["icons"]
                if demo:
                    extra_text = " ".join([text["icon"] for text in demo]).strip()
                    description_list.append(extra_text)
                else:
                    demo = None
                Description =remove_extra_spaces("|".join(description_list).strip())
            except Exception as e:
                print("Description Error:", e)
                Description = "N/A"
            # -------------------------------
            # Price
            try:
                price_value = row["data"]["product"]["listPrice"]
                Mrp = float(price_value.replace("$", "").replace(",", "")) if price_value else None
            except Exception as e:
                Mrp = None
            # -------------------------------
            # Sale Price
            try:
                sale_value = row["data"]["product"]["salePrice"]
                Sale_Price = float(sale_value.replace("$", "").replace(",", "")) if sale_value else None
            except Exception as e:
                Sale_Price = None
            Price_main = None
            Sale_Price_main = None
            if Mrp and Sale_Price:
                Price_main = Mrp
                Sale_Price_main = str(Sale_Price)
                Mrp = Mrp
                Sale_Price = Sale_Price
            elif Mrp and not Sale_Price:
                Price_main =Mrp
                Sale_Price_main =str(Mrp)
                Sale_Price = Mrp
                Mrp = Mrp
            elif Sale_Price and not Mrp:
                Price_main = Sale_Price
                Sale_Price_main = str(Sale_Price)
                Sale_Price = Sale_Price
                Mrp = Sale_Price

            # -------------------------------
            # Final Price
            try:
                Final_value = Sale_Price_main
            except Exception as e:
                Final_Price = "N/A"

            # -------------------------------
            # Discount
            try:
                if Mrp and Sale_Price:
                    discount_value = Mrp - Sale_Price
                Discount = round(discount_value, 2) if discount_value != 0 else "N/A"
            except Exception as e:
                Discount = "N/A"
            #-----------------------------
            # Gender
            try:
                val = row["data"]["product"]["gender"]
                Gender = val if val else "N/A"
            except Exception as e:
                Gender = "N/A"

            Size_list = list()
            Varint_Price_list = list()
            Variant_data = list()
            #color wise main list , inside it size wise list
            try:
                variation_key = row["data"]["product"]["colorSlices"]
                for data in variation_key:
                    if len(variation_key) == 1 and variation_key[0]["onlineSkus"] == []:
                        # Alternate Image URLs
                        try:
                            imageall_value = variation_key[0]["mediaMap"]["large"]
                            if imageall_value:
                                for images in imageall_value[1:]:
                                    Alternate_iamge_urls.append(images["url"])

                        except Exception as e:
                            print("Alternate Image URLs Error:", e)
                            Alternate_iamge_urls = "N/A"
                        try:
                            IsInStock = variation_key[0]["skus"][0]["isInStockOnline"]
                        except Exception as e:
                            print("IsInStock Error:", e)
                            IsInStock = False
                        try:
                            val = product_id
                            SKU = val if val else None
                        except Exception as e:
                            print("SKU Error:", e)
                            SKU = "N/A"
                        Size_list = "N/A"
                        Varint_Price_list = "N/A"
                        varient_dict = dict()
                        varient_dict["available"] = IsInStock
                        varient_dict["Price"] = Sale_Price
                        varient_dict["Mrp"] = Mrp
                        varient_dict['size'] = "N/A"
                        varient_dict["sku"] =f"{PID}"
                        varient_dict["colour"] = "N/A"
                        Variant_data.append(varient_dict)
                        SKU_main = f"{PID}"

                    else:
                        sku_group_found = False
                        sku_group = data.get("onlineSkus", [])
                        if sku_group:
                            sku_group_found = True
                            # Colour --- variationnn
                            try:
                                val = data["color"]
                                Colour = val if val else "N/A"
                            except Exception as e:
                                Colour = "N/A"
                            # Alternate Image URLs
                            try:
                                imageall_value = data["mediaMap"]["large"]
                                if imageall_value:
                                    Alternate_iamge_urls.extend(
                                        images["url"] for images in imageall_value[1:]
                                    )
                            except Exception as e:
                                Alternate_iamge_urls = "N/A"
                            #size variation taken
                            sizes = data["skus"]
                            for size_data in sizes:
                                if size_data["skuId"] in sku_group:
                                    Size_list.append(size_data["sizeName"].replace(" ","-"))
                                    Varint_Price_list.append(f'{size_data["sizeName"].replace(" ","-")}-{Sale_Price}')
                                    varient_dict = dict()
                                    varient_dict["available"] = size_data["isInStockOnline"]
                                    if size_data["isInStockOnline"]:
                                        if not instock_flag:
                                            IsInStock = size_data["isInStockOnline"]
                                        instock_flag = True
                                    varient_dict["Price"] = Sale_Price
                                    varient_dict["Mrp"] = Mrp
                                    varient_dict['size'] = size_data["sizeName"].replace(" ","-")
                                    varient_dict["sku"] = size_data["skuId"]
                                    varient_dict["colour"] = Colour
                                    Variant_data.append(varient_dict)

                #final json return
                result = dict()
                result["Name"] = Name
                result["Image URL"] = Image_URL
                result["SKU"] = SKU_main if SKU_main != "N/A" else f"{PID}"
                result["PID"] = str(PID)
                result["IsInStock"] = "True" if IsInStock else "False"
                result["Price Currency"] = "USD"
                result["Sale Price"] = Sale_Price_main
                result["Final Price"] = Sale_Price_main
                result["Mrp"] = Mrp
                result["Discount"] = Discount
                result["Manufacturer"] = "N/A"
                result["Brand"] = Brand
                result["Colour"] = Colour if Colour else "N/A"
                result["Num Ratings"] = Num_Ratings
                result["Average Ratings"] = Average_Ratings
                result["Gender"] = Gender
                result["Alternate Image URLs"] = " | ".join(Alternate_iamge_urls) if Alternate_iamge_urls else "N/A"
                result["Link URL"] = Link_URL
                result["Category"] = Category
                result["Description"] = Description if Description != "" else "N/A"
                result["Size"] = " | ".join(list(set(Size_list))) if Size_list and Size_list != "N/A" and Size_list != [] else "N/A"
                result["Varint_Price"] = " | ".join(list(set(Varint_Price_list))) if Varint_Price_list and Varint_Price_list !="N/A" and Varint_Price_list != [] else f"{Sale_Price}"
                varient_dict1 = dict()
                Variant_data1 = list()
                varient_dict1["available"] = False
                varient_dict1["Price"] = Sale_Price
                varient_dict1["Mrp"] = Mrp
                varient_dict1['size'] = "N/A"
                varient_dict1["sku"] = f"{PID}"
                varient_dict1["colour"] = "N/A"
                Variant_data1.append(varient_dict1)
                result["Variant_data"] = Variant_data if Variant_data else Variant_data1
                result["policy"] = "N/A"
                # main_dict["results"] = {"results":result}
                main_list.append(result)
                return {"statusCode":200,"data":main_list}

            except Exception as e:
                return {"status_code":500,"message":f"Internal Server Error {str(e)}"}

    except Exception as e:
        print(e)
        return {"status_code":500,"message":"Internal Server Error"}

def multi_pdp_response(response :str,url:str):
    pass

@app.post("/read_excel/")
async def read_pdp_excel(file: UploadFile = File(...)):
    contents = await file.read()
    df = pd.read_excel(io.BytesIO(contents))
    urls = df.iloc[:, 0].dropna().tolist()
    print(len(urls))

if __name__ == '__main__':
    uvicorn.run( "plp_api_search:app", host="192.168.1.4", port=8383, reload=True)


    # event = {"search_key":"tshirt"}
    # pdp_url ="https://www.express.com/clothing/women/mixed-media-scoop-neck-drop-waist-maxi-dress/pro/07852594/color/French%20Blue/"
    # # data_json = search_value(event["search_key"])
    # # category_info = category_detail()
    # pdp_data = express_pdp(pdp_url)
    # # print(json.dumps(data_json))
    # # print(json.dumps(category_info, indent=4))
    # print(json.dumps(pdp_data, indent=4))
