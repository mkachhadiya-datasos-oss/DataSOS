import pymysql
from fastapi import FastAPI , HTTPException ,Request
from fastapi.templating import Jinja2Templates
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from fastapi.responses import FileResponse
import webbrowser

def connection_():
    conn = pymysql.connect(host='localhost',user='root',database='flight_api_db')
    cur = conn.cursor()
    return conn,cur

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# ADD THIS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # allow all origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index.html",{"request":request})

@app.get("/search")
def flight_search_date(column:str,value:str):
    allowed_columns = [
        "Airline", "Route_From", "Route_To",
        "DOT", "Class", "Category", "Price"
    ]

    if column not in allowed_columns:
        raise HTTPException(status_code=400, detail="Invalid column")
    conn,cur =connection_()
    query = f"select * from result_table where {column} LIKE %s limit 15"
    cur.execute(query,(f"%{value}%",))
    results  = cur.fetchall()
    columns= [col[0] for col in cur.description]
    data = list()
    for row in results:
        data.append(dict(zip(columns,row)))
    return data


def download_data(data,option):
    df = pd.DataFrame(data)
    if option == "excel":
        file = "data_sample_excel.xlsx"
        df.to_excel(file,index=False)
    if option == "csv":
        file = "data_sample_csv.csv"
        df.to_csv(file,index=False)
    if option == "json":
        file = "data_sample_json.json"
        df.to_json(file,orient="records")
    return file

@app.get("/download")
def download(column:str,value:str,type:str):
    conn,cur =connection_()
    query = f"select * from result_table where {column} like %s limit 15"
    cur.execute(query,(f"%{value.lower()}%",))
    result = cur.fetchall()
    columns = [col[0] for col in cur.description]
    data = list()
    for row in result:
        data.append(dict(zip(columns,row)))
    file = download_data(data, type)
    return FileResponse(file,filename=file)


if __name__ == "__main__":
    # flight_search_date("11-03-2026")

    uvicorn.run("flight_api:app",host="192.168.1.4",port=8083, reload=True)