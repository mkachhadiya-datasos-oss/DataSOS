import scrapy

class GovCheckSexoffendersItem(scrapy.Item):
    def __setitem__(self, key, value):
        if not key in self.values():
            self.fields[key] =scrapy.Field()
            self._values[key] = value

class GovCheckOffensesItem(scrapy.Item):
    def __setitem__(self, key, value):
        if not key in self.values():
            self.fields[key] = scrapy.Field()
            self._values[key] = value
