import gov_check_sexoffenders.config_use as db
import re
from datetime import datetime
from scrapy.cmdline import execute
from gov_check_sexoffenders.items import *
from gov_check_sexoffenders.common_function import *

class PdpPageReadSpider(scrapy.Spider):
    name = "pdp_page_read"
    # vehicle_path = fr"{db.pdp_pagesave_Vehicle}/{main_id}.html"

    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)

    def start_requests(self):
        conn, cur = db.conn_()
        query = f"select * from {db.plp_table_creation_new} where status='pending' and status_main_pdp='done' and status_address='done' and status_scars='done' and status_vehicle='done' and status_image='done'"
        cur.execute(query)
        records = cur.fetchall()
        print("len of records :", len(records))
        for data in records:
            product_url = data.get("pdp_link")
            first_name = data.get("first_name")
            last_name = data.get("last_name")
            id_ = data.get("id")
            main_id = "".join(product_url.split("&Id=")[-1]).replace(r"/", "_").replace(r"\\", "_").replace("+", "_")
            main_pdp_path = fr"{db.pdp_pagesave_detail}/{first_name}_{last_name}_{main_id}.html"
            yield scrapy.Request(url=f"file://{main_pdp_path}", dont_filter=True, callback=self.parse,cb_kwargs={"main_id":main_id,"first_name":first_name,"last_name":last_name,"id_":id_})

    def parse(self, response,**kwargs):
        main_id = kwargs["main_id"]
        first_name_search = kwargs["first_name"]
        last_name_search = kwargs["last_name"]
        id_ = kwargs["id_"]
        #file id
        file_id = main_id

        #offender
        offender = clean_text(" ".join(response.xpath('//div[@id="offendermenu"]/preceding-sibling::div/text()').getall()))

        #offender_Status
        offender_Status = response.xpath('//div[@id="offendermenu"]/preceding-sibling::div//div/text()').get()
        if offender_Status:
            offender_Status = clean_text(offender_Status)
        else:
            offender_Status = None

        #absconder detail
        absconder_detail = response.xpath('//div[@id="ctl00_ContentPlaceHolder1_OffenderDetails1_panelAD"][.//b/u[contains(text(),"Absconder Details")]]/text()').get()
        if absconder_detail:
            absconder_detail = clean_text(absconder_detail)
        else:
            absconder_detail = None

        name_header = response.xpath('//div[@class="header"][contains(text(),"Name:")]')
        #First Name
        first_name = name_header.xpath('.//following-sibling::div[@class="Row"][./div[contains(text(),"First Name")]]/text()').getall()
        if first_name:
            first_name = clean_text(" ".join(first_name).replace("&nbsp;"," "))
        else:
            first_name = None

        #Middle Name
        middle_name = name_header.xpath('.//following-sibling::div[@class="Row"][./div[contains(text(),"Middle Name")]]/text()').getall()
        if middle_name:
            middle_name =clean_text(" ".join(middle_name).replace("&nbsp;"," "))
        else:
            middle_name = None

        #Last Name
        last_name = name_header.xpath('.//following-sibling::div[@class="Row"][./div[contains(text(),"Last Name")]]/text()').getall()
        if last_name:
            last_name = clean_text(" ".join(last_name).replace("&nbsp;"," "))
        else:
            last_name = None

        #Aliases
        aliases = response.xpath('//div[@class="header"][contains(text(),"Aliases:")]/following-sibling::div/text()').getall()
        if aliases and len(aliases)>1:
            aliases = clean_text(";".join(aliases))
        elif aliases:
            aliases = clean_text(" ".join(aliases))
        else:
            aliases = None

        #gender related details
        gender_header = response.xpath('//div[@class="header"][contains(text(),"Gender/Race/DOB")]')

        #gender
        gender = clean_text(" ".join(gender_header.xpath('.//following-sibling::div[./div[contains(text(),"Gender")]]/text()').getall()))

        #Race
        race = clean_text(" ".join(gender_header.xpath('.//following-sibling::div[./div[contains(text(),"Race")]]/text()').getall()))

        #Ethnicity
        ethnicity = clean_text(" ".join(gender_header.xpath('.//following-sibling::div[./div[contains(text(),"Ethnicity")]]/text()').getall()))

        #Year of Birth
        year_of_birth =  clean_text(" ".join(gender_header.xpath('.//following-sibling::div[./div[contains(text(),"Year of Birth")]]/text()').getall()))

        #physical description
        physical_desc_header = response.xpath('//div[@class="header"][contains(text(),"Physical Description")]')

        #Height
        height = clean_text(" ".join(physical_desc_header.xpath('.//following-sibling::div[./div[contains(text(),"Height")]]/text()').getall()))

        #Weight
        weight = clean_text(" ".join(physical_desc_header.xpath('.//following-sibling::div[./div[contains(text(),"Weight")]]/text()').getall()))

        #Hair Color
        hair_color = clean_text(" ".join(physical_desc_header.xpath('.//following-sibling::div[./div[contains(text(),"Hair Color")]]/text()').getall()))

        #Eye Color
        eye_color = clean_text(" ".join(physical_desc_header.xpath('.//following-sibling::div[./div[contains(text(),"Eye Color")]]/text()').getall()))

        #Tier Level
        tier_level = clean_text(" ".join(response.xpath('//div[@class="header"][contains(text(),"Tier Level")]/following-sibling::div[./div[contains(text(),"Tier Level")]]/text()').getall()))

        #Primary address box
        primary_add_header = response.xpath('//div[@class="header"][contains(text(),"Primary Address")]')

        #Primary Address
        primary_address = clean_text(",".join(primary_add_header.xpath('.//following-sibling::div[not(descendant::div)]/text()').getall()))
        if "No record found" in primary_address:
            primary_address=None
        #County
        county = clean_text(" ".join(primary_add_header.xpath('.//following-sibling::div[./div[contains(text(),"County")]]/text()').getall()))

        #Start Date
        start_date = clean_text(" ".join(primary_add_header.xpath('.//following-sibling::div[./div[contains(text(),"Start Date")]]/text()').getall()))

        #End Date
        end_date =  clean_text(" ".join(primary_add_header.xpath('.//following-sibling::div[./div[contains(text(),"End Date")]]/text()').getall()))

        #Photo
        photo = f"{main_id}.jpg"

        #Photo Date
        photo_Date =  clean_text(" ".join(response.xpath('//span[@id="ctl00_ContentPlaceHolder1_OffenderDetails1_spanPicDate"]/text()').getall()))
        item = GovCheckSexoffendersItem()
        item["id_"] = id_
        item["file_id"]= file_id
        item["offender"]= offender
        item["offender_Status"]= offender_Status
        item["absconder_detail"]= absconder_detail
        item["first_name"]= first_name
        item["middle_name"]= middle_name
        item["last_name"]= last_name
        item["aliases"]= aliases
        item["gender"]=gender
        item["race"]= race
        item["ethnicity"]= ethnicity
        item["year_of_birth"]= year_of_birth
        item["height"]= height
        item["weight"]= weight
        item["hair_color"]= hair_color
        item["eye_color"]= eye_color
        item["tier_level"]= tier_level
        item["primary_address"]= primary_address
        item["county"]= county
        item["start_date"]= start_date
        item["end_date"]= end_date
        item["photo"]= photo
        item["photo_Date"]= photo_Date

        item_offender = GovCheckOffensesItem()
        #offenses details
        offenses_table = response.xpath('//div[@class="header"][contains(text(),"Offenses")]/following-sibling::div/table//tr[position()>1]')
        count = 0
        for offens in offenses_table:
            count+=1
            # Offense Counter
            offense_counter = count

            #Conviction Date
            conviction_date = offens.xpath('.//td[1]//text()').get()

            #Conviction Description
            conviction_description = offens.xpath('.//td[2]/a/text()').get()

            #Court Name
            court_name = clean_text(" ".join(offens.xpath('.//td[3]//text()').getall()))

            #Conviction Name
            conviction_name = clean_text(" ".join(offens.xpath('.//td[4]//text()').getall()))

            #Offense Location
            offense_location = offens.xpath('.//td[5]//text()').get()

            #Institution Name
            institution_name = offens.xpath('.//td[6]//text()').get()
            item_offender["id_"] = id_
            item_offender["file_id"] = file_id
            item_offender["offense_counter"] = offense_counter
            item_offender["conviction_date"] = conviction_date
            item_offender["conviction_description"] = conviction_description
            item_offender["court_name"] = court_name
            item_offender["conviction_name"] = conviction_name
            item_offender["offense_location"] = offense_location
            item_offender["institution_name"] = institution_name
            yield item_offender

        address_path = fr"{db.pdp_pagesave_OtherAddress}/{first_name_search}_{last_name_search}_{main_id}.html"
        yield scrapy.Request(f"file://{address_path}",dont_filter=True,callback=self.parse_address,cb_kwargs={"main_id":main_id,"first_name":first_name_search,"last_name":last_name_search,"item":item,"id_":id_})

    def parse_address(self,response,**kwargs):
        item = kwargs["item"]
        first_name = kwargs["first_name"]
        last_name = kwargs["last_name"]
        main_id = kwargs["main_id"]
        id_ = kwargs["id_"]

        # Employer Addresses
        employer_address = clean_text(",".join(response.xpath('//div[@class="header"][contains(text(),"Employer Addresses:")]/following-sibling::div//text()').getall()))
        if  not employer_address or "No records found" in employer_address:
            employer_address = None
        else:
            employer_address = employer_address.replace(", ,",",").replace(",,",",")

        #School Addreses
        school_address = clean_text(",".join(response.xpath('//div[@class="header"][contains(text(),"School Addresses:")]/following-sibling::div//text()').getall()))
        if not school_address or "No records found" in school_address:
            school_address = None
        else:
            school_address = school_address.replace(", ,",",").replace(",,",",")

        #Other Address
        other_address = clean_text(",".join(response.xpath('//div[@class="header"][contains(text()," Other Addresses")]/following-sibling::div//text()').getall()))
        if  not other_address or "No records found" in other_address:
            other_address = None
        else:
            other_address = other_address.replace(", ,",",").replace(",,",",")

        item["employer_address"] = employer_address
        item["school_address"] = school_address
        item["other_address"] = other_address
        scras_path = fr"{db.pdp_pagesave_Scars}/{first_name}_{last_name}_{main_id}.html"
        yield scrapy.Request(f"file://{scras_path}",dont_filter=True,callback=self.parstattoo_scars,cb_kwargs={"main_id":main_id,"first_name":first_name,"last_name":last_name,"item":item,"id_":id_})

    def parstattoo_scars(self,response,**kwargs):
        item = kwargs["item"]
        first_name = kwargs["first_name"]
        last_name = kwargs["last_name"]
        main_id = kwargs["main_id"]
        id_ = kwargs["id_"]
        #scars table
        scars_data=None
        scras_table = response.xpath('//div[./div[@class="header"][contains(text(),"Scars")]]/table//tr[position()>1]')
        if scras_table.get():
            scars_list=list()
            for scars_data in scras_table:
                keys = scars_data.xpath('.//td[1]/text()').get()
                values = scars_data.xpath('.//td[2]/text()').get()
                scars_list.append(f"{keys} : {values}")
            if scars_list and len(scars_list) >1:
                scars_data = clean_text("; ".join(scars_list))
            elif scars_list:
                scars_data = clean_text("".join(scars_list))
            else:
                scars_data = None

        #marks
        marks = response.xpath('//div[./div[@class="header"][contains(text(),"Marks")]]/table//tr[position()>1]')
        marks_data = None
        if marks.get():
            marks_list = list()
            for mark in marks:
                key = mark.xpath('.//td[1]/text()').get()
                values = mark.xpath('.//td[2]/text()').get()
                marks_list.append(f"{key} : {values}")
            if marks_list and len(marks_list) > 1:
                marks_data = clean_text("; ".join(marks_list))
            elif marks_list:
                marks_data = clean_text("".join(marks_list))
            else:
                marks_data = None

        ##tattose
        tattoos = response.xpath('//div[./div[@class="header"][contains(text(),"Tattoos")]]/table//tr[position()>1]')
        tattoo = None
        if tattoos.get():
            tattoos_list = list()
            for tatoo in tattoos:
                key = tatoo.xpath('.//td[1]/text()').get()
                values = tatoo.xpath('.//td[2]/text()').get()
                tattoos_list.append(f"{key} : {values}")
            if tattoos_list and len(tattoos_list) > 1:
                tattoo = clean_text("; ".join(tattoos_list))
            elif tattoos_list:
                tattoo = clean_text("".join(tattoos_list))
            else:
                tattoo = None
        item["scars"] = scars_data
        item["marks"] = marks_data
        item["tattoos"] = tattoo
        item["collection_date"] = datetime.now().strftime("%m/%d/%Y")
        yield item

if __name__ == "__main__":
    execute("scrapy crawl pdp_page_read".split())






