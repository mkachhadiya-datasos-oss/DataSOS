from datetime import datetime
import pymysql
import os

year_month = datetime.now().strftime("%Y_%m")
year_month = "2026_04"
#deathbycaptch credential ....
user_for_captch = 'kartikrramanuj'
pass_for_captch = 'kartikdbc123$'

# table name conversion
input_table = "input_name"
plp_listing_table = "plp_listing_table"
pdp_table_name = "pdp_data_table"
plp_table_creation_new = "plp_table_creation_new"
offenders_data = "offenders_data"
offencese = "offencese"

#path for page save and captcha images save
captch_image_store_path = fr'/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Captcha_images'
plp_page_save_folder = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Index"
file_path = fr"/home/mkachhadiya@datasos.local/output.txt"

pdp_pagesave_detail = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Detail"
pdp_pagesave_OtherAddress = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/OtherAddress"
pdp_pagesave_Scars = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Scars"
pdp_pagesave_Vehicle = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/PDP_pages/Vehicle"
pdp_pagesave_photo = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/Photos"

process_logs = fr"/home/mkachhadiya@datasos.local/Scrapes/Data/NV/OffenderSearch_NV_SOR/File_{year_month}/process_logs"
os.makedirs(captch_image_store_path,exist_ok=True)
os.makedirs(plp_page_save_folder,exist_ok=True)
os.makedirs(pdp_pagesave_detail,exist_ok=True)
os.makedirs(pdp_pagesave_OtherAddress,exist_ok=True)
os.makedirs(pdp_pagesave_Scars,exist_ok=True)
os.makedirs(pdp_pagesave_Vehicle,exist_ok=True)
os.makedirs(pdp_pagesave_photo,exist_ok=True)
def db_creation():
    conn = pymysql.connect(host="localhost", user="mansi", password="mansi", cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    database = f"NV_SOR_{year_month}"
    query = f"create database if not exists {database}"
    cur.execute(query)
    conn.commit()

def conn_():
    conn = pymysql.connect(host="localhost",user="mansi",password="mansi",database=f"NV_SOR_{year_month}",cursorclass=pymysql.cursors.DictCursor)
    cur = conn.cursor()
    return conn,cur

conn, cur = conn_()
def plp_table_creation_new_fun():
    query = f"""create table if not exists plp_table_creation_new (
    id int auto_increment primary key,
    name varchar(240),
    picture_url text,
    pdp_link text,
    aliases text,
    primaryresidence text,
    first_name varchar(50),
    last_name varchar(50),
    pagesave_path text,
    status varchar(50) default "pending",
    status_main_pdp varchar(50) default "pending",
    status_address varchar(50) default "pending",
    status_scars varchar(50) default "pending",
    status_vehicle varchar(50) default "pending",
    status_image varchar(50) default "pending",
    index index_value (name)
    )engine=InnoDB default CHARSET=utf8mb4 collate=utf8mb4_unicode_ci"""
    cur.execute(query)
    conn.commit()

def pdp_table():
    query = f"""CREATE TABLE IF NOT EXISTS offenders_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        file_id VARCHAR(200) NOT NULL,
        offender VARCHAR(255),
        offender_status VARCHAR(100),
        absconder_detail TEXT,
        first_name VARCHAR(200),
        middle_name VARCHAR(180),
        last_name VARCHAR(200),
        aliases TEXT,
        gender VARCHAR(50),
        race VARCHAR(255),
        ethnicity VARCHAR(255),
        year_of_birth VARCHAR(60),
        height VARCHAR(50),
        weight VARCHAR(50),
        hair_color VARCHAR(50),
        eye_color VARCHAR(50),
        tier_level VARCHAR(50),
        primary_address TEXT,
        county VARCHAR(200),
        start_date VARCHAR(50),
        end_date VARCHAR(50),
        photo TEXT,
        photo_date VARCHAR(255),
        employer_address TEXT,
        school_address TEXT,
        other_address TEXT,
        scars TEXT,
        marks TEXT,
        tattoos TEXT,
        collection_date varchar(60),
        status_pageread varchar(50) default "pending",
        index search_index_apply (first_name,middle_name,last_name),
        UNIQUE KEY unique_file_id (file_id)
        );"""
    cur.execute(query)
    conn.commit()

def offenses_table_creation():
    query = f"""CREATE TABLE if not exists offencese (
        id INT AUTO_INCREMENT PRIMARY KEY,
        file_id VARCHAR(250),
        offense_counter varchar(10),
        conviction_date varchar(60),
        conviction_description TEXT,
        court_name VARCHAR(255),
        conviction_name VARCHAR(255),
        offense_location VARCHAR(255),
        institution_name VARCHAR(255),
        status_pageread varchar(50) default "pending",
        INDEX idx_file_id (file_id),
        INDEX idx_court_name (court_name)
        );"""
    cur.execute(query)
    conn.commit()



if __name__ == "__main__":
    pass
    # db_creation()
    # plp_table_creation_new_fun()
    # pdp_table()
    # offenses_table_creation()