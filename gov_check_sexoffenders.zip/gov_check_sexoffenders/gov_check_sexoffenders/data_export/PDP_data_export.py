import pandas as pd
from pandas import options
import gov_check_sexoffenders.config_use as db
import os
conn, cur = db.conn_()
data_list = list()
batch_size = 100000
query = f"select * from {db.offenders_data}"
query1 = f"select * from {db.offencese}"
cur.execute(query)
columns = [col[0] for col in cur.description]
data = cur.fetchall()
cur.execute(query1)
columns1 = [col[0] for col in cur.description]
data1 = cur.fetchall()

df = pd.DataFrame(data,columns=columns)
df1 = pd.DataFrame(data1,columns=columns1)
df_photo = df.loc[df["photo"].notna() & (df["photo"].astype(str).str.strip() != ""),"photo"]

# df["description"] = df["description"].str.strip()
# df["description"].str.strip().replace("",pd.NA)
df.drop(columns=["id"],inplace=True,errors="ignore")
df1.drop(columns=["id"],inplace=True,errors="ignore")

df.insert(0,"sr_no",range(1,len(df)+1))
df1.insert(0,"sr_no",range(1,len(df1)+1))
columns = df.columns
print(columns)
os.makedirs(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}",exist_ok=True)
df.to_csv(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/NV_SOR_Offenders.csv", index=False)
df1.to_csv(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/NV_SOR_Offenses.csv", index=False)
df_photo.to_csv(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/photo.csv", index=False)


#
# #offender
#
# with pd.ExcelWriter(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/NV_SOR_Offenders.csv",engine="xlsxwriter") as writer:
#     sheet_no = 1
#     total_record = len(df)
#     for start in range(0,total_record,batch_size):
#         end = start+batch_size
#         chunk = df.iloc[start:end]
#         sheet_name = f"sheet{sheet_no}"
#         writer.book.strings_to_urls = False
#         chunk.to_excel(writer,index=False,sheet_name=sheet_name)
#         sheet_no+=1
# #offences
# with pd.ExcelWriter(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/NV_SOR_Offenses.csv",engine="xlsxwriter") as writer:
#     sheet_no = 1
#     total_record = len(df1)
#     for start in range(0,total_record,batch_size):
#         end = start+batch_size
#         chunk = df1.iloc[start:end]
#         sheet_name = f"sheet{sheet_no}"
#         writer.book.strings_to_urls = False
#         chunk.to_excel(writer,index=False,sheet_name=sheet_name)
#         sheet_no+=1
# #photo
# with pd.ExcelWriter(fr"/home/mkachhadiya@datasos.local/Scrapes/output_file/{db.year_month}/photo.csv",engine="xlsxwriter") as writer:
#     sheet_no = 1
#     total_record = len(df_photo)
#     for start in range(0,total_record,batch_size):
#         end = start+batch_size
#         chunk = df_photo.iloc[start:end]
#         sheet_name = f"sheet{sheet_no}"
#         writer.book.strings_to_urls = False
#         chunk.to_excel(writer,index=False,sheet_name=sheet_name)
#         sheet_no+=1