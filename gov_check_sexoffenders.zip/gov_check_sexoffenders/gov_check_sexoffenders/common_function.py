import html
import re

#variable define
domain_name = "https://sexoffenders.nv.gov"

def clean_text(text):
    if not text:
        return None
    text = re.sub(r"\s+"," ",text)
    text = html.unescape(text)
    return text.strip()

def view_state_properties(response):
    pass
