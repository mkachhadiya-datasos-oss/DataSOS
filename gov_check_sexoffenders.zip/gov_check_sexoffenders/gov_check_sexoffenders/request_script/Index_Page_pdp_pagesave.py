import gov_check_sexoffenders.config_use as db
from curl_cffi import requests
from parsel import Selector
import pandas as pd
import deathbycaptcha
from urllib.parse import urlparse, parse_qs, urljoin
import re
import time
def clean_text(value):
    if not value:
        return value
    return re.sub(r"\s+", " ", value).strip()
conn, cur = db.conn_()
max_retry = 3
image_queue = []
BATCH_SIZE = 5
#this is get request done for captch.aspx
def captch_solver(session_id,session):
    url = "https://sexoffenders.nv.gov/Captcha.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Referer": "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    response = session.get(url, headers=headers)
    response = Selector(response.text)
    czptch_path = response.xpath( '//input[@id="LBD_VCT_captcha_ctl00_contentplaceholder1_botdetectcaptcha"]/@value').get()
    src = response.xpath('//img[@id="captcha_ctl00_contentplaceholder1_botdetectcaptcha_CaptchaImage"]/@src').get()
    VIEWSTATE1 = response.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR1 = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION1 = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
    parsed = urlparse(src)
    params = parse_qs(parsed.query)
    s_value = params.get("s", [""])[0]
    return czptch_path,VIEWSTATE1,VIEWSTATEGENERATOR1,EVENTVALIDATION1, s_value

#post request for captch.aspx
def captch_post_requst(session_id,session,czptch_path,VIEWSTATE1,captch_text,VIEWSTATEGENERATOR1,EVENTVALIDATION1):
    #captch_request"
    url = "https://sexoffenders.nv.gov/Captcha.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://sexoffenders.nv.gov/Captcha.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    data = {
        "__LASTFOCUS": "",
        "LBD_VCT_captcha_ctl00_contentplaceholder1_botdetectcaptcha": f"{czptch_path}",
        "__VIEWSTATE": f"{VIEWSTATE1}",
        "ctl00$ContentPlaceHolder1$CodeTextBox": f"{captch_text}",
        "ctl00$ContentPlaceHolder1$ValidateButton": "Continue",
        "__VIEWSTATEGENERATOR": f"{VIEWSTATEGENERATOR1}",
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__EVENTVALIDATION": f"{EVENTVALIDATION1}"
    }
    response = session.post(
        url,
        headers=headers,
        # cookies=cookies,
        data=data,allow_redirects = False )
    print("first page captch solved..")

#lancaptcha request for image download and return captch text
def lanapcaptch(session_id,t,s,session,captcha_controller):
    headers = {
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://sexoffenders.nv.gov/Captcha.aspx',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36',
    }
    params = {
        'get': 'image',
        'c': captcha_controller,
        't': t,
        's': s,
    }
    response = session.get('https://sexoffenders.nv.gov/LanapCaptcha.aspx', params=params, headers=headers)

    with open(fr"{db.captch_image_store_path}/captcha.png", 'wb', buffering=1024*1024) as f:
        f.write(response.content)

    client = deathbycaptcha.HttpClient(db.user_for_captch, db.pass_for_captch)
    captcha_file = fr'{db.captch_image_store_path}/captcha.png'
    captcha = client.decode(captcha_file, timeout=60)

    if captcha:
        print("CAPTCHA text:", captcha['text'])
        with open(fr'{db.captch_image_store_path}/captcha_{captcha['text']}.png', 'wb') as f:
            f.write(response.content)
        return captcha['text']
    else:
        print("Failed to solve captcha.....")
        return None

# 1st default page request if session expire that redirect to this request so we do
#->I agree -> captch get -> lancaptch (return captch text) -> captch post
# buy this we have new session id with that continue process...
def condition_for_user():
    session = requests.Session(impersonate="chrome110")
    #get request step1 :
    url = "https://sexoffenders.nv.gov/ConditionsOfUse.aspx"
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    response = session.get(url, headers=headers )
    session_id = session.cookies.get("ASP.NET_SessionId")
    response = Selector(response.text)
    VIEWSTATE = response.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
    #post request conditionforuse "i agree" step 2
    post_data = {
        "__VIEWSTATE": VIEWSTATE,
        "__VIEWSTATEGENERATOR": VIEWSTATEGENERATOR,
        "__EVENTVALIDATION": EVENTVALIDATION,
        "ctl00$ContentPlaceHolder1$btnAgree": "I agree"
    }
    headers_post = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "max-age=0",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://sexoffenders.nv.gov",
        "Referer": "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    res2 = session.post(
        "https://sexoffenders.nv.gov/ConditionsOfUse.aspx",
        headers=headers_post,
        data=post_data,allow_redirects=False
    )
    #captch request review ()
    czptch_path, VIEWSTATE1, VIEWSTATEGENERATOR1, EVENTVALIDATION1, s_value = captch_solver(session_id,session)
    captcha_controller = "captcha_ctl00_contentplaceholder1_botdetectcaptcha"
    captch_text = lanapcaptch(session_id, czptch_path, s_value,session,captcha_controller)
    captch_post_requst(session_id, session, czptch_path, VIEWSTATE1, captch_text, VIEWSTATEGENERATOR1, EVENTVALIDATION1)
    return session_id, session

def search_ofendr_1(session_id,session):
    for i in range(max_retry):
        try:
            url = "https://sexoffenders.nv.gov/SearchOffender.aspx"
            headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "max-age=0",
                "Referer": "https://sexoffenders.nv.gov/Captcha.aspx",
                "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
            }
            response = session.get(url, headers=headers)
            if response.status_code == 200:
                response = Selector(response.text)
                if response.xpath('//ul[@id="mymenu"]//li//a[contains(text(),"Name Search")]') or "Conditions of Use" not in response._text:
                    break
                else:
                    session_id, session = condition_for_user()
        except Exception as e:
            session_id, session = condition_for_user()
            continue
    session_id = session.cookies.get("ASP.NET_SessionId")
    VIEWSTATE = response.xpath('//input[@id="__VIEWSTATE"]/@value').get()
    VIEWSTATEGENERATOR = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').get()
    EVENTVALIDATION = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').get()
    captcha_hidden = response.xpath('//input[@id="LBD_VCT_searchoffender_ctl00_contentplaceholder1_botdetectcaptcha"]/@value').get()
    #captcha image_solve_
    src = response.xpath('//img[@id="searchoffender_ctl00_contentplaceholder1_botdetectcaptcha_CaptchaImage"]/@src').get()
    parsed = urlparse(src)
    params = parse_qs(parsed.query)
    s_value = params.get("s", [""])[0]
    return VIEWSTATE, VIEWSTATEGENERATOR ,EVENTVALIDATION, captcha_hidden ,session_id,s_value, session

def search_ofender2(VIEWSTATE, VIEWSTATEGENERATOR ,EVENTVALIDATION,first_name,last_name,session_id,session,captcha_hidden, s_value):
    captcha_controller = "searchoffender_ctl00_contentplaceholder1_botdetectcaptcha"
    for i in range(max_retry):
        captch_text = lanapcaptch(session_id, captcha_hidden, s_value, session,captcha_controller)
        url = "https://sexoffenders.nv.gov/SearchOffender.aspx"
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "max-age=0",
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded",
            "Host": "sexoffenders.nv.gov",
            "Origin": "https://sexoffenders.nv.gov",
            "Referer": "https://sexoffenders.nv.gov/SearchOffender.aspx",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
        }
        payload = {
            "LBD_VCT_searchoffender_ctl00_contentplaceholder1_botdetectcaptcha":  captcha_hidden,
            "__EVENTTARGET": 'ctl00$ContentPlaceHolder1$btnSearch',
            # "__EVENTTARGET": "",
            # "ctl00$ContentPlaceHolder1$btnSearch": "Search",
            "__EVENTARGUMENT": "",
            "__VIEWSTATE": VIEWSTATE,
            "__VIEWSTATEGENERATOR":  VIEWSTATEGENERATOR,
            "__EVENTVALIDATION":  EVENTVALIDATION,
            "ctl00$ContentPlaceHolder1$txtLastName": first_name,
            "ctl00$ContentPlaceHolder1$txtFirstName":last_name,
            "ctl00$ContentPlaceHolder1$CodeTextBox": captch_text
        }
        response = session.post(url, headers=headers, data=payload, allow_redirects=True)
        response = Selector(response.text)
        # if "Conditions of Use" in response.text:
        #     VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, captcha_hidden,session_id,s_value,session  = search_ofendr_1(session_id,session)
        # else:
        #     break
        if "Conditions of Use" not in response._text or "Welcome to the Nevada Sex Offender Registry Website, which lists registered sex offenders in Nevada." not in response._text:
            break
        else:
            VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, captcha_hidden,session_id,s_value,session  = search_ofendr_1(session_id,session)
    return response, session_id, session

def ofender_result(first_name,last_name,session_id,session,response):
    if "No offender listed in the statewide registry matches the information" in response._text:
        pagesave_plp_path = fr"{db.plp_page_save_folder}/{first_name}_{last_name}.html"
        with open(pagesave_plp_path, "w", encoding="utf-8") as f:
            f.write(response._text)
        update_table = f"update {db.input_table} set status='no_result' where first_name= %s and last_name= %s"
        cur.execute(update_table,(first_name,last_name))
        conn.commit()
        print(f"no search value found for {first_name} - {last_name}")
        print("=============================================================================")
    else:
        # response = Selector(response._text)
        if response.xpath('//input[@id="ctl00_ContentPlaceHolder1_btnAgree"]'):
            return "change"
        else:
            pagesave_plp_path = fr"{db.plp_page_save_folder}/{first_name}_{last_name}.html"
            with open(pagesave_plp_path, "w", encoding="utf-8") as f:
                f.write(response._text)
            print("done check process")
            # plp_details(response)
            table_path = response.xpath('//h4[contains(text(),"Offenders:")]/following-sibling::table')
            if table_path:
                table = table_path[0]

                #table td data
                rows = table.xpath('.//tr[position()>1]')
                lst = []
                # with ThreadPoolExecutor(max_workers=5) as executor:
                #     futures = [executor.submit(process_row,tr,first_name,last_name,session) for tr in rows]
                #     for future in as_completed(futures):
                #         lst.append(future.result())
                for tr in rows:
                    item = process_row(tr,first_name, last_name, session)
                    lst.append(item)

                row_count = len(lst)
                current_row = 0
                for item in lst:
                    current_row+=1
                    insert_record(item,row_count,current_row)
                 # item = process_row(tr , first_name, last_name, session)

                print("==========================================================================================")

            else:
                print(f"no table result found for {first_name} - {last_name}")

def process_image_queue(session_id,image_queue):
    print(f"Downloading {len(image_queue)} images...")
    for image_url, first_name, last_name, main_id in image_queue:
        try:
            response = session.get(image_url, impersonate="chrome110", timeout=10)
            if response.status_code == 200:
                file_path = f"{db.pdp_pagesave_photo}/{first_name}_{last_name}_{main_id}.jpg"
                with open(file_path, "wb") as f:
                    f.write(response.content)
        except:
            continue
def process_row(tr, first_name, last_name, session):
    item = dict()
    picture = tr.xpath('.//td[1]//img/@src').get()
    pdp_url = tr.xpath('.//td[2]//a/@href').get()
    if pdp_url:
        pdp_url = "https://sexoffenders.nv.gov" + pdp_url.lstrip(".")
    name = tr.xpath('.//td[2]//a/text()').get()
    aliases = [alias.strip() for alias in tr.xpath('.//td[3]/ul//li/text()').getall()]
    primary_residency = [res.strip() for res in tr.xpath('.//td[4]/ul//li/text()').getall()]
    item["name"] = clean_text(name)
    item["picture_url"] = picture
    item["pdp_link"] = pdp_url
    item["aliases"] = clean_text(", ".join(aliases)) if aliases else None
    item["primaryresidence"] = clean_text(", ".join(primary_residency)) if primary_residency else None
    item["first_name"] = first_name
    item["last_name"] = last_name
    item["pagesave_path"] = fr"{db.plp_page_save_folder}/{first_name}_{last_name}.html"
    main_id = "".join(pdp_url.split("&Id=")[-1]).replace(r"/", "_").replace(r"\\", "_").replace("+", "_")
    session, status_main_pdp, status_image = pdp_main_req(pdp_url, session, last_name, first_name, main_id)
    session, status_address = other_address_req(session, last_name, first_name, main_id)
    session, status_scars = scars_req(session, last_name, first_name, main_id)
    session, status_vehicle = vehical_req(session, last_name, first_name, main_id)
    item["status_main_pdp"] = status_main_pdp
    item["status_address"] = status_address
    item["status_scars"] = status_scars
    item["status_vehicle"] = status_vehicle
    item["status_image"] = status_image
    return item
def pdp_main_req(pdp_url,session,last_name,first_name,main_id):
    for i in range(max_retry):
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://sexoffenders.nv.gov/OffenderSearchResults.aspx",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
        }
        response = session.get(
            pdp_url,
            headers=headers,
            allow_redirects= True
        )
        if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
            break
        elif response.status_code == 302 or "Object moved to" in response.text or "Conditions of Use" in response.text:
            session_id, session = condition_for_user()
            continue
    if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
        # page save for main request
        with open(f"{db.pdp_pagesave_detail}/{first_name}_{last_name}_{main_id}.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        status_main_pdp="done"
        print("main_req pagesave done for ",first_name,"-",last_name,"-",main_id)
        #other address page request finding
        #image request
        response = Selector(response.text)
        photo_path = response.xpath('//img[@id="ctl00_ContentPlaceHolder1_OffenderDetails1_imgOffender"]/@src').get()
        if photo_path:
            image_url = urljoin("https://sexoffenders.nv.gov/", photo_path)
            image_queue.append((image_url, first_name, last_name, main_id))
            status_image = "queued"
            if len(image_queue) >= BATCH_SIZE:
                process_image_queue(session, image_queue)
                image_queue.clear()
            # status_image = image_download(image_url,session,first_name,last_name,main_id)
        else:
            status_image = "response_issue"
    else:
        status_main_pdp="response_issue"
        status_image = "response_issue"
    return session, status_main_pdp ,status_image
def other_address_req(session,last_name,first_name,main_id):
    url=f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=OtherAddresses&ID={main_id}"

    for i in range(max_retry):
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=Main&Id={main_id}",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
        }
        response = session.get(
            url,
            headers=headers,
            allow_redirects=True
        )
        if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
            break
        elif response.status_code == 302 or "Object moved to" in response.text or "Conditions of Use" in response.text:
            session_id,session = condition_for_user()

            continue
    if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
        with open(f"{db.pdp_pagesave_OtherAddress}/{first_name}_{last_name}_{main_id}.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        status_address = "done"
        print("address_req pagesave done for ", first_name, "-", last_name, "-", main_id)

    else:
        status_address = "response_issue"
        print("having some issue in other address..")
    return session ,status_address
def scars_req(session,last_name,first_name,main_id):
    url=f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=Scars&ID={main_id}"

    for i in range(max_retry):
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=OtherAddresses&ID={main_id}",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
        }

        response = session.get(
            url,
            headers=headers,
            allow_redirects=True
        )
        if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
            break
        elif response.status_code == 302 or "Object moved to" in response.text or "Conditions of Use" in response.text:
            session_id,session = condition_for_user()
            continue
    if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
        with open(f"{db.pdp_pagesave_Scars}/{first_name}_{last_name}_{main_id}.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        status_scars = "done"
        print("scars pagesave done for ", first_name, "-", last_name, "-", main_id)

    else:
        status_scars = "response_issue"
        print("having some issue in scars...")
    return session , status_scars
def vehical_req(session,last_name,first_name,main_id):
    url=f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=VehicleInformation&ID={main_id}"

    for i in range(max_retry):
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": f"https://sexoffenders.nv.gov/OffenderDetails.aspx?Display=Scars&ID={main_id}",
            "Upgrade-Insecure-Requests": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36",
        }
        response = session.get(
            url,
            headers=headers,
            allow_redirects=True
        )
        if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
            break
        elif response.status_code == 302 or "Object moved to" in response.text or "Conditions of Use" in response.text:
            session_id,session = condition_for_user()

            continue
    if response.status_code == 200 and "Object moved to" not in response.text and "Conditions of Use" not in response.text:
        with open(f"{db.pdp_pagesave_Vehicle}/{first_name}_{last_name}_{main_id}.html", "w", encoding="utf-8") as f:
            f.write(response.text)
        status_vehicle = "done"
        print("vehical pagesave done for ", first_name, "-", last_name, "-", main_id)
    else:
        status_vehicle = "response_issue"
        print("having some issue in vehical..")
    return session , status_vehicle

def image_download(image_url,session,first_name,last_name,main_id):
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Host": "sexoffenders.nv.gov",
        "sec-ch-ua": '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36"
    }
    response = session.get(image_url, headers=headers, impersonate="chrome110")
    if response.status_code == 200:
        file_path = f"{db.pdp_pagesave_photo}/{first_name}_{last_name}_{main_id}.jpg"
        with open(file_path, "wb", buffering=1024*1024) as f:
            f.write(response.content)
        status_image = "done"
        print("----------------------------------")
        print(fr"image pagesave done for {first_name} - {last_name} - {main_id}")
        return status_image
    else:
        status_image = "response_issue"
        print(f"image pagesave issue=== for {first_name} - {last_name} - {main_id}")
        return status_image
        f.write(response.content)

def insert_record(item,row_count,current_row):
    keys = ", ".join(item.keys())
    values = tuple(item.values())
    place_holder = ", ".join(["%s"] * len(item))
    query = f"""
    INSERT IGNORE INTO {db.plp_table_creation_new} ({keys})
    VALUES ({place_holder})
    """
    try:
        cur.execute(query,values)
        conn.commit()
    except Exception as e:
        print(str(e))
    if row_count == current_row:
        update_table = f"update {db.input_table} set status='done' where first_name= %s and last_name= %s"
        cur.execute(update_table,(item["first_name"],item["last_name"]))
        conn.commit()
    print(f"*********record found for {item['first_name']} - {item['last_name']} - total_row:{row_count} - current_row:{current_row}***********")



if __name__ == "__main__":
    # session_id = get_key()
    start_time = time.time()
    df = pd.read_excel(r"/home/mkachhadiya@datasos.local/Documents/check_records.xlsx")
    session_id ,session= condition_for_user()

    query = f"select * from {db.input_table} where id between 324734 and 324744"
    cur.execute(query)
    data = cur.fetchall()
    for row in data:
        first_name = row["first_name"]
        last_name = row["last_name"]
        for i in range(5):

            VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, captcha_hidden,session_id,s_value,session= search_ofendr_1(session_id, session)
            response_serch_offender ,session_id, session =search_ofender2(VIEWSTATE, VIEWSTATEGENERATOR, EVENTVALIDATION, first_name, last_name, session_id, session, captcha_hidden,s_value)
            return_value = ofender_result(first_name, last_name, session_id, session,response_serch_offender)
            if return_value == "change":
                session_id, session = condition_for_user()
                continue
            else:
                break
    end_time = time.time()
    total_time = end_time-start_time
    print("total _time for 10 records:",total_time)

