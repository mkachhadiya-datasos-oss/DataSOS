# Define your item pipelines here
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import curl_cffi
# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from gov_check_sexoffenders.items import *
import gov_check_sexoffenders.config_use as db

class GovCheckSexoffendersPipeline:
    conn,cur = db.conn_()
    def insert_item(self,item,table_name,parent_table=None):
        id_ = item.pop("id_")
        keys = ", ".join(item.keys())
        values = tuple(item.values())
        placeholder = ", ".join(["%s"] * len(item))
        try:
            query = f"insert into {table_name} ({keys}) values ({placeholder})"
            self.cur.execute(query,values)
            self.conn.commit()
        except Exception as e:
            print("issue in insertion.....",e)
        try:
            update_query = f"update {parent_table} set status='page_read' where id= %s"
            self.cur.execute(update_query,(id_,))
            self.conn.commit()
        except Exception as e:
            print("issue in data updation .....",e)

    def process_item(self, item, spider):
        if isinstance(item,GovCheckSexoffendersItem):
            self.insert_item(item,db.offenders_data,db.plp_table_creation_new)

        if isinstance(item,GovCheckOffensesItem):
            self.insert_item(item,db.offencese)
        return item


